from __future__ import annotations

import json
from typing import Any, Literal

from pydantic import BaseModel, Field

from config import ALLOWED_ACTIONS
from governance import redact_sensitive, redact_customer_state_for_llm
from json_utils import ensure_object, extract_json, response_text
from life_event import LifeEventResult
from llm_provider import create_groq_llm, invoke
from policy_registry import PolicyRegistry, PolicyViolationError


class CustomerDecision(BaseModel):
    customer_id: str
    inferred_state: str
    confidence_band: Literal["low", "medium", "high"]
    confidence: float = Field(ge=0.0, le=1.0)
    action: Literal[
        "no_action", "proactive_retention_outreach", "relationship_manager_escalation",
        "personalized_offer", "support_intervention", "compliance_fraud_hold",
    ]
    action_subtype: str | None
    rationale: str
    evidence: list[str] = Field(default_factory=list)
    risk_flags: list[str] = Field(default_factory=list)
    requires_human_review: bool = False
    hitl_status: Literal["auto_approved", "escalated", "human_approved", "human_rejected", "human_modified", "timed_out"] = "auto_approved"
    decision_provider: Literal["groq", "deterministic_fallback"] = "groq"


class DecisionAgent:
    """Selects a bounded intervention, constrained by deterministic policy validation."""
    def __init__(self, llm=None):
        self.name = "decision_agent"
        self.llm = llm if llm is not None else create_groq_llm("decision", default_model="openai/gpt-oss-20b", default_temperature=0.0)
        self.registry = PolicyRegistry()
        self.last_prompt = ""
        self.last_error: str | None = None
        self.last_provider = "deterministic_fallback"

    def _prompt(self, life_event: LifeEventResult, context: dict[str, Any], policy: dict[str, Any], correction: str = "") -> str:
        constraint = {
            "allowed_actions": self.registry.allowed_actions_for(life_event.inferred_state),
            "allowed_action_subtypes": policy.get("allowed_action_subtypes", {}),
            "human_review_actions": policy.get("human_review_actions", []),
            "offer_type": policy.get("offer_type"),
        }
        return f"""
You are the Decision Agent in an ambient Customer 360 system.

Choose one bounded action from the policy-constrained vocabulary. Policy constraints
are limits, not proof that an action should occur. Low or medium confidence may result
in explicit no_action. Never claim HITL approval before a human acts. Never invent facts.

Allowed action vocabulary: {json.dumps(ALLOWED_ACTIONS, separators=(",", ":"))}
Policy constraint: {json.dumps(constraint, separators=(",", ":"), ensure_ascii=False)}
Life-event inference: {json.dumps(redact_sensitive(life_event.model_dump()), separators=(",", ":"), ensure_ascii=False, default=str)}
Context: {json.dumps(redact_sensitive(context), separators=(",", ":"), ensure_ascii=False, default=str)}
{correction}

Return ONLY JSON:
{{"action":"allowed action","action_subtype":"allowed subtype or null","rationale":"brief evidence-grounded rationale","risk_flags":[],"requires_human_review":false,"hitl_status":"auto_approved|escalated"}}
""".strip()

    @staticmethod
    def _fallback(life_event: LifeEventResult, registry: PolicyRegistry, error: Exception | None = None, context: dict[str, Any] | None = None) -> CustomerDecision:
        allowed = registry.allowed_actions_for(life_event.inferred_state)
        action = "no_action"
        prior_actions = (context or {}).get("prior_action_history", [])
        if life_event.confidence_band == "high":
            if life_event.inferred_state == "churn_risk" and any(str(a.get("action")) == "relationship_manager_escalation" for a in prior_actions if isinstance(a, dict)) and "proactive_retention_outreach" in allowed:
                action = "proactive_retention_outreach"
            else:
                action = next((a for a in allowed if a != "no_action"), "no_action")
        elif "no_action" not in allowed:
            action = allowed[0] if allowed else "no_action"
        subtypes = registry.allowed_subtypes_for(life_event.inferred_state, action)
        subtype = subtypes[0] if subtypes else (None if action == "no_action" else "review")
        requires = registry.requires_human_review(life_event.inferred_state, action)
        reason = (
            "A bounded policy-permitted action was selected by the deterministic resilience path."
            if action != "no_action"
            else "The evidence confidence is not sufficient for a customer-facing action at this checkpoint."
        )
        if life_event.inferred_state == "churn_risk" and action == "proactive_retention_outreach":
            reason += " A prior relationship-manager escalation exists, so the next distinct retention stage is proactive outreach rather than duplicate escalation."
        return CustomerDecision(
            customer_id=life_event.customer_id, inferred_state=life_event.inferred_state, confidence_band=life_event.confidence_band,
            confidence=life_event.confidence, action=action, action_subtype=subtype, rationale=reason,
            evidence=life_event.evidence, risk_flags=["llm_fallback"] if error else [], requires_human_review=requires,
            hitl_status="escalated" if requires else "auto_approved", decision_provider="deterministic_fallback",
        )

    def decide(self, life_event: LifeEventResult, semantic_policy: dict | None = None, context: dict[str, Any] | None = None) -> CustomerDecision:
        policy = self.registry.for_state(life_event.inferred_state)
        if semantic_policy and isinstance(semantic_policy, dict):
            for rule in semantic_policy.get("rules", []):
                if rule.get("state") == life_event.inferred_state:
                    policy = dict(rule)
                    break

        compact_context = {
            "customer_state": redact_customer_state_for_llm(dict((context or {}).get("customer_state", {}))),
            "specialist_findings": (context or {}).get("specialist_findings", [])[:4],
            "correlated_signals": (context or {}).get("correlated_signals", [])[:6],
            "evidence": (context or {}).get("evidence", [])[:6],
            "memory": (context or {}).get("memory", [])[:3],
            "debate": (context or {}).get("debate", {}),
            "prior_action_history": (context or {}).get("prior_action_history", [])[-10:],
        }
        prompt = self._prompt(life_event, compact_context, policy)
        self.last_prompt = prompt
        self.last_error = None

        if self.llm is None:
            result = self._fallback(life_event, self.registry, context=compact_context)
            self.last_provider = "deterministic_fallback"
            print("[DECISION] Deterministic fallback: provider unavailable.")
            return result

        try:
            response = invoke(self.llm, prompt, "decision")
            data = ensure_object(extract_json(response_text(response)))
            data.update({
                "customer_id": life_event.customer_id,
                "inferred_state": life_event.inferred_state,
                "confidence": life_event.confidence,
                "confidence_band": life_event.confidence_band,
                "evidence": life_event.evidence,
                "decision_provider": "groq",
            })
            result = CustomerDecision.model_validate(data)
            self.registry.validate(result, life_event)
            # Deterministic action-safety layer: non-high confidence cannot autonomously
            # create a customer-facing intervention. This keeps early weak signals in
            # observation mode even when a model is over-eager.
            if life_event.confidence_band != "high" and result.action != "no_action":
                result.action = "no_action"
                result.action_subtype = None
                result.requires_human_review = False
                result.hitl_status = "auto_approved"
                result.risk_flags.append("confidence_gate_no_action")
                result.rationale = "Confidence gate kept the checkpoint in explicit no-action mode until evidence becomes high-confidence."
            prior_actions = compact_context.get("prior_action_history", [])
            if life_event.inferred_state == "churn_risk" and life_event.confidence_band == "high" and any(str(a.get("action")) == "relationship_manager_escalation" for a in prior_actions if isinstance(a, dict)) and result.action == "relationship_manager_escalation" and "proactive_retention_outreach" in self.registry.allowed_actions_for(life_event.inferred_state):
                result.action = "proactive_retention_outreach"
                result.action_subtype = self.registry.allowed_subtypes_for(life_event.inferred_state, result.action)[0] or "retention_review"
                result.requires_human_review = True
                result.hitl_status = "escalated"
                result.rationale = "A prior relationship-manager escalation exists; policy stages the next distinct retention action as proactive outreach."
            self.registry.validate(result, life_event)
            self.last_provider = "groq"
            print(f"[DECISION] Groq: {result.action} / {result.action_subtype} | HITL={result.hitl_status}.")
            return result
        except Exception as exc:
            self.last_error = f"{type(exc).__name__}: {exc}"
            result = self._fallback(life_event, self.registry, exc, context=compact_context)
        self.last_provider = "deterministic_fallback"
        print(f"[DECISION] Groq output unusable; fallback used: {self.last_error or 'provider error'}.")
        return result
