"""Single source of truth for the PS-facing agent/data-flow manifest.

This registry is descriptive metadata used by verification/docs/UI; the runtime orchestration
remains in the dedicated agent modules. Keeping the manifest explicit makes the PS requirement
"what each agent can read/write and when it fires" inspectable without reading the whole codebase.
"""
from __future__ import annotations

AGENT_REGISTRY = {
    "usage_agent": {
        "role": "Usage / Engagement",
        "trigger": "event-based + time-based",
        "tools": ["windowed_aggregation", "trend_detection", "anomaly_scoring"],
        "reads": ["web_app_events"],
        "writes": ["state_board.finding", "feature_store"],
        "handoff": "structured usage finding -> synthesis",
    },
    "support_agent": {
        "role": "Support / Sentiment",
        "trigger": "event-based",
        "tools": ["ticket_retrieval", "sentiment_analysis", "urgency_detection"],
        "reads": ["support_logs"],
        "writes": ["state_board.finding", "feature_store"],
        "handoff": "structured support finding -> synthesis",
    },
    "transaction_agent": {
        "role": "Transaction / Billing",
        "trigger": "event-based",
        "tools": ["transaction_query", "historical_baseline", "anomaly_scoring"],
        "reads": ["card_payments", "instant_payments", "ach_wire", "core_banking_ledger", "trading_brokerage"],
        "writes": ["state_board.finding", "feature_store"],
        "handoff": "structured transaction finding -> synthesis",
    },
    "kyc_compliance_agent": {
        "role": "KYC / Compliance",
        "trigger": "event-based + time-based",
        "tools": ["kyc_lookup", "sanctions_lookup", "compliance_rules"],
        "reads": ["loan_kyc", "semantic_policy"],
        "writes": ["state_board.finding"],
        "handoff": "structured KYC finding -> synthesis",
    },
    "synthesis_agent": {
        "role": "Synthesis / Correlation",
        "trigger": "agent-dependent",
        "tools": ["state_board_read", "episodic_retrieval", "semantic_policy_retrieval", "cross_domain_correlation"],
        "reads": ["state_board", "episodic_memory", "semantic_memory"],
        "writes": ["correlated_signals", "conflict_package"],
        "handoff": "compact signals + conflict package -> life_event",
    },
    "life_event_agent": {
        "role": "Life-Event Inference",
        "trigger": "agent-dependent",
        "tools": ["cross_domain_join", "consented_social_enrichment", "episodic_retrieval"],
        "reads": ["structured specialist findings", "state_board", "episodic_memory", "consented social signal"],
        "writes": ["inferred semantic state + evidence"],
        "handoff": "state + confidence + source event IDs -> decision",
    },
    "debate_agent": {
        "role": "Conflict / Debate / Arbitration",
        "trigger": "agent-dependent, only when material disagreement exists",
        "tools": ["conflict_detector", "two_perspective_debate", "arbitration_rule"],
        "reads": ["specialist findings", "correlated signals", "life-event inference"],
        "writes": ["debate transcript", "resolution status", "consensus", "disagreements"],
        "handoff": "resolved or unresolved interpretation -> decision",
    },
    "decision_agent": {
        "role": "Bounded Decision",
        "trigger": "sequential handoff",
        "tools": ["policy_constraints", "confidence_gate", "action_lifecycle_check"],
        "reads": ["life-event result", "semantic policy", "debate package", "prior action history"],
        "writes": ["bounded action proposal"],
        "handoff": "bounded action + rationale -> offer",
    },
    "offer_eligibility_agent": {
        "role": "Offer / Eligibility",
        "trigger": "agent-dependent after decision",
        "tools": ["policy_rag", "eligibility_rules", "product_offer_lookup"],
        "reads": ["semantic policy", "decision", "life-event result"],
        "writes": ["eligibility result + conditions"],
        "handoff": "eligible/review/not-eligible package -> action agent",
    },
    "retention_action_agent": {
        "role": "Retention / Action",
        "trigger": "agent-dependent after decision + offer",
        "tools": ["bounded_action_planner", "CRM_grounding", "episodic_intervention_lookup"],
        "reads": ["decision", "offer eligibility", "customer evidence", "episodic memory"],
        "writes": ["auditable action proposal; no side effects"],
        "handoff": "purpose + allowed/prohibited content + evidence IDs -> round-robin drafting",
    },
    "drafting_agent": {
        "role": "Round-Robin Customer Communication",
        "trigger": "sequential handoff",
        "tools": ["message_composer", "evidence_grounding"],
        "reads": ["action proposal", "offer", "bounded decision context"],
        "writes": ["3 sequential customer-facing drafts"],
        "handoff": "draft set -> critique/refiner",
    },
    "critique_compliance_agent": {
        "role": "Critique / Compliance-Refiner",
        "trigger": "agent-dependent after drafting",
        "tools": ["policy_rag", "deterministic_guardrail_checker", "cost_feasibility_check", "tone_review"],
        "reads": ["drafts", "offer eligibility", "policy"],
        "writes": ["review verdicts + revision"],
        "handoff": "compliant/revised draft -> final guardrail",
    },
    "guardrail_hitl_agent": {
        "role": "Escalation / Guardrail",
        "trigger": "event-based hard-stop + final synchronous gate",
        "tools": ["hard_stop_keyword_scanner", "PII_checker", "policy_action_check", "blast_radius_check"],
        "reads": ["raw event text", "decision", "offer", "critiques", "drafts"],
        "writes": ["continue / block / HITL requirement", "specialized review queue"],
        "handoff": "real HITL checkpoint or blocked terminal path",
    },
    "execution_agent": {
        "role": "Safe Execution Adapter",
        "trigger": "only after deterministic guardrail + human clearance when required",
        "tools": ["simulated_side_effect_adapter"],
        "reads": ["guardrail result", "selected final draft"],
        "writes": ["simulated execution/audit result"],
        "handoff": "customer/relationship-manager outcome",
    },
}


def validate_registry() -> None:
    required = {"role", "trigger", "tools", "reads", "writes", "handoff"}
    for name, record in AGENT_REGISTRY.items():
        missing = required - set(record)
        if missing:
            raise ValueError(f"Agent registry entry {name!r} is missing {sorted(missing)}")
