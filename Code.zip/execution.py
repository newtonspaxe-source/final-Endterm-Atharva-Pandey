from typing import Literal

from pydantic import BaseModel, Field

from drafting import ActionDraft
from guardrail import GuardrailResult


class ExecutionResult(BaseModel):
    customer_id: str
    execution_status: Literal["executed", "pending_human_review", "blocked"]
    action: str
    draft_id: str | None = None
    execution_message: str
    audit_record: dict = Field(default_factory=dict)


class ExecutionAgent:
    """Safe simulated action adapter. No real banking/customer API is called."""

    def __init__(self):
        self.name = "execution_agent"

    def execute(self, guardrail: GuardrailResult, drafts: list[ActionDraft]) -> ExecutionResult:
        if guardrail.decision == "blocked":
            return ExecutionResult(
                customer_id=guardrail.customer_id,
                execution_status="blocked",
                action="blocked_action",
                execution_message="Execution blocked by deterministic guardrails.",
                audit_record={
                    "guardrail_decision": guardrail.decision,
                    "hitl_status": guardrail.hitl_status,
                    "reason": guardrail.reason,
                    "flags": guardrail.guardrail_flags,
                },
            )

        if guardrail.decision == "requires_human_review":
            return ExecutionResult(
                customer_id=guardrail.customer_id,
                execution_status="pending_human_review",
                action="human_review",
                draft_id=guardrail.selected_draft_id,
                execution_message="Action is waiting at the human approval checkpoint and has not been executed.",
                audit_record={
                    "guardrail_decision": guardrail.decision,
                    "hitl_status": guardrail.hitl_status,
                    "reason": guardrail.reason,
                    "selected_draft_id": guardrail.selected_draft_id,
                },
            )

        if guardrail.decision == "no_action_required":
            return ExecutionResult(
                customer_id=guardrail.customer_id,
                execution_status="executed",
                action="no_action",
                execution_message="No customer-facing action required; explicit no-action terminal decision recorded.",
                audit_record={
                    "guardrail_decision": guardrail.decision,
                    "hitl_status": guardrail.hitl_status,
                    "reason": guardrail.reason,
                },
            )

        selected = next((d for d in drafts if d.draft_id == guardrail.selected_draft_id), None)
        if selected is None:
            return ExecutionResult(
                customer_id=guardrail.customer_id,
                execution_status="blocked",
                action="blocked_action",
                execution_message="Execution blocked because the guardrail-selected draft could not be found.",
                audit_record={
                    "guardrail_decision": guardrail.decision,
                    "error": "selected_draft_not_found",
                },
            )

        # This final adapter is intentionally a simulation. A real side-effecting
        # tool would be called only here, after the guardrail returned approved_for_execution.
        return ExecutionResult(
            customer_id=guardrail.customer_id,
            execution_status="executed",
            action=selected.action,
            draft_id=selected.draft_id,
            execution_message="Human-cleared action reached the simulated execution adapter.",
            audit_record={
                "guardrail_decision": guardrail.decision,
                "hitl_status": guardrail.hitl_status,
                "selected_draft": selected.draft_id,
                "action": selected.action,
                "action_subtype": selected.action_subtype,
                "side_effect": "simulated_only",
            },
        )
