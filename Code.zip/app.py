from __future__ import annotations

import html
import json
import os
from pathlib import Path
import subprocess
import sys
from typing import Any

import streamlit as st
from dotenv import load_dotenv

from config import (
    ALLOWED_ACTIONS,
    ALLOWED_CONFIDENCE_BANDS,
    ALLOWED_HITL,
    ALLOWED_STATES,
    discover_scenarios,
    load_json,
    load_scenario_metadata,
    project_root,
)

# -----------------------------------------------------------------------------
# PAGE / THEME
# -----------------------------------------------------------------------------
st.set_page_config(
    page_title="Customer 360 · Control Room",
    page_icon="◉",
    layout="wide",
    initial_sidebar_state="expanded",
)

BASE_DIR = project_root()
load_dotenv(BASE_DIR / "api.env", override=False)
OUTPUT_DIR = BASE_DIR / "outputs"
MEMORY_DIR = BASE_DIR / "memory"

if "processes" not in st.session_state:
    st.session_state.processes = {}
if "log_handles" not in st.session_state:
    st.session_state.log_handles = {}
if "last_message" not in st.session_state:
    st.session_state.last_message = ""
if "selected_scenario" not in st.session_state:
    st.session_state.selected_scenario = ""

# -----------------------------------------------------------------------------
# AESTHETIC SYSTEM
# Main surface is warm slate, not white. Sidebar is deep navy. Cards are dark
# enough to contrast, while content panels remain readable. No fake state is
# created by the UI; colors only communicate runtime status.
# -----------------------------------------------------------------------------
st.markdown(
    """
<style>
:root {
  --bg: #0b1220;
  --bg-2: #0f1829;
  --sidebar: #070e1b;
  --surface: #121d30;
  --surface-2: #17243a;
  --surface-3: #1b2a42;
  --ink: #edf4ff;
  --ink-soft: #c7d2e3;
  --muted: #8e9db4;
  --line: #263650;
  --line-strong: #344866;
  --accent: #69b7ff;
  --accent-2: #72dfd0;
  --green: #42d392;
  --amber: #f4bc57;
  --red: #ff7777;
  --shadow: 0 14px 34px rgba(0,0,0,.22);
}

html, body, [data-testid="stAppViewContainer"] {
  background: var(--bg) !important;
  color: var(--ink) !important;
}

[data-testid="stAppViewContainer"] {
  background:
    radial-gradient(circle at 92% 4%, rgba(105,183,255,.08), transparent 24%),
    radial-gradient(circle at 8% 12%, rgba(114,223,208,.055), transparent 22%),
    linear-gradient(180deg, #0d1524 0%, #0b1220 100%) !important;
}

[data-testid="stMain"] {
  background: transparent !important;
}

[data-testid="stHeader"] {
  background: transparent !important;
}

.block-container {
  max-width: 1580px;
  padding-top: 1rem;
  padding-bottom: 3rem;
}

/* Native Streamlit text: explicit light-on-dark so no white text disappears on pale panels. */
[data-testid="stAppViewContainer"] [data-testid="stMarkdownContainer"] p,
[data-testid="stAppViewContainer"] [data-testid="stMarkdownContainer"] h1,
[data-testid="stAppViewContainer"] [data-testid="stMarkdownContainer"] h2,
[data-testid="stAppViewContainer"] [data-testid="stMarkdownContainer"] h3,
[data-testid="stAppViewContainer"] [data-testid="stMarkdownContainer"] h4,
[data-testid="stAppViewContainer"] [data-testid="stMarkdownContainer"] li,
[data-testid="stAppViewContainer"] [data-testid="stCaptionContainer"] {
  color: var(--ink-soft) !important;
}

[data-testid="stAppViewContainer"] [data-testid="stMarkdownContainer"] strong,
[data-testid="stAppViewContainer"] [data-testid="stMarkdownContainer"] b,
[data-testid="stAppViewContainer"] [data-testid="stMarkdownContainer"] h1,
[data-testid="stAppViewContainer"] [data-testid="stMarkdownContainer"] h2,
[data-testid="stAppViewContainer"] [data-testid="stMarkdownContainer"] h3,
[data-testid="stAppViewContainer"] [data-testid="stMarkdownContainer"] h4 {
  color: var(--ink) !important;
}

[data-testid="stAppViewContainer"] code {
  color: #dce8fa !important;
  background: #0f192a !important;
  border: 1px solid #263650;
}

/* Sidebar */
[data-testid="stSidebar"] {
  background: linear-gradient(180deg, #070e1b 0%, #0a1425 100%) !important;
  border-right: 1px solid #1c2a40 !important;
}
[data-testid="stSidebar"] .block-container { padding: 1rem .9rem 1.4rem .9rem; }
[data-testid="stSidebar"] [data-testid="stMarkdownContainer"] p,
[data-testid="stSidebar"] [data-testid="stCaptionContainer"],
[data-testid="stSidebar"] label { color: #b9c7db !important; }
[data-testid="stSidebar"] [data-baseweb="select"] > div,
[data-testid="stSidebar"] input,
[data-testid="stSidebar"] textarea {
  background: #101b30 !important;
  color: #eef5ff !important;
  border: 1px solid #273852 !important;
}
[data-testid="stSidebar"] hr { border-color: #1c2a40 !important; }

.sidebar-brand { padding: .25rem .2rem 1rem .2rem; }
.sidebar-brand-top { display:flex; align-items:center; gap:.55rem; color:#f2f7ff; }
.sidebar-brand-mark {
  width:34px; height:34px; border-radius:11px; display:flex; align-items:center; justify-content:center;
  background: linear-gradient(135deg,#4e8df6,#45d3c2); color:#07111f; font-weight:950;
  box-shadow: 0 10px 24px rgba(69,211,194,.18);
}
.sidebar-brand-title { font-weight:900; font-size:1.06rem; }
.sidebar-brand-sub { font-size:.72rem; color:#7f91aa; margin-top:.15rem; }
.sidebar-section {
  margin:.95rem 0 .55rem; font-size:.64rem; text-transform:uppercase; letter-spacing:.14em;
  font-weight:900; color:#6f86a5;
}
.sidebar-note { font-size:.70rem; line-height:1.5; color:#71839e !important; }

/* Hero */
.hero {
  position:relative; overflow:hidden; border-radius:24px; padding:28px 30px 26px; color:#fff;
  background:
    radial-gradient(circle at 85% 15%, rgba(105,183,255,.20), transparent 26%),
    radial-gradient(circle at 18% 0%, rgba(114,223,208,.10), transparent 26%),
    linear-gradient(135deg,#111c31 0%,#142640 55%,#102b38 100%);
  border:1px solid #253751;
  box-shadow: 0 20px 46px rgba(0,0,0,.25);
  margin-bottom:16px;
}
.hero::after {
  content:""; position:absolute; width:320px; height:320px; border-radius:50%; right:-150px; bottom:-190px;
  border:1px solid rgba(255,255,255,.08); box-shadow:0 0 0 42px rgba(255,255,255,.015),0 0 0 86px rgba(255,255,255,.01);
}
.hero-kicker { color:#87c8ff; font-size:.69rem; text-transform:uppercase; letter-spacing:.16em; font-weight:900; }
.hero-title { margin-top:.35rem; font-size:2.18rem; line-height:1.05; font-weight:950; letter-spacing:-.03em; color:#f5f9ff !important; }
.hero-subtitle { max-width:930px; margin-top:.55rem; color:#c8d5e7; font-size:.90rem; line-height:1.55; }
.hero-meta { display:flex; flex-wrap:wrap; gap:.45rem; margin-top:1rem; }
.hero-chip {
  display:inline-flex; align-items:center; gap:.32rem; padding:.36rem .64rem; border-radius:999px;
  border:1px solid rgba(255,255,255,.12); background:rgba(255,255,255,.07); color:#edf5ff;
  font-size:.71rem; font-weight:800;
}
.hero-chip.green { background:rgba(66,211,146,.12); color:#a9f2d1; border-color:rgba(95,227,167,.24); }
.hero-chip.blue { background:rgba(105,183,255,.13); color:#cbe7ff; border-color:rgba(105,183,255,.24); }
.hero-chip.amber { background:rgba(244,188,87,.13); color:#ffe0a0; border-color:rgba(244,188,87,.25); }
.hero-chip.red { background:rgba(255,119,119,.12); color:#ffd0d0; border-color:rgba(255,119,119,.22); }

/* Top navigation */
div[data-baseweb="tab-list"] { gap:.45rem; background:transparent; margin-bottom:1rem; }
button[data-baseweb="tab"] {
  border:1px solid #24334b !important; border-radius:12px !important; background:#111b2d !important;
  color:#8fa1bb !important; padding:.56rem .86rem !important; font-size:.80rem !important; font-weight:850 !important;
  box-shadow: inset 0 1px 0 rgba(255,255,255,.025);
}
button[data-baseweb="tab"] span { color:#8fa1bb !important; }
button[data-baseweb="tab"][aria-selected="true"] {
  background:linear-gradient(180deg,#243a60,#1b304f) !important;
  color:#f2f7ff !important; border-color:#4775a8 !important; box-shadow:0 8px 20px rgba(0,0,0,.20);
}
button[data-baseweb="tab"][aria-selected="true"] span { color:#f2f7ff !important; }
button[data-baseweb="tab"]::after { display:none !important; }

/* Section headers */
.section-head { display:flex; align-items:flex-end; justify-content:space-between; gap:1rem; margin:8px 0 9px; }
.section-title { font-weight:900; font-size:1.04rem; color:#eff5ff !important; }
.section-caption { font-size:.73rem; color:#7f92ad !important; }

/* Metrics */
[data-testid="stMetric"] {
  border:1px solid #263650; border-radius:16px; background:linear-gradient(180deg,#142137,#111c2f) !important;
  box-shadow:var(--shadow); padding:.66rem .78rem .72rem;
}
[data-testid="stMetricLabel"] { color:#8798b2 !important; font-size:.70rem !important; }
[data-testid="stMetricValue"] { color:#f1f6ff !important; font-size:1.18rem !important; font-weight:950 !important; }

.surface-card, .profile-card, .detail-card {
  border:1px solid #263650; border-radius:18px; padding:16px 17px;
  background:linear-gradient(180deg,#142137,#111c2f); box-shadow:var(--shadow);
}
.profile-card { background:linear-gradient(135deg,#172843,#122035); }
.profile-top { display:flex; align-items:center; justify-content:space-between; gap:1rem; }
.profile-avatar {
  width:46px; height:46px; border-radius:14px; display:flex; align-items:center; justify-content:center; flex:0 0 auto;
  background:linear-gradient(135deg,#4e8df6,#45d3c2); color:#07111f; font-weight:950; font-size:1rem;
}
.profile-name { font-size:1.17rem; font-weight:950; color:#f3f7ff !important; }
.profile-id { margin-top:.15rem; font-size:.75rem; color:#8a9ab2 !important; }
.profile-tag { padding:.31rem .55rem; border-radius:999px; background:#1b3152; color:#a9d4ff; font-size:.68rem; font-weight:850; border:1px solid #31557f; }
.small-label { font-size:.64rem; text-transform:uppercase; letter-spacing:.10em; font-weight:900; color:#8093ae !important; }

/* Pipeline cards */
.stage-card {
  border:1px solid #263650; border-radius:16px; padding:12px 13px; background:#131f33; min-height:96px;
  box-shadow:0 7px 18px rgba(0,0,0,.16);
}
.stage-card-active { border-color:#466b99; background:linear-gradient(180deg,#18304a,#14263d); }
.stage-dot { width:9px; height:9px; border-radius:50%; display:inline-block; margin-right:.3rem; }
.stage-dot.green { background:#42d392; box-shadow:0 0 0 4px rgba(66,211,146,.10); }
.stage-dot.blue { background:#69b7ff; box-shadow:0 0 0 4px rgba(105,183,255,.10); }
.stage-dot.gray { background:#64758e; }
.stage-name { font-weight:900; font-size:.79rem; margin-top:6px; color:#e7effb !important; }
.stage-status { font-size:.69rem; color:#8a9ab2 !important; margin-top:4px; line-height:1.35; }

/* State banners */
.status-card { border-radius:16px; padding:14px 16px; border:1px solid #2a3a52; background:#141f32; }
.status-card.amber { border-color:#6f5626; background:linear-gradient(135deg,#2a2417,#211d15); }
.status-card.green { border-color:#255b47; background:linear-gradient(135deg,#132c25,#12251f); }
.status-card.red { border-color:#67353b; background:linear-gradient(135deg,#2a1a20,#22171c); }
.status-card.navy { border-color:#304766; background:linear-gradient(135deg,#15253c,#111e31); }
.status-title { font-weight:950; color:#eef4ff !important; }
.status-copy { margin-top:.20rem; font-size:.78rem; line-height:1.45; color:#a5b3c6 !important; }
.pill {
  display:inline-block; padding:.24rem .50rem; border-radius:999px; background:#1b2940; color:#a9bad0;
  border:1px solid #2c405f; margin-right:.20rem; margin-bottom:.22rem; font-size:.67rem; font-weight:850;
}

/* Customer profile + operator status */
.operator-status {
  display:grid; grid-template-columns:1.1fr 1fr 1.1fr 1.15fr 1.45fr 1.1fr;
  gap:0; border:1px solid #2c3d58; border-radius:17px; overflow:hidden;
  background:#0e182a; box-shadow:0 10px 28px rgba(0,0,0,.22); margin:0 0 18px;
}
.operator-status-item { padding:12px 14px; border-right:1px solid #263650; min-width:0; }
.operator-status-item:last-child { border-right:0; }
.operator-status-label { color:#7186a4; font-size:.61rem; text-transform:uppercase; letter-spacing:.10em; font-weight:900; }
.operator-status-value { color:#f2f7ff; font-size:.82rem; font-weight:900; margin-top:3px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.operator-status-value.running { color:#72dfff; }
.operator-status-value.green { color:#6ee2aa; }
.operator-status-value.amber { color:#ffd275; }

.profile-layout { display:grid; grid-template-columns:1.18fr 2fr; gap:14px; align-items:stretch; }
.profile-identity { min-height:156px; display:flex; flex-direction:column; justify-content:space-between; }
.profile-avatar-lg { width:68px; height:68px; border-radius:20px; display:flex; align-items:center; justify-content:center;
  background:linear-gradient(135deg,#4e8df6,#45d3c2); color:#07111f; font-weight:950; font-size:1.25rem;
  box-shadow:0 12px 28px rgba(69,211,194,.17); }
.profile-name-lg { font-size:1.48rem; line-height:1.05; font-weight:950; color:#f5f9ff !important; margin-top:.55rem; }
.profile-id-lg { color:#8fa1bb !important; font-size:.76rem; margin-top:.28rem; }
.profile-role { color:#b6c4d7 !important; font-size:.77rem; margin-top:.18rem; }
.profile-stats { display:grid; grid-template-columns:repeat(4,1fr); gap:10px; }
.profile-stat { border:1px solid #293b57; border-radius:14px; background:linear-gradient(180deg,#17263c,#121e32); padding:13px 13px 12px; min-height:72px; }
.profile-stat-label { color:#788ca8; text-transform:uppercase; letter-spacing:.09em; font-size:.59rem; font-weight:900; }
.profile-stat-value { color:#edf4ff; font-size:.98rem; font-weight:950; margin-top:7px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.profile-accounts { margin-top:10px; border:1px solid #293b57; border-radius:14px; padding:10px 12px; background:#101b2d; }
.account-chip { display:inline-block; margin:.2rem .28rem .1rem 0; padding:.31rem .52rem; border-radius:8px; background:#172b46; color:#b9dcff; border:1px solid #31557d; font-size:.66rem; font-weight:850; }

/* Debate control-room view */
.debate-summary { display:grid; grid-template-columns:1fr 1fr 1fr 1fr; gap:10px; margin-bottom:13px; }
.debate-summary-card { border:1px solid #2b3d59; border-radius:14px; background:#121f33; padding:12px 13px; }
.debate-summary-label { color:#788da9; font-size:.60rem; text-transform:uppercase; letter-spacing:.10em; font-weight:900; }
.debate-summary-value { color:#eef5ff; font-size:.91rem; font-weight:950; margin-top:5px; }
.debate-vs { display:grid; grid-template-columns:1fr 62px 1fr; gap:12px; align-items:stretch; margin-top:10px; }
.debate-side { border:1px solid #2b3d59; border-radius:18px; padding:17px; background:linear-gradient(180deg,#142238,#101b2d); box-shadow:0 9px 24px rgba(0,0,0,.18); }
.debate-side.left { border-top:4px solid #9aa9bb; }
.debate-side.right { border-top:4px solid #58b8ff; }
.debate-side-title { color:#f0f5fc; font-size:1.02rem; font-weight:950; }
.debate-side-sub { color:#8094af; font-size:.68rem; margin-top:3px; }
.debate-vs-mark { align-self:center; justify-self:center; width:48px; height:48px; border-radius:50%; display:flex; align-items:center; justify-content:center;
  background:#1c2d45; border:1px solid #3a5577; color:#a9c7e8; font-weight:950; font-size:.74rem; box-shadow:0 7px 18px rgba(0,0,0,.18); }
.debate-section-label { margin-top:15px; color:#7890ad; font-size:.61rem; text-transform:uppercase; letter-spacing:.11em; font-weight:900; }
.debate-position { margin-top:7px; padding:11px 12px; border-radius:11px; background:#0d1728; border:1px solid #243650; color:#dbe6f4; font-size:.82rem; line-height:1.48; }
.debate-list { margin:7px 0 0 0; padding-left:1.1rem; color:#bdcbe0; font-size:.78rem; line-height:1.55; }
.debate-list li { margin-bottom:.22rem; }
.debate-compare { margin-top:14px; border:1px solid #2b3d59; border-radius:17px; overflow:hidden; background:#101b2d; }
.debate-compare-head { display:grid; grid-template-columns:1.05fr 1fr 1fr; background:#17263c; border-bottom:1px solid #2b3d59; }
.debate-compare-head > div { padding:10px 12px; color:#9bb1cc; font-size:.62rem; text-transform:uppercase; letter-spacing:.09em; font-weight:900; border-right:1px solid #2b3d59; }
.debate-compare-head > div:last-child { border-right:0; }
.debate-compare-row { display:grid; grid-template-columns:1.05fr 1fr 1fr; border-bottom:1px solid #22334c; }
.debate-compare-row:last-child { border-bottom:0; }
.debate-compare-row > div { padding:11px 12px; border-right:1px solid #22334c; color:#c7d4e6; font-size:.75rem; line-height:1.48; vertical-align:top; }
.debate-compare-row > div:last-child { border-right:0; }
.debate-compare-key { color:#eef4ff !important; font-weight:900; background:#121f33; }
.debate-outcome-grid { display:grid; grid-template-columns:1fr 1fr 1.35fr; gap:12px; margin-top:14px; }
.debate-outcome { border:1px solid #2b3d59; border-radius:16px; background:#121f33; padding:14px; min-height:135px; }
.debate-outcome.consensus { border-top:3px solid #43d392; }
.debate-outcome.disagreement { border-top:3px solid #f0bd57; }
.debate-outcome.conclusion { border-top:3px solid #69b7ff; }
.debate-outcome-title { color:#eaf2fc; font-size:.78rem; font-weight:950; }
.debate-outcome-copy { color:#b9c8db; font-size:.77rem; line-height:1.5; margin-top:.55rem; }

/* Detail / debate / drafting */
.detail-top { display:flex; align-items:flex-start; justify-content:space-between; gap:1rem; }
.detail-title { font-size:1rem; font-weight:950; color:#edf4ff !important; }
.detail-sub { color:#8092ad !important; font-size:.72rem; margin-top:.15rem; }
.badge { display:inline-flex; align-items:center; border-radius:999px; padding:.27rem .55rem; font-size:.67rem; font-weight:900; border:1px solid transparent; }
.badge-green { background:#143226; color:#8fe5ba; border-color:#285b45; }
.badge-blue { background:#142b44; color:#9fd0ff; border-color:#2c5882; }
.badge-amber { background:#342a16; color:#ffd47a; border-color:#665020; }
.badge-red { background:#351a20; color:#ffadad; border-color:#69343c; }
.debate-grid { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
.debate-perspective {
  border:1px solid #2a3a54; border-radius:18px; padding:16px; background:linear-gradient(180deg,#142137,#111c2f);
  box-shadow:var(--shadow); min-height:330px;
}
.debate-perspective.skeptic { border-top:4px solid #8ea0b8; }
.debate-perspective.advocate { border-top:4px solid #69b7ff; }
.debate-label { font-size:.64rem; font-weight:900; text-transform:uppercase; letter-spacing:.10em; color:#7f92ad !important; }
.debate-name { font-size:1rem; font-weight:950; margin-top:.25rem; color:#eef4ff !important; }

.draft-card {
  border:1px solid #2a3a54; border-radius:17px; padding:15px 16px; background:linear-gradient(180deg,#142137,#111c2f);
  box-shadow:0 8px 22px rgba(0,0,0,.16); margin-bottom:11px;
}
.draft-meta { font-size:.65rem; font-weight:900; text-transform:uppercase; color:#8294ad !important; letter-spacing:.08em; }
.draft-message { margin-top:.55rem; padding:12px 13px; border-radius:13px; background:#0f192a; border:1px solid #263650; font-size:.86rem; line-height:1.55; color:#e3ecf9 !important; }

/* HITL */
.hitl-shell {
  border:1px solid #70562a; border-radius:20px; background:linear-gradient(135deg,#302616,#241f16);
  padding:18px; box-shadow:0 14px 30px rgba(0,0,0,.20);
}
.hitl-kicker { font-size:.66rem; text-transform:uppercase; letter-spacing:.12em; font-weight:950; color:#f0bd57 !important; }
.hitl-title { margin-top:.2rem; font-size:1.18rem; font-weight:950; color:#fff0c6 !important; }
.hitl-copy { margin-top:.25rem; color:#d4c29b !important; font-size:.78rem; line-height:1.5; }
.hitl-message { margin-top:.9rem; padding:14px 15px; background:#171a20; border:1px solid #4a422f; border-radius:14px; color:#f1f5fb !important; line-height:1.55; }

/* Inputs / buttons / expanders */
.stButton > button { border-radius:12px; font-weight:900; background:#17253a; color:#dce8f8; border:1px solid #2e425f; }
.stButton > button:hover { border-color:#527baa; color:#fff; }
.stButton > button[kind="primary"] { background:linear-gradient(135deg,#3d7ee0,#319ab4) !important; color:#fff !important; border-color:#579ae7 !important; }
textarea, input { border-radius:12px !important; }
[data-testid="stTextInputRootElement"], [data-testid="stTextArea"] { color:#eef4ff !important; }
[data-baseweb="select"] > div { background:#111c2f !important; border-color:#2a3b56 !important; color:#eef4ff !important; }
[data-testid="stExpander"] { border:1px solid #2a3a54 !important; border-radius:15px !important; background:#121e31 !important; }
[data-testid="stExpander"] summary, [data-testid="stExpander"] summary span { color:#dce6f4 !important; }
div[data-testid="stAlert"] { border-radius:14px !important; }
[data-testid="stDataFrame"] { border-radius:15px; overflow:hidden; border:1px solid #2a3a54; }

/* Inline HTML used inside the cards */
.debate-perspective div, .debate-perspective li, .draft-card div { color:#cbd7e7; }

footer { visibility:hidden; }

@media (max-width: 900px) {
  .operator-status { grid-template-columns:1fr 1fr; }
  .operator-status-item { border-bottom:1px solid #263650; }
  .profile-layout { grid-template-columns:1fr; }
  .profile-stats { grid-template-columns:1fr 1fr; }
  .debate-vs { grid-template-columns:1fr; }
  .debate-vs-mark { display:none; }
  .debate-compare-head, .debate-compare-row { grid-template-columns:1fr; }
  .debate-compare-head > div, .debate-compare-row > div { border-right:0; border-bottom:1px solid #22334c; }
  .debate-outcome-grid { grid-template-columns:1fr; }
  .hero-title { font-size:1.75rem; }
  .debate-grid { grid-template-columns:1fr; }
}
</style>
""",
    unsafe_allow_html=True,
)

# -----------------------------------------------------------------------------
# HELPERS
# -----------------------------------------------------------------------------
def esc(value: Any) -> str:
    return html.escape(str(value))


def load_jsonl(path: Path | None) -> list[dict[str, Any]]:
    if not path or not path.exists():
        return []
    rows: list[dict[str, Any]] = []
    try:
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            if line.strip():
                try:
                    value = json.loads(line)
                    if isinstance(value, dict):
                        rows.append(value)
                except json.JSONDecodeError:
                    pass
    except OSError:
        pass
    return rows


def latest_file(path: Path, pattern: str) -> Path | None:
    if not path.exists():
        return None
    files = [p for p in path.glob(pattern) if p.is_file()]
    return max(files, key=lambda p: p.stat().st_mtime) if files else None


def artifact_paths(scenario: str) -> dict[str, Path | None]:
    trace_dir = OUTPUT_DIR / f"{scenario}_traces"
    return {
        "status": OUTPUT_DIR / f"{scenario}_run_status.json",
        "evaluation": OUTPUT_DIR / f"{scenario}_evaluation.json",
        "inferred": OUTPUT_DIR / f"{scenario}_inferred_events.jsonl",
        "audit": OUTPUT_DIR / f"{scenario}_hitl_audit.jsonl",
        "request": OUTPUT_DIR / f"{scenario}_hitl_request.json",
        "response": OUTPUT_DIR / f"{scenario}_hitl_response.json",
        "trace": latest_file(trace_dir, "*.jsonl"),
        "trace_dir": trace_dir,
        "log": OUTPUT_DIR / f"{scenario}_ui_run.log",
    }


def extract_trace(records: list[dict[str, Any]], stage: str, event: str, first: bool = False) -> Any:
    matches = [r.get("data") for r in records if r.get("stage") == stage and r.get("event") == event]
    if not matches:
        return None
    return matches[0] if first else matches[-1]


def trace_stage(records: list[dict[str, Any]], stage: str) -> list[dict[str, Any]]:
    return [r for r in records if r.get("stage") == stage]


def process_running(scenario: str) -> bool:
    proc = st.session_state.processes.get(scenario)
    return proc is not None and proc.poll() is None


def cleanup_finished() -> None:
    for scenario in list(st.session_state.processes):
        proc = st.session_state.processes[scenario]
        if proc.poll() is not None:
            handle = st.session_state.log_handles.pop(scenario, None)
            if handle:
                handle.close()


def status_label(status: dict[str, Any]) -> tuple[str, str]:
    value = str(status.get("status", "idle") or "idle").lower()
    if value in {"completed", "complete", "success"}:
        return "COMPLETE", "green"
    if value in {"running", "started", "in_progress"}:
        return "RUNNING", "blue"
    if value in {"failed", "error", "hard_stop"}:
        return "ATTENTION", "red"
    return "IDLE", ""


def format_percent(value: Any) -> str:
    if isinstance(value, (int, float)):
        return f"{value * 100:.1f}%"
    return "—"


def metric_or_dash(mapping: dict[str, Any], key: str) -> Any:
    value = mapping.get(key)
    return "—" if value is None or value == "" else value


def initials(name: str) -> str:
    parts = [p for p in str(name).split() if p]
    if not parts:
        return "CU"
    return (parts[0][0] + (parts[-1][0] if len(parts) > 1 else "")).upper()[:2]

# -----------------------------------------------------------------------------
# RUNTIME CONTROL
# -----------------------------------------------------------------------------
def start_scenario(scenario: str, checkpoint_interval: int, ui_hitl: bool, instructions: dict[str, str]) -> str:
    if process_running(scenario):
        return f"{scenario} is already running."
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    log_path = OUTPUT_DIR / f"{scenario}_ui_run.log"
    handle = open(log_path, "a", encoding="utf-8")
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    for key, value in instructions.items():
        if value.strip():
            env[key] = value.strip()

    cmd = [
        sys.executable,
        "main.py",
        "--scenario",
        scenario,
        "--checkpoint-interval",
        str(checkpoint_interval),
    ]
    if ui_hitl:
        cmd.append("--ui-hitl")

    try:
        proc = subprocess.Popen(
            cmd,
            cwd=BASE_DIR,
            stdout=handle,
            stderr=subprocess.STDOUT,
            env=env,
            text=True,
        )
    except OSError as exc:
        handle.close()
        return f"Could not start {scenario}: {exc}"

    st.session_state.processes[scenario] = proc
    st.session_state.log_handles[scenario] = handle
    return f"Started {scenario} · PID {proc.pid}"


def submit_hitl(scenario: str, request_id: str, choice: str, final_message: str = "") -> None:
    path = artifact_paths(scenario)["response"]
    if path is None:
        raise RuntimeError(f"HITL response path is unavailable for {scenario}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            {
                "request_id": request_id,
                "choice": choice,
                "final_message": final_message,
            },
            indent=2,
        ),
        encoding="utf-8",
    )


def customer_profile(scenario: str) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    package = load_scenario_metadata(BASE_DIR / scenario)
    entities = package.get("entities", {})
    if not isinstance(entities, dict):
        return {}, []

    raw_customer = entities.get("customer")
    if isinstance(raw_customer, dict):
        customer = dict(raw_customer)
    elif isinstance(entities.get("customers"), list) and entities["customers"]:
        customer = dict(entities["customers"][0])
    else:
        customer = dict(entities.get("profile") or {})
        if entities.get("customer_id"):
            customer["customer_id"] = entities.get("customer_id")
        if entities.get("accounts"):
            customer["accounts"] = entities.get("accounts")

    nested_profile = entities.get("profile")
    if isinstance(nested_profile, dict) and nested_profile is not customer:
        for key, value in nested_profile.items():
            customer.setdefault(key, value)

    accounts = customer.get("accounts") or entities.get("accounts") or []
    return customer, accounts if isinstance(accounts, list) else []


def load_json_optional(path: Path | None) -> dict[str, Any]:
    """Read an optional JSON artifact without passing None to config.load_json."""
    if path is None or not path.exists():
        return {}
    value = load_json(path)
    return value if isinstance(value, dict) else {}


def run_data(scenario: str) -> dict[str, Any]:
    paths = artifact_paths(scenario)
    return {
        "status": load_json_optional(paths["status"]),
        "evaluation": load_json_optional(paths["evaluation"]),
        "inferred": load_jsonl(paths["inferred"]),
        "audit": load_jsonl(paths["audit"]),
        "trace": load_jsonl(paths["trace"]),
        "hitl_request": load_json_optional(paths["request"]),
    }

# -----------------------------------------------------------------------------
# REUSABLE UI
# -----------------------------------------------------------------------------
def section(title: str, caption: str | None = None) -> None:
    right = f'<div class="section-caption">{esc(caption)}</div>' if caption else ""
    st.markdown(
        f'<div class="section-head"><div class="section-title">{esc(title)}</div>{right}</div>',
        unsafe_allow_html=True,
    )


def current_objects(data: dict[str, Any]) -> dict[str, Any]:
    trace = data["trace"]
    latest = data["inferred"][-1] if data["inferred"] else {}
    return {
        "latest": latest,
        "specialists": extract_trace(trace, "specialists", "findings") or [],
        "signals": extract_trace(trace, "synthesis", "correlated_signals") or [],
        "life": extract_trace(trace, "life_event", "inference_result") or {},
        "conflict": extract_trace(trace, "conflict", "detection") or {},
        "debate": extract_trace(trace, "debate", "resolution") or {},
        "decision": extract_trace(trace, "decision", "decision_result") or {},
        "offer": extract_trace(trace, "offer", "eligibility_result") or {},
        "action_proposal": extract_trace(trace, "action", "proposal") or {},
        "drafts": extract_trace(trace, "drafting", "drafts") or [],
        "critiques": extract_trace(trace, "critique", "results") or [],
        "guardrail": extract_trace(trace, "guardrail", "result") or {},
        "execution": extract_trace(trace, "execution", "result") or {},
    }


def render_hero(scenario: str, data: dict[str, Any]) -> None:
    profile, _ = customer_profile(scenario)
    status = data["status"] or {}
    latest = data["inferred"][-1] if data["inferred"] else {}
    evaluation = data["evaluation"] or {}
    label, klass = status_label(status)
    name = profile.get("name") or profile.get("full_name") or "Customer"
    customer_id = profile.get("customer_id") or latest.get("customer_id") or "Unknown customer"
    state = latest.get("inferred_state") or "Awaiting inference"
    action = latest.get("action") or "no_action"
    score = evaluation.get("checkpoint_metrics", {}).get("complete_checkpoint_accuracy")

    st.markdown(
        f"""
        <div class="hero">
          <div class="hero-kicker">Agentic AI 360 · Operator Console</div>
          <div class="hero-title">Proactive Intervention Desk</div>
          <div class="hero-subtitle">
            Monitor the customer state, follow the evidence and reasoning path, inspect the actual agent debate, review action proposals,
            and intervene at the human-approval boundary — with each layer separated into a deliberate operator tab.
          </div>
          <div class="hero-meta">
            <span class="hero-chip {klass}">● {esc(label)}</span>
            <span class="hero-chip blue">Customer · {esc(customer_id)}</span>
            <span class="hero-chip">Profile · {esc(name)}</span>
            <span class="hero-chip">State · {esc(state)}</span>
            <span class="hero-chip">Action · {esc(action)}</span>
            {f'<span class="hero-chip green">Evaluation · {format_percent(score)}</span>' if isinstance(score, (int, float)) else ''}
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_profile(scenario: str, data: dict[str, Any]) -> None:
    profile, accounts = customer_profile(scenario)
    latest = data["inferred"][-1] if data["inferred"] else {}
    customer_id = profile.get("customer_id") or latest.get("customer_id") or "Unknown"
    name = profile.get("name") or profile.get("full_name") or "Customer"
    tier = profile.get("customer_value_tier", profile.get("tier", "—"))
    occupation = profile.get("occupation") or profile.get("profession") or "Customer profile"

    account_values: list[str] = []
    for account in accounts:
        if isinstance(account, dict):
            account_id = account.get("account_id") or account.get("id") or account.get("type") or str(account)
            account_values.append(str(account_id))
        else:
            account_values.append(str(account))

    st.markdown(
        f"""
        <div class="profile-layout">
          <div class="profile-card profile-identity">
            <div>
              <div style="display:flex;align-items:center;gap:15px;">
                <div class="profile-avatar-lg">{esc(initials(name))}</div>
                <div>
                  <div class="small-label">Customer profile</div>
                  <div class="profile-name-lg">{esc(name)}</div>
                  <div class="profile-id-lg">{esc(customer_id)}</div>
                  <div class="profile-role">{esc(occupation)}</div>
                </div>
              </div>
            </div>
            <div style="display:flex;gap:7px;flex-wrap:wrap;margin-top:13px;">
              <span class="profile-tag">Value tier · {esc(tier)}</span>
              <span class="profile-tag">Customer 360</span>
            </div>
          </div>
          <div class="profile-card">
            <div class="small-label" style="margin-bottom:9px;">Customer snapshot</div>
            <div class="profile-stats">
              <div class="profile-stat"><div class="profile-stat-label">Age</div><div class="profile-stat-value">{esc(profile.get("age", "—"))}</div></div>
              <div class="profile-stat"><div class="profile-stat-label">Value tier</div><div class="profile-stat-value">{esc(tier)}</div></div>
              <div class="profile-stat"><div class="profile-stat-label">Tenure</div><div class="profile-stat-value">{esc(f'{profile.get("tenure_months")} months' if profile.get("tenure_months") is not None else "—")}</div></div>
              <div class="profile-stat"><div class="profile-stat-label">Dependents</div><div class="profile-stat-value">{esc(profile.get("dependents", "—"))}</div></div>
            </div>
            <div class="profile-accounts">
              <div class="profile-stat-label">Accounts</div>
              <div style="margin-top:4px;">
                {''.join(f'<span class="account-chip">{esc(v)}</span>' for v in account_values) or '<span style="color:#8092ad;font-size:.72rem;">No account metadata</span>'}
              </div>
            </div>
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_operator_status(scenario: str, data: dict[str, Any]) -> None:
    profile, _ = customer_profile(scenario)
    status = data["status"] or {}
    latest = data["inferred"][-1] if data["inferred"] else {}
    evaluation = data["evaluation"] or {}
    score = evaluation.get("checkpoint_metrics", {}).get("complete_checkpoint_accuracy")
    label, klass = status_label(status)
    name = profile.get("name") or profile.get("full_name") or "Customer"
    customer_id = profile.get("customer_id") or latest.get("customer_id") or "Unknown"
    state = latest.get("inferred_state") or "—"
    action = latest.get("action") or "no_action"
    status_class = "running" if klass == "blue" else ("green" if klass == "green" else ("amber" if klass == "amber" else ""))
    score_text = format_percent(score) if isinstance(score, (int, float)) else "—"
    st.markdown(
        f"""
        <div class="operator-status">
          <div class="operator-status-item"><div class="operator-status-label">Run</div><div class="operator-status-value {status_class}">● {esc(label)}</div></div>
          <div class="operator-status-item"><div class="operator-status-label">Customer</div><div class="operator-status-value">{esc(customer_id)}</div></div>
          <div class="operator-status-item"><div class="operator-status-label">Profile</div><div class="operator-status-value">{esc(name)}</div></div>
          <div class="operator-status-item"><div class="operator-status-label">State</div><div class="operator-status-value">{esc(state)}</div></div>
          <div class="operator-status-item"><div class="operator-status-label">Action</div><div class="operator-status-value">{esc(action)}</div></div>
          <div class="operator-status-item"><div class="operator-status-label">Evaluation</div><div class="operator-status-value green">{esc(score_text)}</div></div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_run_health(data: dict[str, Any]) -> None:
    status = data["status"] or {}
    trace = data["trace"]
    evaluation = data["evaluation"] or {}
    provider = evaluation.get("provider", {}) if isinstance(evaluation, dict) else {}
    metrics = evaluation.get("checkpoint_metrics", {}) if isinstance(evaluation, dict) else {}

    section("Run health", "Runtime facts only")
    cols = st.columns(6)
    cols[0].metric("Accepted events", status.get("accepted_events", len(trace)))
    cols[1].metric("Checkpoints", status.get("inference_checkpoints", len(data["inferred"])))
    cols[2].metric("Duplicates", status.get("duplicate_events", 0))
    cols[3].metric("Late", status.get("late_events", 0))
    cols[4].metric("Provider attempts", provider.get("provider_attempts", "—"))
    cols[5].metric("Complete checkpoint", format_percent(metrics.get("complete_checkpoint_accuracy")))


def render_stage_strip(data: dict[str, Any]) -> None:
    trace = data["trace"]
    debate = extract_trace(trace, "debate", "resolution") or {}
    decision = extract_trace(trace, "decision", "decision_result") or {}
    guardrail = extract_trace(trace, "guardrail", "result") or {}
    execution = extract_trace(trace, "execution", "result") or {}

    stages = [
        ("Specialists", "specialists", bool(trace_stage(trace, "specialists"))),
        ("Synthesis", "synthesis", bool(trace_stage(trace, "synthesis"))),
        ("Life-event", "life_event", bool(trace_stage(trace, "life_event"))),
        ("Debate", "debate", bool(trace_stage(trace, "debate"))),
        ("Decision", "decision", bool(trace_stage(trace, "decision"))),
        ("Offer / action", "offer", bool(trace_stage(trace, "offer") or trace_stage(trace, "action"))),
        ("Draft / critique", "drafting", bool(trace_stage(trace, "drafting") or trace_stage(trace, "critique"))),
        ("Guardrail / HITL", "guardrail", bool(trace_stage(trace, "guardrail"))),
        ("Execution", "execution", bool(trace_stage(trace, "execution"))),
    ]

    section("Pipeline state", "The latest observed path")
    cols = st.columns(len(stages))
    for col, (name, key, seen) in zip(cols, stages):
        status_text = "Observed" if seen else "Waiting"
        if key == "debate" and seen and debate.get("conflict_detected") is False:
            status_text = "Skipped · no conflict"
        elif key == "decision" and decision:
            status_text = str(decision.get("action") or "Recorded")
        elif key == "guardrail" and guardrail:
            status_text = str(guardrail.get("decision") or "Recorded")
        elif key == "execution" and execution:
            status_text = str(execution.get("execution_status") or "Recorded")
        with col:
            dot = "green" if seen else "gray"
            st.markdown(
                f'<div class="stage-card {"stage-card-active" if seen else ""}">'
                f'<div class="small-label"><span class="stage-dot {dot}"></span>{esc(key)}</div>'
                f'<div class="stage-name">{esc(name)}</div>'
                f'<div class="stage-status">{esc(status_text)}</div></div>',
                unsafe_allow_html=True,
            )


def render_action_banner(data: dict[str, Any]) -> None:
    o = current_objects(data)
    latest = o["latest"]
    guardrail = o["guardrail"]
    execution = o["execution"]
    action = latest.get("action") or "no_action"
    hitl = latest.get("hitl_status") or guardrail.get("hitl_status") or "—"
    exec_status = execution.get("execution_status", "—")

    if hitl == "escalated" and action != "no_action":
        st.markdown(
            f"""
            <div class="status-card amber">
              <div class="status-title">Human review required</div>
              <div class="status-copy">
                <b>{esc(action)}</b> is waiting at the approval boundary. Execution status: <b>{esc(exec_status)}</b>.
                Open <b>Decision & HITL</b> to inspect the reason and respond.
              </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    elif action == "no_action":
        st.markdown(
            '<div class="status-card green"><div class="status-title">No customer-facing action</div>'
            '<div class="status-copy">The current checkpoint is recorded without an outbound intervention.</div></div>',
            unsafe_allow_html=True,
        )
    else:
        st.markdown(
            f'<div class="status-card navy"><div class="status-title">Action state · {esc(action)}</div>'
            f'<div class="status-copy">HITL={esc(hitl)} · execution={esc(exec_status)}.</div></div>',
            unsafe_allow_html=True,
        )


def render_overview(scenario: str, data: dict[str, Any]) -> None:
    o = current_objects(data)
    latest = o["latest"]

    render_run_health(data)
    render_action_banner(data)
    st.write("")

    section("Current customer state", "Latest checkpoint · decision-oriented summary")
    cols = st.columns(5)
    cols[0].metric("Inferred state", metric_or_dash(latest, "inferred_state"))
    cols[1].metric("Confidence", f"{latest.get('confidence', 0):.2f}" if latest.get("confidence") is not None else "—")
    cols[2].metric("Band", metric_or_dash(latest, "confidence_band"))
    cols[3].metric("Action", metric_or_dash(latest, "action"))
    cols[4].metric("HITL", metric_or_dash(latest, "hitl_status"))

    render_stage_strip(data)

    left, right = st.columns([1.05, .95])
    with left:
        section("Why this checkpoint exists")
        with st.container(border=True):
            st.markdown("**Trigger**")
            st.write(latest.get("trigger_reasons") or latest.get("trigger_reason") or "Recorded in inferred-event artifact.")
            st.markdown("**Inference summary**")
            st.write(latest.get("reason") or "No summary recorded.")
            if latest.get("source_event_ids"):
                st.caption("Source events: " + ", ".join(map(str, latest.get("source_event_ids", [])[:8])))
    with right:
        section("Decision snapshot")
        with st.container(border=True):
            decision = o["decision"]
            offer = o["offer"]
            guardrail = o["guardrail"]
            st.markdown(f"**Selected action** · `{decision.get('action', latest.get('action', '—'))}`")
            st.caption(f"Subtype · {decision.get('action_subtype') or latest.get('action_subtype') or '—'}")
            st.markdown(f"**Offer / eligibility** · `{offer.get('eligibility', '—')}`")
            st.markdown(f"**Guardrail** · `{guardrail.get('decision', '—')}`")

    section("Inference timeline", "Compact checkpoint view")
    inferred = data["inferred"]
    if inferred:
        rows = []
        for i, row in enumerate(inferred, 1):
            rows.append(
                {
                    "#": i,
                    "As-of": row.get("as_of_time"),
                    "State": row.get("inferred_state"),
                    "Conf.": row.get("confidence"),
                    "Band": row.get("confidence_band"),
                    "Action": row.get("action"),
                    "HITL": row.get("hitl_status"),
                }
            )
        st.dataframe(rows, use_container_width=True, hide_index=True, height=min(360, 90 + 42 * len(rows)))
    else:
        st.info("No inference checkpoints yet.")


def _debate_items(value: Any, limit: int = 5) -> list[str]:
    if not isinstance(value, list):
        return []
    return [str(x) for x in value if str(x).strip()][:limit]


def _joined(items: list[str], empty: str = "No point recorded.") -> str:
    return "<br>".join(f"• {esc(x)}" for x in items) if items else esc(empty)


def render_reasoning(data: dict[str, Any]) -> None:
    o = current_objects(data)
    section("Agent reasoning", "Inspect the evidence chain, conflict and the actual arbitration discussion")

    c1, c2 = st.columns(2)
    with c1:
        st.markdown('<div class="detail-card"><div class="detail-top"><div><div class="detail-title">Specialist swarm</div><div class="detail-sub">Parallel source-specific findings</div></div><span class="badge badge-blue">4 agents</span></div>', unsafe_allow_html=True)
        specialists = o["specialists"]
        if specialists:
            st.dataframe([
                {"Agent": x.get("agent_name"), "Signal": x.get("signal_type"), "Severity": x.get("severity"), "Conf.": x.get("confidence"), "Direction": x.get("direction")} for x in specialists
            ], use_container_width=True, hide_index=True)
        else:
            st.caption("No specialist trace available yet.")
        st.markdown('</div>', unsafe_allow_html=True)

    with c2:
        life = o["life"]
        provider = life.get("provider", "runtime") if isinstance(life, dict) else "runtime"
        st.markdown(f'<div class="detail-card"><div class="detail-top"><div><div class="detail-title">Life-event inference</div><div class="detail-sub">Cross-signal interpretation before arbitration</div></div><span class="badge badge-green">{esc(provider)}</span></div>', unsafe_allow_html=True)
        if life:
            st.metric("State", life.get("inferred_state", "—"))
            cols = st.columns(2)
            cols[0].metric("Confidence", life.get("confidence", "—"))
            cols[1].metric("Band", life.get("confidence_band", "—"))
            if life.get("reason"):
                st.write(life.get("reason"))
        else:
            st.caption("No life-event inference trace yet.")
        st.markdown('</div>', unsafe_allow_html=True)

    section("Conflict & debate", "A visible two-sided discussion — arguments, counterpoints, evidence, disagreement, consensus and arbiter conclusion")
    debate = o["debate"]
    conflict = o["conflict"]
    if not debate:
        st.info("No debate record yet.")
        return

    perspectives = debate.get("perspectives", []) or []
    positions = debate.get("positions", []) or []
    disagreements = _debate_items(debate.get("disagreements"), 6)
    consensus = _debate_items(debate.get("consensus"), 6)
    resolution_evidence = _debate_items(debate.get("resolution_evidence"), 8)

    st.markdown(
        f"""
        <div class="debate-summary">
          <div class="debate-summary-card"><div class="debate-summary-label">Conflict</div><div class="debate-summary-value">{'Detected' if debate.get('conflict_detected') else 'None'}</div></div>
          <div class="debate-summary-card"><div class="debate-summary-label">Compared agents</div><div class="debate-summary-value">{esc(', '.join(map(str, debate.get('participating_agents', []) or [])) or '—')}</div></div>
          <div class="debate-summary-card"><div class="debate-summary-label">Resolution</div><div class="debate-summary-value">{esc(debate.get('resolution_status', '—'))}</div></div>
          <div class="debate-summary-card"><div class="debate-summary-label">Resolved state</div><div class="debate-summary-value">{esc(debate.get('resolved_state', '—'))} · {esc(debate.get('confidence', '—'))}</div></div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    if conflict:
        st.markdown(
            f'<div class="status-card navy"><div class="status-title">Why did the agents disagree?</div><div class="status-copy">{esc(conflict.get("explanation", "Material disagreement was detected."))}</div></div>',
            unsafe_allow_html=True,
        )

    # Actual two-sided debate
    if perspectives:
        sides = perspectives[:2]
        while len(sides) < 2:
            sides.append({})
        left, right = sides[0], sides[1]
        left_args, right_args = _debate_items(left.get("arguments")), _debate_items(right.get("arguments"))
        left_cp, right_cp = _debate_items(left.get("counterpoints")), _debate_items(right.get("counterpoints"))
        left_ev, right_ev = _debate_items(left.get("evidence")), _debate_items(right.get("evidence"))
        st.markdown(
            f"""
            <div class="debate-vs">
              <div class="debate-side left">
                <div class="debate-side-title">{esc(left.get('perspective_name','Perspective 1'))}</div>
                <div class="debate-side-sub">Position / interpretation</div>
                <div class="debate-section-label">Position</div><div class="debate-position">{esc(left.get('position','—'))}</div>
                <div class="debate-section-label">Arguments</div><ul class="debate-list">{''.join(f'<li>{esc(x)}</li>' for x in left_args) or '<li>No arguments recorded.</li>'}</ul>
                <div class="debate-section-label">Counterpoints</div><ul class="debate-list">{''.join(f'<li>{esc(x)}</li>' for x in left_cp) or '<li>No counterpoints recorded.</li>'}</ul>
                <div class="debate-section-label">Evidence used</div><ul class="debate-list">{''.join(f'<li>{esc(x)}</li>' for x in left_ev) or '<li>No evidence recorded.</li>'}</ul>
              </div>
              <div class="debate-vs-mark">VS</div>
              <div class="debate-side right">
                <div class="debate-side-title">{esc(right.get('perspective_name','Perspective 2'))}</div>
                <div class="debate-side-sub">Position / interpretation</div>
                <div class="debate-section-label">Position</div><div class="debate-position">{esc(right.get('position','—'))}</div>
                <div class="debate-section-label">Arguments</div><ul class="debate-list">{''.join(f'<li>{esc(x)}</li>' for x in right_args) or '<li>No arguments recorded.</li>'}</ul>
                <div class="debate-section-label">Counterpoints</div><ul class="debate-list">{''.join(f'<li>{esc(x)}</li>' for x in right_cp) or '<li>No counterpoints recorded.</li>'}</ul>
                <div class="debate-section-label">Evidence used</div><ul class="debate-list">{''.join(f'<li>{esc(x)}</li>' for x in right_ev) or '<li>No evidence recorded.</li>'}</ul>
              </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        # Point-by-point comparison, using the actual debate fields rather than inventing criteria.
        rows = [
            ("Position", [str(left.get("position", "—"))], [str(right.get("position", "—"))]),
            ("Arguments", left_args, right_args),
            ("Counterpoints", left_cp, right_cp),
            ("Evidence", left_ev, right_ev),
        ]
        html_rows = []
        for label, a, b in rows:
            html_rows.append(
                f'<div class="debate-compare-row"><div class="debate-compare-key">{esc(label)}</div><div>{_joined(a)}</div><div>{_joined(b)}</div></div>'
            )
        st.markdown(
            f"""
            <div class="debate-compare">
              <div class="debate-compare-head"><div>Debate dimension</div><div>{esc(left.get('perspective_name','Perspective 1'))}</div><div>{esc(right.get('perspective_name','Perspective 2'))}</div></div>
              {''.join(html_rows)}
            </div>
            """,
            unsafe_allow_html=True,
        )

    # Actual agent positions when available
    if positions:
        with st.expander("Specialist positions entering the debate", expanded=False):
            st.dataframe([
                {"Agent": p.get("agent_name"), "Position": p.get("position"), "Key concern": p.get("key_concern"), "Supporting evidence": " · ".join(map(str, p.get("supporting_evidence", [])[:4]))}
                for p in positions
            ], use_container_width=True, hide_index=True)

    out_html = []
    consensus_html = _joined(consensus, "No consensus point recorded.")
    disagreement_html = _joined(disagreements, "No explicit disagreement recorded.")
    evidence_html = _joined(resolution_evidence, "No resolution evidence recorded.")
    out_html.append(f'<div class="debate-outcome disagreement"><div class="debate-outcome-title">⚡ Disagreement</div><div class="debate-outcome-copy">{disagreement_html}</div></div>')
    out_html.append(f'<div class="debate-outcome consensus"><div class="debate-outcome-title">✓ Consensus</div><div class="debate-outcome-copy">{consensus_html}</div></div>')
    out_html.append(f'<div class="debate-outcome conclusion"><div class="debate-outcome-title">◆ Arbiter conclusion</div><div class="debate-outcome-copy">{esc(debate.get("reasoning", "No arbiter reasoning recorded."))}<br><br><b>Resolution evidence</b><br>{evidence_html}</div></div>')
    st.markdown('<div class="debate-outcome-grid">' + ''.join(out_html) + '</div>', unsafe_allow_html=True)

    if debate.get("resolution_status") == "unresolved":
        st.markdown('<div class="status-card amber" style="margin-top:13px;"><div class="status-title">Debate remained unresolved</div><div class="status-copy">The system preserved the disagreement instead of silently forcing a consensus. Downstream policy and HITL controls remain responsible for the final action boundary.</div></div>', unsafe_allow_html=True)


def render_action_hitl(scenario: str, data: dict[str, Any]) -> None:
    o = current_objects(data)
    latest = o["latest"]
    decision = o["decision"]
    offer = o["offer"]
    guardrail = o["guardrail"]
    execution = o["execution"]
    request = data["hitl_request"]

    section("Decision & action", "The operational layer")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Action", latest.get("action", decision.get("action", "—")))
    c2.metric("Subtype", latest.get("action_subtype") or decision.get("action_subtype") or "—")
    c3.metric("Eligibility", offer.get("eligibility", "—"))
    c4.metric("Execution", execution.get("execution_status", "—"))

    left, right = st.columns(2)
    with left:
        with st.container(border=True):
            st.markdown("### Decision rationale")
            st.write(decision.get("rationale", "No decision rationale recorded."))
            st.caption(f"Provider: {decision.get('provider', 'runtime')} · HITL: {latest.get('hitl_status', guardrail.get('hitl_status', '—'))}")
    with right:
        with st.container(border=True):
            st.markdown("### Guardrail outcome")
            st.write(guardrail.get("reason", "No guardrail reason recorded."))
            flags = guardrail.get("flags") or []
            if flags:
                st.markdown(" ".join(f'<span class="pill">{esc(x)}</span>' for x in flags), unsafe_allow_html=True)

    section("HITL checkpoint", "Real approval boundary · response is written to the backend response artifact")
    if not request:
        if latest.get("hitl_status") == "escalated":
            st.markdown(
                '<div class="status-card amber"><div class="status-title">Pending HITL record not found yet</div>'
                '<div class="status-copy">The runtime reports escalation, but the request artifact has not appeared. Refresh after the backend reaches the checkpoint.</div></div>',
                unsafe_allow_html=True,
            )
        else:
            st.markdown(
                '<div class="status-card green"><div class="status-title">No pending human decision</div>'
                '<div class="status-copy">This checkpoint is not waiting for an operator response.</div></div>',
                unsafe_allow_html=True,
            )
        return

    proposed = request.get("proposed_message", "")
    request_id = str(request.get("request_id", ""))
    st.markdown(
        f"""
        <div class="hitl-shell">
          <div class="hitl-top">
            <div>
              <div class="hitl-kicker">Human-in-the-loop</div>
              <div class="hitl-title">Review before execution</div>
              <div class="hitl-copy">Request <b>{esc(request_id)}</b> · Action <b>{esc(request.get('action','—'))}</b> · State <b>{esc(request.get('inferred_state','—'))}</b></div>
            </div>
            <span class="badge badge-amber">ESCALATED</span>
          </div>
          <div class="hitl-message">{esc(proposed or 'No customer message attached.')}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    st.write("")

    with st.container(border=True):
        st.markdown("**Why this reached a human**")
        st.write(request.get("rationale", "No rationale recorded."))
        with st.expander("Approver context", expanded=False):
            st.json(request.get("context", {}))

        a1, a2, a3 = st.columns([1, 1, 2])
        with a1:
            if st.button("Approve action", key=f"approve_{scenario}", use_container_width=True, type="primary"):
                submit_hitl(scenario, request_id, "approve", proposed)
                st.success("Approval response written. Refresh while the backend is waiting.")
        with a2:
            if st.button("Reject action", key=f"reject_{scenario}", use_container_width=True):
                submit_hitl(scenario, request_id, "reject", proposed)
                st.warning("Rejection response written. Refresh while the backend consumes it.")
        with a3:
            modified = st.text_area(
                "Operator modification",
                value=proposed,
                height=96,
                key=f"modify_text_{scenario}",
                placeholder="Enter an approved replacement message…",
                label_visibility="visible",
            ) or ""
            if st.button("Submit modification", key=f"modify_{scenario}", use_container_width=True):
                if modified.strip():
                    submit_hitl(scenario, request_id, "modify", modified.strip())
                    st.success("Modified response written. Refresh while the backend is waiting.")
                else:
                    st.error("Modified message cannot be empty.")


def render_drafting(data: dict[str, Any]) -> None:
    o = current_objects(data)
    section("Drafting & compliance", "Dedicated workspace for the customer-facing artifact")

    drafts = o["drafts"]
    critiques = o["critiques"]

    if not drafts:
        st.info("No customer-facing drafts in the latest run.")
    else:
        for draft in drafts:
            st.markdown(
                f"""
                <div class="draft-card">
                  <div class="draft-meta">Round {esc(draft.get('round_number','—'))} · {esc(draft.get('agent_name','agent'))} · {esc(draft.get('draft_status','draft'))}</div>
                  <div class="draft-message">{esc(draft.get('message',''))}</div>
                  <div style="margin-top:.6rem;color:#93a2b7;font-size:.71rem;line-height:1.45;">{esc(draft.get('revision_notes',''))}</div>
                </div>
                """,
                unsafe_allow_html=True,
            )

    if critiques:
        section("Compliance review", "Reviewer perspectives for the final draft")
        for result in critiques:
            status = str(result.get("status", "unknown"))
            status_class = "badge-green" if status == "approved" else "badge-amber" if status == "needs_revision" else "badge-red"
            st.markdown(
                f'<span class="badge {status_class}">{esc(result.get("draft_id", "draft"))} · {esc(status)}</span>',
                unsafe_allow_html=True,
            )
            with st.expander(f"Review details · {result.get('draft_id','draft')}"):
                assessments = result.get("reviewer_assessments", [])
                if assessments:
                    st.dataframe(
                        [
                            {"Reviewer": a.get("reviewer"), "Verdict": a.get("verdict"), "Issues": " | ".join(a.get("issues", []))}
                            for a in assessments
                        ],
                        use_container_width=True,
                        hide_index=True,
                    )
                if result.get("explanation"):
                    st.write("**Summary**")
                    st.write(result.get("explanation"))
                if result.get("revised_message"):
                    st.write("**Suggested revision**")
                    st.code(result["revised_message"])


def render_evidence_memory(data: dict[str, Any], scenario: str) -> None:
    o = current_objects(data)
    latest = o["latest"]
    evidence = latest.get("evidence", [])
    signals = o["signals"]

    section("Customer context", "Grounding first, memory second")
    left, right = st.columns([1.05, .95])
    with left:
        st.markdown("### Grounding evidence")
        for item in evidence or ["No evidence recorded."]:
            st.write("•", item)
        st.caption("Source event IDs")
        st.code(", ".join(map(str, latest.get("source_event_ids", []))) or "None")
        if signals:
            st.markdown("### Correlated signals")
            st.dataframe(
                [
                    {"Signal": x.get("signal"), "Confidence": x.get("confidence"), "Events": ", ".join(map(str, x.get("event_ids", [])[:4]))}
                    for x in signals
                ],
                use_container_width=True,
                hide_index=True,
            )
    with right:
        st.markdown("### Latest state record")
        with st.container(border=True):
            st.metric("State", latest.get("inferred_state", "—"))
            cols = st.columns(2)
            cols[0].metric("Action", latest.get("action", "—"))
            cols[1].metric("Confidence", latest.get("confidence", "—"))

        customer_id = latest.get("customer_id")
        if not customer_id:
            profile, _ = customer_profile(scenario)
            customer_id = profile.get("customer_id")
        if customer_id:
            memory_files = sorted(MEMORY_DIR.glob(f"{customer_id}_*_episodic.jsonl"), key=lambda x: x.stat().st_mtime)
            records: list[dict[str, Any]] = []
            for memory_file in memory_files[-4:]:
                records.extend(load_jsonl(memory_file))
            st.markdown("### Episodic memory")
            if records:
                st.dataframe(
                    [
                        {"Timestamp": r.get("timestamp"), "State": r.get("inferred_state"), "Action": r.get("action"), "Outcome": r.get("outcome"), "Conf.": r.get("confidence")}
                        for r in records[-20:]
                    ],
                    use_container_width=True,
                    hide_index=True,
                )
            else:
                st.info("No episodic records yet.")

    with st.expander("Semantic / shared policy memory"):
        semantic = load_json(MEMORY_DIR / "semantic_policy.json")
        st.json(semantic or {"rules": []})


def render_trace_evaluation(data: dict[str, Any], scenario: str) -> None:
    trace = data["trace"]
    paths = artifact_paths(scenario)
    evaluation = data["evaluation"] or {}

    section("Observability", "Trace, provider usage and audit artifacts")
    if not trace:
        st.info("No trace yet.")
    else:
        stage_filter = st.multiselect(
            "Filter trace stages",
            sorted({str(x.get("stage", "unknown")) for x in trace}),
            default=[],
            key=f"trace_filter_{scenario}",
        )
        limit = st.slider("Recent trace rows", 20, min(300, len(trace)), min(120, len(trace)), key=f"trace_rows_{scenario}")
        filtered = [x for x in trace if not stage_filter or x.get("stage") in stage_filter]
        st.dataframe(
            [{"Timestamp": x.get("timestamp"), "Stage": x.get("stage"), "Event": x.get("event")} for x in filtered[-limit:]],
            use_container_width=True,
            hide_index=True,
            height=470,
        )

    if evaluation:
        section("Evaluation", "Practice-scenario ground truth")
        metrics = evaluation.get("checkpoint_metrics", {})
        cols = st.columns(5)
        for col, (label, value) in zip(
            cols,
            [
                ("State", metrics.get("state_accuracy")),
                ("Action", metrics.get("action_accuracy")),
                ("Subtype", metrics.get("subtype_accuracy")),
                ("HITL", metrics.get("hitl_accuracy")),
                ("Complete", metrics.get("complete_checkpoint_accuracy")),
            ],
        ):
            col.metric(label, format_percent(value))
        tm = evaluation.get("trace_metrics", {})
        st.caption(
            f"Trace events={tm.get('trace_events','—')} · handoffs={tm.get('handoff_count','—')} · retrievals={tm.get('retrieval_count','—')} · debates={tm.get('debate_resolution_count','—')} · hard-stops={evaluation.get('hard_stop_queue_count',0)}"
        )
        rows = []
        for i, item in enumerate(evaluation.get("checkpoint_results", []), 1):
            rows.append(
                {
                    "#": i,
                    "As-of": item.get("as_of_time"),
                    "Expected": item.get("expected", {}).get("state"),
                    "Predicted": item.get("predicted", {}).get("inferred_state"),
                    "State": "PASS" if item.get("state_pass") else "FAIL",
                    "Action": "PASS" if item.get("action_pass") else "FAIL",
                    "Complete": "PASS" if item.get("checkpoint_pass") else "FAIL",
                }
            )
        if rows:
            st.dataframe(rows, use_container_width=True, hide_index=True, height=min(440, 100 + 44 * len(rows)))

    with st.expander("Latest structured trace"):
        st.json(trace[-30:] if trace else [])
    if paths["log"] and paths["log"].exists():
        with st.expander("Backend log", expanded=False):
            st.code(paths["log"].read_text(encoding="utf-8", errors="replace")[-16000:])
    if data["audit"]:
        with st.expander("HITL audit"):
            st.dataframe(data["audit"][-30:], use_container_width=True, hide_index=True)


def render_contract(data: dict[str, Any]) -> None:
    section("PS contract", "Runtime artifact validation")
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("**Allowed states**")
        st.code("\n".join(ALLOWED_STATES))
        st.markdown("**Allowed actions**")
        st.code("\n".join(ALLOWED_ACTIONS))
    with c2:
        st.markdown("**HITL states**")
        st.code("\n".join(ALLOWED_HITL))
        st.markdown("**Confidence bands**")
        st.code("\n".join(ALLOWED_CONFIDENCE_BANDS))

    violations = []
    for row in data["inferred"]:
        if row.get("inferred_state") not in ALLOWED_STATES:
            violations.append(f"Invalid state: {row.get('inferred_state')}")
        if row.get("action") not in ALLOWED_ACTIONS:
            violations.append(f"Invalid action: {row.get('action')}")
        if row.get("confidence_band") not in ALLOWED_CONFIDENCE_BANDS:
            violations.append(f"Invalid confidence band: {row.get('confidence_band')}")
        if row.get("hitl_status") not in ALLOWED_HITL:
            violations.append(f"Invalid HITL status: {row.get('hitl_status')}")

    if violations:
        st.markdown(
            f'<div class="status-card red"><div class="status-title">Contract violations</div><div class="status-copy">{esc(" · ".join(violations[:8]))}</div></div>',
            unsafe_allow_html=True,
        )
    else:
        st.markdown(
            '<div class="status-card green"><div class="status-title">Contract healthy</div><div class="status-copy">Recorded inferred-event artifacts comply with the core runtime contract.</div></div>',
            unsafe_allow_html=True,
        )

# -----------------------------------------------------------------------------
# SIDEBAR
# -----------------------------------------------------------------------------
cleanup_finished()
scenarios = [p.name for p in discover_scenarios(BASE_DIR)]

with st.sidebar:
    st.markdown(
        """
        <div class="sidebar-brand">
          <div class="sidebar-brand-top">
            <div class="sidebar-brand-mark">◉</div>
            <div>
              <div class="sidebar-brand-title">Customer 360</div>
              <div class="sidebar-brand-sub">Agentic operator control room</div>
            </div>
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.markdown('<div class="sidebar-section">Run control</div>', unsafe_allow_html=True)
    if scenarios:
        run_selection = st.multiselect(
            "Scenarios to run",
            scenarios,
            default=scenarios[:1],
            help="Run scenarios independently. Each scenario has isolated event, memory, trace, evaluation and HITL artifacts.",
        )
        default_inspect = scenarios.index(run_selection[0]) if run_selection and run_selection[0] in scenarios else 0
        inspect_scenario = st.selectbox("Scenario to inspect", scenarios, index=default_inspect)
    else:
        run_selection = []
        inspect_scenario = st.text_input("Scenario directory")

    checkpoint_interval = st.number_input(
        "Minimum events between inference",
        min_value=20,
        max_value=200,
        value=30,
        help="Backend checkpoint cadence. Lower values show more checkpoints and can use more provider calls.",
    )
    use_ui_hitl = st.checkbox("Enable UI HITL", value=True)

    st.markdown('<div class="sidebar-section">Agent overrides</div>', unsafe_allow_html=True)
    st.text_area("Life-event instruction", height=74, key="life_instruction", placeholder="Optional operator instruction…")
    st.text_area("Decision instruction", height=74, key="decision_instruction", placeholder="Optional operator instruction…")
    st.text_area("Drafting instruction", height=74, key="drafting_instruction", placeholder="Optional operator instruction…")

    if st.button("Run selected scenarios", use_container_width=True, type="primary"):
        instructions = {
            "C360_LIFE_EVENT_INSTRUCTION": st.session_state.get("life_instruction", ""),
            "C360_DECISION_INSTRUCTION": st.session_state.get("decision_instruction", ""),
            "C360_DRAFTING_INSTRUCTION": st.session_state.get("drafting_instruction", ""),
        }
        if not run_selection:
            st.session_state.last_message = "Select at least one scenario."
        else:
            messages = [start_scenario(s, int(checkpoint_interval), use_ui_hitl, instructions) for s in run_selection]
            st.session_state.last_message = " · ".join(messages)

    if st.button("Refresh", use_container_width=True):
        st.rerun()

    if st.session_state.last_message:
        st.caption(st.session_state.last_message)

    st.divider()
    st.markdown(
        '<div class="sidebar-note">The interface only renders backend artifacts: event stream state, agent findings, HITL request/response, trace, memory, evaluation and contract status.</div>',
        unsafe_allow_html=True,
    )

# -----------------------------------------------------------------------------
# MAIN CONTROL ROOM
# -----------------------------------------------------------------------------
def render_control_room() -> None:
    if inspect_scenario not in scenarios:
        st.info("Add a scenario_* directory containing history_seed.jsonl and live_stream.jsonl, then refresh.")
        return

    st.session_state.selected_scenario = inspect_scenario
    data = run_data(inspect_scenario)
    render_hero(inspect_scenario, data)
    render_operator_status(inspect_scenario, data)
    render_profile(inspect_scenario, data)

    package = load_scenario_metadata(BASE_DIR / inspect_scenario)
    replay = package.get("replay", {})
    scenario_id = replay.get("scenario_id")
    scenario_note = package.get("instructions", "").strip()

    top_left, top_right = st.columns([1.45, .55])
    with top_left:
        if process_running(inspect_scenario):
            st.info("Live run detected · refreshes every 2 seconds while the backend process is active.")
    with top_right:
        if scenario_id:
            st.markdown(f'<div style="text-align:right;color:#77849a;font-size:.70rem;">Package · <b>{esc(scenario_id)}</b></div>', unsafe_allow_html=True)

    if scenario_note:
        with st.expander("Scenario context", expanded=False):
            st.write(scenario_note)

    tabs = st.tabs([
        "Overview",
        "Agent reasoning",
        "Decision & HITL",
        "Drafting & compliance",
        "Customer context",
        "Observability",
        "PS contract",
    ])

    with tabs[0]:
        render_overview(inspect_scenario, data)
    with tabs[1]:
        render_reasoning(data)
    with tabs[2]:
        render_action_hitl(inspect_scenario, data)
    with tabs[3]:
        render_drafting(data)
    with tabs[4]:
        render_evidence_memory(data, inspect_scenario)
    with tabs[5]:
        render_trace_evaluation(data, inspect_scenario)
    with tabs[6]:
        render_contract(data)

    status = data["status"] or {}
    st.caption(f"Run status · {status.get('status', 'idle')} · scenario={inspect_scenario}")


if hasattr(st, "fragment"):
    st.fragment(run_every="2s")(render_control_room)()
else:
    render_control_room()
