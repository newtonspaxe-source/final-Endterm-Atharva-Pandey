from __future__ import annotations

import os
import random
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / "api.env", override=False)

try:
    from langchain_groq import ChatGroq  # type: ignore
except ImportError:  # pragma: no cover
    ChatGroq = None  # type: ignore

from json_utils import response_text


class LLMProviderError(RuntimeError):
    pass


class LLMUnavailableError(LLMProviderError):
    pass


class LLMRateLimitError(LLMProviderError):
    pass


class LLMBudgetTimeoutError(LLMProviderError):
    pass


class LLMRunBudgetExceeded(LLMProviderError):
    """Hard per-run provider-call cap; callers must use deterministic fallback."""


class LLMResponseError(LLMProviderError):
    pass


@dataclass(frozen=True)
class LLMRunStats:
    run_id: str
    provider_attempts: int
    estimated_prompt_tokens: int
    calls_by_role: dict[str, int]
    capped: bool

    def as_dict(self) -> dict[str, Any]:
        return {
            "run_id": self.run_id,
            "provider_attempts": self.provider_attempts,
            "estimated_prompt_tokens": self.estimated_prompt_tokens,
            "calls_by_role": dict(self.calls_by_role),
            "capped": self.capped,
        }


ABSOLUTE_MAX_CALLS_PER_RUN = 12
ABSOLUTE_MAX_PROMPT_TOKENS_PER_RUN = 24000
ABSOLUTE_MAX_OUTPUT_TOKENS = 800


class _RunBudget:
    """Process-local hard budget shared by all agents in one scenario replay."""

    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.run_id = "uninitialized"
        self.provider_attempts = 0
        self.estimated_prompt_tokens = 0
        self.calls_by_role: dict[str, int] = defaultdict(int)
        self.capped = False

    def start(self, run_id: str) -> None:
        with self.lock:
            self.run_id = str(run_id)
            self.provider_attempts = 0
            self.estimated_prompt_tokens = 0
            self.calls_by_role = defaultdict(int)
            self.capped = False

    def claim(self, role: str, estimated_tokens: int) -> None:
        cap = configured_call_cap()
        prompt_cap = configured_prompt_token_cap()
        with self.lock:
            if self.provider_attempts >= cap:
                self.capped = True
                raise LLMRunBudgetExceeded(
                    f"Per-run LLM call cap ({cap}) reached; deterministic fallback is required."
                )
            next_prompt_total = self.estimated_prompt_tokens + int(estimated_tokens)
            if next_prompt_total > prompt_cap:
                self.capped = True
                raise LLMRunBudgetExceeded(
                    f"Per-run prompt-token cap ({prompt_cap}) reached; deterministic fallback is required."
                )
            self.provider_attempts += 1
            self.estimated_prompt_tokens = next_prompt_total
            self.calls_by_role[str(role)] += 1

    def stats(self) -> LLMRunStats:
        with self.lock:
            return LLMRunStats(
                run_id=self.run_id,
                provider_attempts=self.provider_attempts,
                estimated_prompt_tokens=self.estimated_prompt_tokens,
                calls_by_role=dict(self.calls_by_role),
                capped=self.capped,
            )


_RUN_BUDGET = _RunBudget()


class _BudgetGate:
    """Rolling request-token budget + inter-call pacing to prevent request storms."""

    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.usage: deque[tuple[float, int]] = deque()
        self.last_call_at = 0.0

    @staticmethod
    def _now() -> float:
        return time.monotonic()

    def reset(self) -> None:
        with self.lock:
            self.usage.clear()
            self.last_call_at = 0.0

    def acquire(self, estimated_tokens: int) -> None:
        # Groq's TPM limit is a rolling one-minute window. The old build used a
        # 2-second timeout here, which meant a perfectly valid Groq request was
        # converted into deterministic fallback as soon as the previous request
        # was still inside the rolling window. Waiting is correct; falling back
        # after two seconds is not.
        # Keep the local limiter below the common 8K free/on-demand envelope.
        # A deployment with a larger quota may raise this, but never above 7.9K
        # through this safety layer unless the code is intentionally changed.
        try:
            configured_tpm = int(os.getenv("C360_LLM_SOFT_TPM", "7000"))
        except ValueError:
            configured_tpm = 7000
        limit = min(7900, max(512, configured_tpm))
        min_gap = max(0.0, float(os.getenv("C360_LLM_MIN_GAP_SECONDS", "0.35")))
        max_wait = max(0.0, float(os.getenv("C360_LLM_BUDGET_MAX_WAIT_SECONDS", "65")))
        if estimated_tokens > limit:
            raise LLMBudgetTimeoutError(
                f"Estimated request size {estimated_tokens} exceeds rolling budget {limit}."
            )
        deadline = self._now() + max_wait
        while True:
            with self.lock:
                now = self._now()
                while self.usage and now - self.usage[0][0] >= 60.0:
                    self.usage.popleft()
                used = sum(tokens for _, tokens in self.usage)
                wait_for = max(0.0, min_gap - (now - self.last_call_at))
                if used + estimated_tokens <= limit and wait_for <= 0:
                    self.usage.append((now, estimated_tokens))
                    self.last_call_at = now
                    return
                if used + estimated_tokens > limit and self.usage:
                    wait_for = max(wait_for, 60.0 - (now - self.usage[0][0]))
            if self._now() + wait_for > deadline:
                raise LLMBudgetTimeoutError(
                    "Provider soft budget gate timeout; deterministic fallback will be used."
                )
            time.sleep(min(max(wait_for, 0.01), 0.25))


_BUDGET = _BudgetGate()


_DEFAULT_STAGE_SET = frozenset({"life_event", "debate", "draft", "critique"})
_STAGE_ALIASES = {
    "drafting": "draft",
    "critique_compliance": "critique",
    "critique-recheck": "critique",
    "life-event": "life_event",
    "life_event_inference": "life_event",
    "debate_arbitration": "debate",
}


def _canonical_role(role: str) -> str:
    key = str(role or "").strip().lower()
    return _STAGE_ALIASES.get(key, key)


def _enabled_stages() -> set[str]:
    raw = os.getenv("C360_LLM_STAGES", "life_event,debate,draft,critique").strip().lower()
    if not raw:
        return set(_DEFAULT_STAGE_SET)
    if raw == "all":
        return {"synthesis", "life_event", "decision", "debate", "draft", "critique"}
    values = set()
    for item in raw.split(","):
        key = item.strip()
        if not key:
            continue
        values.add(_canonical_role(key))
    return values or set(_DEFAULT_STAGE_SET)


def stage_enabled(role: str) -> bool:
    return _canonical_role(role) in _enabled_stages()


def configured_call_cap() -> int:
    try:
        configured = int(os.getenv("C360_LLM_MAX_CALLS_PER_RUN", str(ABSOLUTE_MAX_CALLS_PER_RUN)))
    except ValueError:
        configured = ABSOLUTE_MAX_CALLS_PER_RUN
    return min(ABSOLUTE_MAX_CALLS_PER_RUN, max(1, configured))


def configured_prompt_token_cap() -> int:
    try:
        configured = int(os.getenv("C360_LLM_MAX_PROMPT_TOKENS_PER_RUN", str(ABSOLUTE_MAX_PROMPT_TOKENS_PER_RUN)))
    except ValueError:
        configured = ABSOLUTE_MAX_PROMPT_TOKENS_PER_RUN
    return min(ABSOLUTE_MAX_PROMPT_TOKENS_PER_RUN, max(1024, configured))


def start_llm_run(run_id: str) -> None:
    # A scenario replay is a new accounting window. Never carry the previous
    # scenario's rolling TPM reservations into the next run.
    _RUN_BUDGET.start(run_id)
    _BUDGET.reset()


def llm_run_stats() -> dict[str, Any]:
    return _RUN_BUDGET.stats().as_dict()


def llm_enabled() -> bool:
    mode = os.getenv("C360_LLM_MODE", "auto").strip().lower()
    if mode in {"offline", "none", "disabled"}:
        return False
    return ChatGroq is not None and bool(os.getenv("GROQ_API_KEY", "").strip())


def provider_mode() -> str:
    mode = os.getenv("C360_LLM_MODE", "auto").strip().lower()
    if mode in {"offline", "none", "disabled"}:
        return "offline"
    return "groq" if llm_enabled() else "fallback"


def create_groq_llm(
    role: str,
    default_model: str = "openai/gpt-oss-20b",
    default_temperature: float = 0.0,
):
    role = _canonical_role(role)
    if not stage_enabled(role):
        return None
    if not llm_enabled():
        return None

    model = os.getenv(f"C360_{role.upper()}_MODEL", default_model)
    try:
        temperature = float(
            os.getenv(f"C360_{role.upper()}_TEMPERATURE", str(default_temperature))
        )
    except ValueError:
        temperature = default_temperature
    role_defaults = {
        "synthesis": 450,
        "life_event": 500,
        "decision": 360,
        "debate": 650,
        "critique": 600,
        "draft": 500,
    }
    try:
        max_tokens = max(
            128,
            int(os.getenv(f"C360_{role.upper()}_MAX_TOKENS", str(role_defaults.get(role, 500)))),
        )
    except ValueError:
        max_tokens = role_defaults.get(role, 500)

    try:
        max_tokens = min(ABSOLUTE_MAX_OUTPUT_TOKENS, max_tokens)
        # GPT-OSS is a reasoning model. For our bounded JSON agent stages, keep
        # reasoning effort low and exclude reasoning from the returned message.
        # This prevents the provider adapter from exposing an empty/None final
        # content field when the completion budget is dominated by reasoning.
        reasoning_effort = os.getenv(
            f"C360_{role.upper()}_REASONING_EFFORT", "low"
        ).strip().lower() or "low"
        if reasoning_effort not in {"low", "medium", "high"}:
            reasoning_effort = "low"

        # langchain-groq 0.3.8 exposes reasoning_effort as an explicit
        # ChatGroq field. Passing it inside model_kwargs causes Pydantic
        # validation to fail with "should be specified explicitly".
        # Keep only parameters that are not explicit ChatGroq fields in
        # model_kwargs.
        model_kwargs = {
            "include_reasoning": False,
            # GPT-OSS supports JSON object mode; this gives the parser a valid
            # JSON boundary instead of relying only on prompt instructions.
            "response_format": {"type": "json_object"},
        }
        return ChatGroq(
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
            max_retries=0,
            reasoning_effort=reasoning_effort,
            model_kwargs=model_kwargs,
        )  # type: ignore[misc]
    except Exception as exc:
        print(
            f"[LLM PROVIDER] {role} initialization unavailable; deterministic fallback: "
            f"{type(exc).__name__}: {exc}"
        )
        return None


def estimate_tokens(prompt: str) -> int:
    # Conservative character-based estimate. This is deliberately only a
    # pacing estimate; Groq remains the source of truth for actual usage.
    return max(1, (len(prompt) + 3) // 4)


def _configured_output_tokens(role: str) -> int:
    role = _canonical_role(role)
    defaults = {
        "synthesis": 450,
        "life_event": 500,
        "decision": 360,
        "debate": 650,
        "draft": 500,
        "critique": 600,
    }
    try:
        value = int(os.getenv(f"C360_{role.upper()}_MAX_TOKENS", str(defaults.get(role, 500))))
    except ValueError:
        value = defaults.get(role, 500)
    return min(ABSOLUTE_MAX_OUTPUT_TOKENS, max(128, value))


def _is_retryable(exc: Exception) -> bool:
    text = str(exc).lower()
    permanent = (
        "tokens per day", "tokens per month", "tpd", "tokens/day", "daily limit",
        "tpm limit", "request too large", "413", "quota exceeded", "insufficient quota",
        "invalid api key", "authentication", "401", "403",
    )
    if any(term in text for term in permanent):
        return False
    if isinstance(exc, LLMRunBudgetExceeded):
        return False
    if isinstance(exc, LLMResponseError) and "empty response" in text:
        return True
    retry_words = (
        "rate", "429", "timeout", "timed out", "temporarily", "503", "502", "504",
        "connection", "overloaded", "unavailable", "server error", "reset",
    )
    return any(word in text for word in retry_words) or any(
        word in type(exc).__name__.lower() for word in ("rate", "timeout", "connect")
    )


def invoke(llm: Any, prompt: str, role: str) -> Any:
    """Provider boundary: canonicalize role names, cap attempts, pace requests, and reject empty replies early."""
    role = _canonical_role(role)
    if llm is None:
        raise LLMUnavailableError(f"No LLM client is configured for {role}.")

    estimated_prompt = estimate_tokens(prompt)
    # The hard per-run ceiling is explicitly a PROMPT-token ceiling. Completion
    # tokens are accounted for by the rolling TPM gate below, but must not be
    # double-counted against the prompt-token safety ceiling. The previous
    # implementation charged prompt + reserved completion here, which made a
    # normal multi-checkpoint replay exhaust the 24k prompt budget early.
    estimated = estimated_prompt
    # The rolling Groq TPM gate still reserves the complete request budget.
    estimated_request = estimated_prompt + _configured_output_tokens(role)
    try:
        retries = max(0, int(os.getenv("C360_LLM_RETRIES", "1")))
    except ValueError:
        retries = 1
    try:
        base_backoff = max(0.1, float(os.getenv("C360_LLM_RETRY_BASE_SECONDS", "0.6")))
    except ValueError:
        base_backoff = 0.6

    for attempt in range(retries + 1):
        # Enforce the absolute per-run ceiling before waiting on the rolling TPM
        # gate. A saturated run must fail immediately rather than sleeping for a
        # minute only to discover that no provider attempt is allowed anymore.
        current = _RUN_BUDGET.stats()
        if current.provider_attempts >= configured_call_cap():
            _RUN_BUDGET.claim(role, 0)
        # Pace first, then count the actual provider attempt. Retries count too.
        _BUDGET.acquire(estimated_request)
        _RUN_BUDGET.claim(role, estimated)
        try:
            response = llm.invoke(prompt)
            if response is None:
                raise LLMResponseError(f"{role} provider returned None.")
            text = response_text(response)
            if not text:
                # Do not leak a deep JSONDecodeError from the parsing layer.
                raise LLMResponseError(f"{role} provider returned an empty response.")
            return response
        except Exception as exc:
            if not _is_retryable(exc) or attempt >= retries:
                message = str(exc).lower()
                if "rate" in message or "429" in message or "quota" in message:
                    raise LLMRateLimitError(f"{role} provider rate/quota error: {exc}") from exc
                if isinstance(exc, LLMProviderError):
                    raise
                raise LLMProviderError(f"{role} provider error: {exc}") from exc
            delay = base_backoff * (2 ** attempt) + random.uniform(0.0, 0.10)
            print(f"[{role.upper()}] transient provider response; retrying ({attempt + 1}/{retries})")
            time.sleep(delay)

    raise LLMProviderError(f"{role} invocation ended without a usable response.")


def with_fallback(
    *,
    llm: Any,
    prompt: str,
    role: str,
    fallback: Callable[[Exception | None], Any],
) -> tuple[Any, str, str | None]:
    try:
        return invoke(llm, prompt, role), "groq", None
    except Exception as exc:
        return fallback(exc), "deterministic_fallback", f"{type(exc).__name__}: {exc}"
