from __future__ import annotations

from typing import Any


class EvidenceExtractor:
    """Create source-grounded evidence from a bounded event-time view."""

    def __init__(self, state):
        self.state = state

    def extract(self, events: list[Any] | None = None) -> dict[str, list[str]]:
        source_events = list(events if events is not None else self.state.all_events)
        source_events.sort(key=lambda e: (e.event_time, e.ingestion_time, e.event_id))
        evidence: dict[str, list[str]] = {
            "financial": [], "support": [], "usage": [], "profile": [], "life_event_keywords": [], "temporal_patterns": []
        }
        for event in source_events:
            source = event.source_system
            event_type = event.event_type
            payload = event.payload or {}
            if source in {"card_payments", "instant_payments", "ach_wire", "core_banking_ledger", "trading_brokerage"}:
                amount = payload.get("amount")
                merchant = payload.get("merchant_name")
                counterparty = payload.get("counterparty_name")
                tx_type = payload.get("transaction_type")
                if event_type in {"withdrawal", "outbound_transfer", "standing_instruction", "deposit"}:
                    evidence["financial"].append(f"{event.event_id}: {event_type}; amount={amount}; counterparty={counterparty}; transaction_type={tx_type}")
                elif any(v not in (None, "") for v in (merchant, counterparty, tx_type)):
                    evidence["financial"].append(f"{event.event_id}: merchant={merchant}; counterparty={counterparty}; type={tx_type}; amount={amount}")
            if source == "support_logs":
                raw = str(payload.get("raw_text", "")).strip()
                if raw:
                    evidence["support"].append(f"{event.event_id}: {raw[:300]}")
                evidence["temporal_patterns"].append(f"{event.event_id}: support event={event_type} at {event.event_time.isoformat()}")
            if source == "web_app_events":
                search = str(payload.get("search_text", "")).strip()
                feature = str(payload.get("feature_or_page", "")).strip()
                if search:
                    evidence["usage"].append(f"{event.event_id}: search={search[:250]}")
                elif feature and event_type in {"feature_used", "session_duration"}:
                    evidence["usage"].append(f"{event.event_id}: feature={feature[:250]}")
            if source == "loan_kyc":
                old_value = payload.get("old_value")
                new_value = payload.get("new_value")
                if old_value is not None or new_value is not None:
                    evidence["profile"].append(f"{event.event_id}: {event_type}: {old_value} -> {new_value}")
        return {key: values[-20:] for key, values in evidence.items()}
