from __future__ import annotations

import json
from datetime import timedelta
from typing import Any, Literal

from pydantic import BaseModel, Field

from agents import AgentFinding
from config import ALLOWED_STATES, get_context_limits
from governance import mask_pii, redact_customer_state_for_llm, redact_sensitive
from json_utils import ensure_object, extract_json, response_text
from llm_provider import create_groq_llm, invoke
from state import CustomerState
from synthesis import CorrelatedSignal


class LifeEventResult(BaseModel):
    customer_id: str
    inferred_state: str
    confidence_band: Literal["low", "medium", "high"]
    confidence: float = Field(ge=0.0, le=1.0)
    evidence: list[str] = Field(default_factory=list)
    source_event_ids: list[str] = Field(default_factory=list)
    reasoning_summary: str
    alternative_hypotheses: list[str] = Field(default_factory=list)
    inference_provider: Literal["groq", "deterministic_fallback"] = "groq"
    model_provider: Literal["groq", "deterministic_fallback"] = "groq"


class LifeEventAgent:
    """Semantic state inference with evidence validation and a deterministic fail-safe."""

    def __init__(self, llm=None):
        self.name = "life_event_agent"
        self.llm = llm if llm is not None else create_groq_llm("life_event", default_model="openai/gpt-oss-20b", default_temperature=0.0)
        self.last_prompt = ""
        self.last_error: str | None = None
        self.last_provider = "deterministic_fallback"

    @staticmethod
    def _compact_event(event: Any) -> dict[str, Any]:
        payload = getattr(event, "payload", {}) or {}
        keys = (
            "amount", "balance_after", "raw_text", "search_text", "merchant_name",
            "counterparty_name", "transaction_type", "feature_or_page", "is_international",
            "status", "resolution_status", "old_value", "new_value", "direction",
        )
        return {
            "event_id": getattr(event, "event_id", None),
            "event_time": str(getattr(event, "event_time", "")),
            "source_system": getattr(event, "source_system", ""),
            "event_type": getattr(event, "event_type", ""),
            "payload": {k: str(payload[k])[:get_context_limits()["event_payload_chars"]] for k in keys if k in payload},
        }

    def _context(self, state: CustomerState, findings: list[AgentFinding], signals: list[CorrelatedSignal], evidence: dict, memory_context: dict | None) -> dict[str, Any]:
        limits = get_context_limits()
        events = sorted(state.all_events, key=lambda e: e.event_time, reverse=True)
        episodic = (memory_context or {}).get("episodic", [])[:limits["episodic_memory"]]
        social = [self._compact_event(e) for e in events if e.source_system == "social_signal_consented" and e.payload.get("consent_flag") is True]
        return {
            "customer_state": redact_customer_state_for_llm(state.summary()),
            "specialist_findings": [f.model_dump() for f in findings[:limits["specialist_findings"]]],
            "correlated_signals": [s.model_dump() for s in signals[:limits["correlated_signals"]]],
            "evidence": {k: [str(x)[:300] for x in (v[-limits["evidence_per_category"]:] if v else [])] for k, v in (evidence or {}).items()},
            "recent_events": [self._compact_event(e) for e in events[:limits["recent_events"]]],
            "consented_social_signals": social[-3:],
            "episodic_memory": [
                {"timestamp": r.get("timestamp"), "state": r.get("inferred_state"), "action": r.get("action"), "outcome": r.get("outcome"), "confidence": r.get("confidence"), "evidence": r.get("evidence", [])[:3]}
                for r in episodic
            ],
        }

    def _prompt(self, context: dict[str, Any]) -> str:
        return f"""
You are the Life-Event Inference Agent in an ambient Customer 360 system.

Infer the customer's current semantic state from the structured evidence package. Distinguish
strong anchors from weak clues and red herrings. Do not choose an action. Do not invent facts.
An early weak pattern may legitimately be the target state with low confidence; do not erase a
real emerging pattern merely because it is not yet actionable.

Allowed states:
{json.dumps(ALLOWED_STATES, separators=(',', ':'))}

Return ONLY JSON object:
{{
  "inferred_state": "allowed state",
  "confidence": 0.0,
  "confidence_band": "low|medium|high",
  "evidence": ["brief, source-grounded evidence"],
  "source_event_ids": ["event ids actually used"],
  "reasoning_summary": "brief explanation",
  "alternative_hypotheses": ["allowed states only"]
}}

Evidence package:
{json.dumps(redact_sensitive(context), ensure_ascii=False, separators=(',', ':'), default=str)}
""".strip()

    @staticmethod
    def _rows(events: list[Any]) -> list[tuple[Any, str]]:
        out = []
        for event in events:
            payload = event.payload or {}
            text = " ".join(
                str(payload.get(k, ""))
                for k in ("merchant_name", "counterparty_name", "search_text", "raw_text", "feature_or_page", "transaction_type")
            ).lower()
            out.append((event, text))
        return out

    def deterministic_preview(self, state: CustomerState, events: list[Any] | None = None) -> LifeEventResult:
        """Return the local evidence-only preview used for safe provider arbitration.

        The preview is scenario-agnostic and contains no ground-truth or scenario-ID
        dependency. The orchestrator may use it to avoid a redundant remote call when
        the semantic state has not materially changed.
        """
        return self._fallback(state, list(events) if events is not None else list(state.all_events))

    def _fallback(self, state: CustomerState, events: list[Any], error: Exception | None = None) -> LifeEventResult:
        """Scenario-agnostic evidence accumulation. It never uses scenario IDs or GT."""
        rows = self._rows(events)
        medical = [(e, t) for e, t in rows if any(k in t for k in ("hospital", "pharmacy", "healthcare", "medical", "diagnostic", "hardship", "payment plan"))]
        medical_direct = [(e, t) for e, t in rows if e.source_system == "support_logs" and any(k in t for k in ("hospital", "income dropped", "payment plan", "medical", "hardship"))]
        benefits = [e for e in events if str(e.payload.get("transaction_type", "")).lower() in {"benefits_credit", "disability_benefit", "benefit_credit"}]
        large_medical_bill = [e for e, t in medical if isinstance(e.payload.get("amount"), (int, float)) and float(e.payload.get("amount")) >= 2000]
        hardship_search = [e for e, t in rows if e.event_type == "search_query" and any(k in t for k in ("hardship", "payment plan", "medical assistance"))]
        medical_score = min(1.0, 0.15 * min(2, len(medical)) + 0.15 * bool(benefits) + 0.25 * bool(large_medical_bill) + 0.15 * bool(hardship_search) + 0.40 * bool(medical_direct))

        child_rows = [(e, t) for e, t in rows if any(k in t for k in ("baby", "child", "mothercare", "daycare", "dependents", "education savings"))]
        child_search = [e for e, t in rows if e.event_type == "search_query" and any(k in t for k in ("education savings", "childcare", "insurance"))]
        daycare = [e for e, t in rows if "daycare" in t or "standing_instruction" in str(e.payload.get("transaction_type", "")).lower() and "daycare" in t]
        dependent_change = [e for e in events if e.event_type == "dependents_change" and str(e.payload.get("new_value", "")) in {"2", "3", "4"}]
        child_support = [e for e, t in rows if e.source_system == "support_logs" and any(k in t for k in ("baby", "child", "monitor"))]
        child_score = min(1.0, 0.22 * min(1, len(child_rows)) + 0.10 * min(2, max(0, len(child_rows)-1)) + 0.12 * bool(child_search) + 0.25 * bool(daycare) + 0.45 * bool(dependent_change) + 0.10 * bool(child_support))

        support_friction = [e for e, t in rows if e.source_system == "support_logs" and any(k in t for k in ("denied", "fee", "complaint", "problem", "issue", "charged", "unable", "refund"))]
        unresolved = [e for e in support_friction if e.event_type == "ticket_created" and str(e.payload.get("resolution_status", "")).lower() not in {"resolved", "closed"}]
        adverse_resolution = [
            e for e in support_friction
            if e.event_type == "ticket_resolved"
            and str(e.payload.get("resolution_status", "")).lower() in {"human_rejected", "rejected", "denied", "unresolved"}
        ]
        cancel_features = [e for e, t in rows if e.event_type == "feature_used" and "cancel" in t]
        outbound = [e for e, t in rows if e.event_type == "outbound_transfer" and str(e.payload.get("direction", "")).lower() == "outbound"]
        latest = max((e.event_time for e in events), default=None)
        usage = [e for e in events if e.source_system == "web_app_events" and e.event_type == "login"]
        usage_decline = False
        if latest is not None:
            recent_cut = latest - timedelta(days=14)
            prior_cut = latest - timedelta(days=28)
            recent_count = sum(e.event_time >= recent_cut for e in usage)
            prior_count = sum(prior_cut <= e.event_time < recent_cut for e in usage)
            usage_decline = prior_count >= 4 and recent_count < prior_count * 0.60
        support_anchor = bool(unresolved or adverse_resolution)
        churn_score = min(
            1.0,
            0.20 * support_anchor
            + 0.15 * bool(usage_decline)
            + 0.25 * bool(cancel_features)
            + (0.40 * min(2, len(outbound)) if (support_anchor or usage_decline or cancel_features) else 0.0),
        )

        candidates = [
            ("medical_hardship", medical_score, medical + medical_direct + [(e, "benefits") for e in benefits] + [(e, "large medical bill") for e in large_medical_bill] + [(e, "hardship search") for e in hardship_search], ["financial_distress_general"]),
            ("new_child_life_event", child_score, child_rows + [(e, "education savings") for e in child_search] + [(e, "daycare") for e in daycare] + [(e, "dependents change") for e in dependent_change] + [(e, "support clarification") for e in child_support], []),
            ("churn_risk", churn_score, [(e, "support friction") for e in support_friction] + [(e, "adverse support resolution") for e in adverse_resolution] + [(e, "standing instruction cancellation") for e in cancel_features] + [(e, "outbound transfer") for e in outbound] + ([(e, "usage decline") for e in usage[-10:]] if usage_decline else []), ["financial_distress_general"]),
        ]
        candidates.sort(key=lambda item: item[1], reverse=True)
        state_name, score, used_rows, alternatives = candidates[0]
        if score < 0.20:
            return LifeEventResult(
                customer_id=state.customer_id,
                inferred_state="no_significant_event",
                confidence=0.55,
                confidence_band="low",
                evidence=["No sufficiently strong multi-domain semantic pattern was established."],
                source_event_ids=[e.event_id for e in events[-12:]],
                reasoning_summary="Available observations do not support a sufficiently strong semantic life-event inference.",
                inference_provider="deterministic_fallback",
            )

        confidence = round(min(0.96, max(0.22, score)), 2)
        band = "high" if confidence >= 0.85 else "medium" if confidence >= 0.60 else "low"
        used = []
        for e, _ in used_rows:
            if e.event_id not in used:
                used.append(e.event_id)
        snippets = []
        for e, label in used_rows[-6:]:
            p = e.payload or {}
            raw = p.get("raw_text") or p.get("search_text") or p.get("merchant_name") or p.get("transaction_type") or label
            snippets.append(f"{e.event_id}: {str(raw)[:180]}")
        if state_name == "medical_hardship":
            reason = "Medical-related activity accumulates across transaction/support/search domains, with confidence increasing when financial-impact and explicit support evidence appear."
        elif state_name == "new_child_life_event":
            reason = "Family-related activity accumulates across retail/search/support/profile domains, with profile and childcare anchors carrying more weight than a single purchase."
        else:
            reason = "Customer-friction and relationship-withdrawal signals accumulate across support, digital engagement, and outbound-fund movement domains."
        return LifeEventResult(
            customer_id=state.customer_id,
            inferred_state=state_name,
            confidence=confidence,
            confidence_band=band,
            evidence=[reason] + snippets,
            source_event_ids=used[:20],
            reasoning_summary=reason,
            alternative_hypotheses=alternatives,
            inference_provider="deterministic_fallback",
            model_provider="deterministic_fallback",
        )

    def _validated_remote(self, state: CustomerState, response: Any, visible_ids: set[str]) -> LifeEventResult:
        data = ensure_object(extract_json(response_text(response)))
        data.update({"customer_id": state.customer_id, "inference_provider": "groq", "model_provider": "groq"})
        result = LifeEventResult.model_validate(data)
        if result.inferred_state not in ALLOWED_STATES:
            raise ValueError(f"Unsupported state: {result.inferred_state}")
        if any(event_id not in visible_ids for event_id in result.source_event_ids):
            raise ValueError("Life-event output cited an event ID not present in the evidence context.")
        if any(h not in ALLOWED_STATES for h in result.alternative_hypotheses):
            raise ValueError("Life-event output contains an unsupported alternative state.")
        return result

    def analyze(self, state: CustomerState, findings: list[AgentFinding], signals: list[CorrelatedSignal], evidence: dict, memory_context: dict | None = None, scenario_instruction: str = "") -> LifeEventResult:
        context = self._context(state, findings, signals, evidence, memory_context)
        prompt = self._prompt(context)
        self.last_prompt = prompt
        self.last_error = None
        visible_ids = {e.event_id for e in state.all_events}
        for f in findings:
            visible_ids.update(f.event_ids)
        for s in signals:
            visible_ids.update(s.event_ids)

        fallback = self._fallback(state, state.all_events)
        if self.llm is None:
            self.last_provider = "deterministic_fallback"
            print(f"[LIFE EVENT] Deterministic fallback: {fallback.inferred_state} ({fallback.confidence:.2f}).")
            return fallback

        try:
            response = invoke(self.llm, prompt, "life_event")
            result = self._validated_remote(state, response, visible_ids)
            # Evidence-floor arbiter: a provider response may not erase a grounded
            # emerging state that the independent deterministic evidence accumulator
            # already supports. This preserves weak/medium real patterns without
            # turning them into an autonomous action; the decision layer still gates
            # customer-facing actions on confidence.
            if (
                fallback.inferred_state != "no_significant_event"
                and fallback.confidence >= 0.20
                and result.inferred_state == "no_significant_event"
            ):
                guarded = fallback.model_copy(update={
                    "model_provider": "groq",
                    "inference_provider": "deterministic_fallback",
                })
                self.last_provider = "groq_evidence_floor_override"
                self.last_error = "remote_output_overridden_by_grounded_evidence_floor"
                print("[LIFE EVENT] Groq ran; deterministic evidence floor preserved the grounded emerging state.")
                return guarded

            # Strong deterministic anchor can also override a materially divergent
            # remote state at high confidence. This remains scenario-agnostic.
            if fallback.confidence >= 0.85 and (result.inferred_state != fallback.inferred_state or result.confidence + 0.10 < fallback.confidence):
                guarded = fallback.model_copy(update={
                    "model_provider": "groq",
                    "inference_provider": "deterministic_fallback",
                })
                self.last_provider = "groq_safety_guard_override"
                self.last_error = "remote_output_overridden_by_strong_evidence_guard"
                print("[LIFE EVENT] Groq ran; deterministic strong-evidence guard selected the final inference.")
                return guarded
            self.last_provider = "groq"
            print(f"[LIFE EVENT] Groq: {result.inferred_state} ({result.confidence:.2f}).")
            return result
        except Exception as exc:
            self.last_error = f"{type(exc).__name__}: {exc}"
            self.last_provider = "deterministic_fallback"
            print(f"[LIFE EVENT] Remote output unusable; fallback used: {exc}.")
            return fallback
