from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any


class ScenarioEvaluator:
    """Practice-scenario evaluator. Ground truth is read only here, never by inference agents."""

    def __init__(self, dataset_root: str | Path = "."):
        self.dataset_root = Path(dataset_root)

    def load_ground_truth(self, scenario_id: str) -> dict[str, Any]:
        path = self.dataset_root / scenario_id / "ground_truth.json"
        return json.loads(path.read_text(encoding="utf-8"))

    @staticmethod
    def _parse_time(value: str) -> datetime:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))

    def _load_rows(self, path: str | Path) -> list[dict[str, Any]]:
        p = Path(path)
        rows: list[dict[str, Any]] = []
        if not p.exists():
            return rows
        for line_no, line in enumerate(p.read_text(encoding="utf-8").splitlines(), start=1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
                if isinstance(row, dict) and (row.get("as_of_time") or row.get("timestamp")):
                    row.setdefault("as_of_time", row.get("timestamp"))
                    rows.append(row)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid inferred-events JSON at line {line_no}: {exc}") from exc
        rows.sort(key=lambda r: self._parse_time(r["as_of_time"]))
        return rows

    def _causal_match(self, rows: list[dict[str, Any]], target: str) -> dict[str, Any] | None:
        if not rows:
            return None
        target_time = self._parse_time(target)
        prior = [r for r in rows if self._parse_time(r["as_of_time"]) <= target_time]
        if prior:
            return prior[-1]
        return rows[0]

    def _checkpoint_results(self, gt: dict[str, Any], rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for cp in gt.get("checkpoints", []):
            target = cp.get("as_of_time")
            predicted = self._causal_match(rows, target) if target else (rows[-1] if rows else None)
            expected_state = cp.get("expected_inferred_state")
            expected_action = cp.get("expected_action")
            expected_subtype = cp.get("expected_action_subtype")
            expected_hitl = cp.get("expected_hitl_status")
            expected_band = cp.get("expected_confidence_band")
            state_pass = bool(predicted and predicted.get("inferred_state") == expected_state)
            action_pass = bool(predicted and predicted.get("action") == expected_action)
            subtype_pass = bool(predicted and (expected_subtype is None or predicted.get("action_subtype") == expected_subtype))
            # expected_hitl_status describes whether the checkpoint required escalation, not the
            # final human disposition. Prefer the explicit pre-human-review field and fall back to
            # the legacy final field for older inferred-event files.
            observed_hitl = (predicted.get("hitl_requirement_status") if predicted else None) or (predicted.get("hitl_status") if predicted else None)
            hitl_pass = bool(predicted and (expected_hitl is None or observed_hitl == expected_hitl))
            band_pass = bool(predicted and (expected_band is None or predicted.get("confidence_band") == expected_band))
            timing = None
            if predicted and target:
                delta_hours = (self._parse_time(predicted["as_of_time"]) - self._parse_time(target)).total_seconds() / 3600
                timing = {"predicted_as_of_time": predicted["as_of_time"], "delta_hours": round(delta_hours, 2), "causal": delta_hours <= 0}
            out.append({
                "as_of_time": target,
                "expected": {"state": expected_state, "action": expected_action, "action_subtype": expected_subtype, "hitl_status": expected_hitl, "confidence_band": expected_band},
                "predicted": predicted,
                "observed_hitl_for_benchmark": observed_hitl,
                "timing": timing,
                "state_pass": state_pass,
                "action_pass": action_pass,
                "subtype_pass": subtype_pass,
                "hitl_pass": hitl_pass,
                "confidence_band_pass": band_pass,
                "checkpoint_pass": all((state_pass, action_pass, subtype_pass, hitl_pass, band_pass)) and bool(timing is None or timing["causal"]),
            })
        return out

    def _false_positive_results(self, gt: dict[str, Any], rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        inferred_by_event: list[tuple[datetime, dict[str, Any]]] = []
        for row in rows:
            inferred_by_event.append((self._parse_time(row["as_of_time"]), row))
        results = []
        for check in gt.get("false_positive_checks", []):
            # Practice datasets do not provide a direct row-to-event link beyond source_event_ids.
            event_id = check.get("event_id")
            target_rows = [r for _, r in inferred_by_event if event_id in set(r.get("source_event_ids", []))]
            forbidden = set(check.get("must_not_trigger_action", []))
            violations = [r.get("action") for r in target_rows if r.get("action") in forbidden]
            results.append({
                "event_id": event_id,
                "must_not_trigger_action": sorted(forbidden),
                "rows_citing_event": len(target_rows),
                "violations": violations,
                "pass": not violations,
            })
        return results

    def _trace_metrics(self, trace_path: str | Path | None, audit_path: str | Path | None = None) -> dict[str, Any]:
        path = Path(trace_path) if trace_path else None
        stage_latencies: dict[str, list[float]] = {}
        events = 0
        handoffs = 0
        tool_calls = 0
        retrievals = 0
        trace_errors = 0
        debates = 0
        draft_passes = 0
        llm_calls = 0
        fallback_calls = 0
        specialist_confidences: list[float] = []
        life_confidences: list[float] = []
        if path and path.exists():
            for line in path.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                try:
                    row = json.loads(line)
                except json.JSONDecodeError:
                    continue
                events += 1
                stage = str(row.get("stage", ""))
                event = str(row.get("event", ""))
                raw_data = row.get("data")
                data = raw_data if isinstance(raw_data, dict) else {}
                if event.endswith("_end") and isinstance(data.get("latency_ms"), (int, float)):
                    stage_latencies.setdefault(stage, []).append(float(data["latency_ms"]))
                if event in {"checkpoint_to_decision", "checkpoint_to_action"} and isinstance(data.get("latency_ms"), (int, float)):
                    stage_latencies.setdefault(event, []).append(float(data["latency_ms"]))
                if stage == "latency" and event == "stage" and isinstance(data.get("latency_ms"), (int, float)):
                    stage_latencies.setdefault(str(data.get("stage", "unknown")), []).append(float(data["latency_ms"]))
                if stage == "handoff":
                    handoffs += 1
                if stage == "specialists" and event == "tool_calls" and isinstance(raw_data, list):
                    tool_calls += len(raw_data)
                if stage == "specialists" and event == "findings" and isinstance(raw_data, list):
                    specialist_confidences.extend(
                        float(x.get("confidence")) for x in raw_data
                        if isinstance(x, dict) and isinstance(x.get("confidence"), (int, float))
                    )
                if stage == "memory" and event == "retrieved":
                    retrievals += 1
                if stage == "debate" and event == "resolution" and bool(data.get("conflict_detected")):
                    debates += 1
                if stage == "drafting" and event == "drafts" and isinstance(raw_data, list):
                    draft_passes = max(draft_passes, len(raw_data))
                if event == "llm_boundary":
                    llm_calls += 1
                    if str(data.get("provider")) == "deterministic_fallback":
                        fallback_calls += 1
                    # A fallback is an expected resilience path, not a trace error.
                if event in {"error", "exception", "failed"} or (isinstance(data, dict) and data.get("trace_error")):
                    trace_errors += 1
                if stage == "life_event" and event == "inference_result" and isinstance(data.get("confidence"), (int, float)):
                    life_confidences.append(float(data["confidence"]))

        audit_rows: list[dict[str, Any]] = []
        if audit_path and Path(audit_path).exists():
            for line in Path(audit_path).read_text(encoding="utf-8").splitlines():
                try:
                    row = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(row, dict):
                    audit_rows.append(row)
        hitl_counts: dict[str, int] = {}
        for row in audit_rows:
            key = str(row.get("status", "unknown"))
            hitl_counts[key] = hitl_counts.get(key, 0) + 1
        total_hitl = sum(hitl_counts.values())
        return {
            "trace_events": events,
            "stage_latency_ms": {k: {"count": len(v), "mean": round(sum(v) / len(v), 2), "max": round(max(v), 2)} for k, v in stage_latencies.items() if v},
            "handoff_count": handoffs,
            "tool_call_count": tool_calls,
            "retrieval_count": retrievals,
            "debate_resolution_count": debates,
            "draft_pass_count": draft_passes,
            "llm_boundary_count": llm_calls,
            "llm_fallback_count": fallback_calls,
            "trace_error_count": trace_errors,
            "hitl_decisions": hitl_counts,
            "hitl_approval_rate": (round(hitl_counts.get("human_approved", 0) / total_hitl, 3) if total_hitl else None),
            "hitl_override_rate": (round((hitl_counts.get("human_modified", 0) + hitl_counts.get("human_rejected", 0)) / total_hitl, 3) if total_hitl else None),
            "specialist_mean_confidence": (round(sum(specialist_confidences) / len(specialist_confidences), 3) if specialist_confidences else None),
            "life_event_mean_confidence": (round(sum(life_confidences) / len(life_confidences), 3) if life_confidences else None),
        }

    def evaluate_run(self, scenario_id: str, inferred_path: str, final_result: dict[str, Any], late_events: int, trace_path: str | Path | None = None, audit_path: str | Path | None = None, hard_stop_path: str | Path | None = None) -> dict[str, Any]:
        gt = self.load_ground_truth(scenario_id)
        rows = self._load_rows(inferred_path)
        checkpoint_results = self._checkpoint_results(gt, rows)
        total = len(checkpoint_results)

        def rate(n: int) -> float | None:
            return None if total == 0 else round(n / total, 3)

        state_passes = sum(r["state_pass"] for r in checkpoint_results)
        action_passes = sum(r["action_pass"] for r in checkpoint_results)
        subtype_passes = sum(r["subtype_pass"] for r in checkpoint_results)
        hitl_passes = sum(r["hitl_pass"] for r in checkpoint_results)
        band_passes = sum(r["confidence_band_pass"] for r in checkpoint_results)
        complete_passes = sum(r["checkpoint_pass"] for r in checkpoint_results)
        action_fp_count = sum(1 for r in checkpoint_results if r["expected"]["action"] == "no_action" and r.get("predicted") and r["predicted"].get("action") != "no_action")
        action_fn_count = sum(1 for r in checkpoint_results if r["expected"]["action"] != "no_action" and (not r.get("predicted") or r["predicted"].get("action") == "no_action"))
        action_timing_hours = [float(r["timing"]["delta_hours"]) for r in checkpoint_results if r.get("timing")]

        fp = self._false_positive_results(gt, rows)
        red_herring_pass = all(item["pass"] for item in fp) if fp else True
        expected_actionable = [cp for cp in gt.get("checkpoints", []) if cp.get("expected_action") not in (None, "no_action")]
        predicted_actionable = [r for r in rows if r.get("action") not in (None, "no_action")]
        lifecycle = {
            "expected_actionable_checkpoints": len(expected_actionable),
            "predicted_actionable_inferences": len(predicted_actionable),
            "actionable_detected": bool(predicted_actionable),
            "duplicate_suppression_observed": any("duplicate_action_suppressed" in str(r.get("notes", "")) for r in rows),
            "red_herring_checks_pass": red_herring_pass,
        }

        trace_metrics = self._trace_metrics(trace_path, audit_path)
        hard_stop_count = 0
        if hard_stop_path and Path(hard_stop_path).exists():
            hard_stop_count = sum(1 for line in Path(hard_stop_path).read_text(encoding="utf-8").splitlines() if line.strip())

        runtime = {
            "state": final_result["life_event"].inferred_state,
            "confidence": final_result["life_event"].confidence,
            "confidence_band": final_result["life_event"].confidence_band,
            "action": final_result["decision"].action,
            "action_subtype": final_result["decision"].action_subtype,
            "hitl_status": final_result["decision"].hitl_status,
            "execution_status": final_result["execution"].execution_status,
        }
        return {
            "scenario_id": scenario_id,
            "checkpoint_results": checkpoint_results,
            "checkpoint_metrics": {
                "total_checkpoints": total,
                "state_accuracy": rate(state_passes),
                "action_accuracy": rate(action_passes),
                "subtype_accuracy": rate(subtype_passes),
                "hitl_accuracy": rate(hitl_passes),
                "confidence_band_accuracy": rate(band_passes),
                "complete_checkpoint_accuracy": rate(complete_passes),
                "action_false_positive_rate": rate(action_fp_count),
                "action_false_negative_rate": rate(action_fn_count),
                "mean_checkpoint_timing_delta_hours": (round(sum(action_timing_hours)/len(action_timing_hours), 2) if action_timing_hours else None),
                "all_action_checkpoints_causal": all(bool(r.get("timing", {}).get("causal")) for r in checkpoint_results if r.get("timing") is not None),
            },
            "false_positive_checks": fp,
            "inference_count": len(rows),
            "late_events": late_events,
            "lifecycle": lifecycle,
            "runtime_final": runtime,
            "trace_metrics": trace_metrics,
            "hard_stop_queue_count": hard_stop_count,
        }

    def print_summary(self, result: dict[str, Any]) -> None:
        m = result.get("checkpoint_metrics", {})
        print("\n" + "=" * 78)
        print(f"BENCHMARK SUMMARY — {result.get('scenario_id')}")
        print("=" * 78)
        for key in ("state_accuracy", "action_accuracy", "subtype_accuracy", "hitl_accuracy", "confidence_band_accuracy", "complete_checkpoint_accuracy", "action_false_positive_rate", "action_false_negative_rate"):
            print(f"{key:<28}: {m.get(key)}")
        fp = result.get("false_positive_checks", [])
        print(f"{'red_herring_pass':<28}: {all(x.get('pass') for x in fp) if fp else True}")
        print(f"{'inference_count':<28}: {result.get('inference_count')}")
        print("=" * 78)
