"""Deterministic, scoped specialist tools and their declared data sources.

Tools only read the data-domain inputs required by their owning agent. Customer-facing
side effects do not live here; they are intentionally isolated behind `execution.py` and HITL.
"""
from __future__ import annotations

from datetime import timedelta

TOOL_CATALOG = {
    "windowed_aggregation": {"owner": "usage_agent", "reads": ["web_app_events"], "writes": "none"},
    "trend_detection": {"owner": "usage_agent", "reads": ["web_app_events"], "writes": "feature_store"},
    "anomaly_scoring": {"owner": "usage_agent", "reads": ["web_app_events", "transaction_baseline"], "writes": "finding_only"},
    "ticket_retrieval": {"owner": "support_agent", "reads": ["support_logs"], "writes": "none"},
    "sentiment_analysis": {"owner": "support_agent", "reads": ["support_logs"], "writes": "finding_only"},
    "urgency_detection": {"owner": "support_agent", "reads": ["support_logs"], "writes": "finding_only"},
    "transaction_query": {"owner": "transaction_agent", "reads": ["card_payments", "instant_payments", "ach_wire", "core_banking_ledger", "trading_brokerage"], "writes": "none"},
    "historical_baseline": {"owner": "transaction_agent", "reads": ["transaction sources"], "writes": "feature_store"},
    "kyc_lookup": {"owner": "kyc_compliance_agent", "reads": ["loan_kyc"], "writes": "none"},
    "sanctions_lookup": {"owner": "kyc_compliance_agent", "reads": ["loan_kyc"], "writes": "finding_only"},
    "compliance_rules": {"owner": "kyc_compliance_agent", "reads": ["semantic_policy"], "writes": "finding_only"},
}

def windowed_usage(events, days=14):
    if not events:
        return {"count": 0, "logins": 0, "searches": 0, "features": 0, "sessions": 0}
    latest = max(e.event_time for e in events)
    cutoff = latest - timedelta(days=days)
    w = [e for e in events if e.event_time >= cutoff]
    return {
        "count": len(w),
        "logins": sum(e.event_type == "login" for e in w),
        "searches": sum(e.event_type == "search_query" for e in w),
        "features": sum(e.event_type == "feature_used" for e in w),
        "sessions": sum(e.event_type == "session_duration" for e in w),
    }

def support_ticket_retrieval(events):
    return [e for e in events if e.event_type in {"ticket_created", "ticket_resolved", "call_transcript"}]

def sentiment_score(text):
    negative = {"angry", "furious", "terrible", "urgent", "problem", "issue", "charged", "denied", "cannot", "unable", "lawsuit", "attorney"}
    words = str(text).lower().split()
    return round(sum(w.strip(".,!?;:") in negative for w in words) / max(1, len(words)), 3)

def transaction_baseline(events):
    amounts = [float(e.payload.get("amount", 0)) for e in events if isinstance(e.payload.get("amount"), (int, float))]
    return {"count": len(events), "total": sum(amounts), "average": sum(amounts) / len(amounts) if amounts else 0.0}

def kyc_lookup(events):
    return [e for e in events if e.source_system == "loan_kyc"]
