"""Data-layer access boundaries for specialist agents.

The orchestrator does *not* hand a full CustomerState object to specialists.  A
specialist receives a customer-scoped context containing only the identifier plus
the authorized event view returned by this layer.  Authorization is therefore
structural at the data boundary, not a prompt instruction.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from governance import AGENT_SOURCES, authorize
from models import Event


@dataclass(frozen=True)
class AgentContext:
    """Minimum context visible to a domain specialist."""

    customer_id: str


@dataclass(frozen=True)
class AgentEventView:
    agent_name: str
    customer_id: str
    allowed_sources: frozenset[str]
    events: tuple[Event, ...]


class DataAccessLayer:
    def context_for(self, customer_id: str) -> AgentContext:
        if not str(customer_id).strip():
            raise ValueError("A non-empty customer_id is required for a specialist context.")
        return AgentContext(customer_id=str(customer_id))

    def view_for(self, agent_name: str, customer_id: str, events: Iterable[Event]) -> AgentEventView:
        allowed = frozenset(AGENT_SOURCES.get(agent_name, set()))
        if not allowed:
            raise PermissionError(f"No data sources registered for agent {agent_name!r}.")
        selected: list[Event] = []
        for event in events:
            if event.customer_id != customer_id:
                raise PermissionError("Cross-customer event supplied to specialist data access boundary.")
            if authorize(agent_name, event.source_system):
                selected.append(event)
        return AgentEventView(
            agent_name=agent_name,
            customer_id=customer_id,
            allowed_sources=allowed,
            events=tuple(selected),
        )

    def assert_authorized(self, agent_name: str, source_system: str) -> None:
        if not authorize(agent_name, source_system):
            raise PermissionError(f"Agent {agent_name!r} cannot access source {source_system!r}.")
