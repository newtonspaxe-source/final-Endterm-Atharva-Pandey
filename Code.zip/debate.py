from __future__ import annotations

import json
from typing import Any, Literal

from pydantic import BaseModel, Field

from agents import AgentFinding
from config import ALLOWED_STATES
from governance import mask_pii, redact_sensitive
from json_utils import coerce_string_list, ensure_object, extract_json, response_text
from life_event import LifeEventResult
from llm_provider import create_groq_llm, invoke
from synthesis import CorrelatedSignal


class ConflictResult(BaseModel):
    conflict_detected: bool
    conflict_type: str
    conflicting_signals: list[str] = Field(default_factory=list)
    explanation: str
    compared_agents: list[str] = Field(default_factory=list)


class DebatePerspective(BaseModel):
    perspective_name: str
    position: str
    arguments: list[str] = Field(default_factory=list)
    counterpoints: list[str] = Field(default_factory=list)
    evidence: list[str] = Field(default_factory=list)


class DebatePosition(BaseModel):
    agent_name: str
    position: str
    supporting_evidence: list[str] = Field(default_factory=list)
    key_concern: str = ""


class DebateResult(BaseModel):
    customer_id: str
    conflict_detected: bool
    resolution_status: Literal["not_required", "resolved", "unresolved"]
    resolved_state: str
    confidence: float = Field(ge=0.0, le=1.0)
    reasoning: str
    participating_agents: list[str] = Field(default_factory=list)
    positions: list[DebatePosition] = Field(default_factory=list)
    perspectives: list[DebatePerspective] = Field(default_factory=list)
    disagreements: list[str] = Field(default_factory=list)
    consensus: list[str] = Field(default_factory=list)
    resolution_evidence: list[str] = Field(default_factory=list)


class ConflictDetectionAgent:
    """Detect disagreement from explicit synthesis metadata plus finding direction."""
    def __init__(self):
        self.name = "conflict_detection_agent"

    def detect(self, findings: list[AgentFinding], signals: list[CorrelatedSignal], synthesis_conflict: dict[str, Any] | None = None) -> ConflictResult:
        info = synthesis_conflict or {}
        if bool(info.get("conflict_detected")):
            agents = [str(x) for x in info.get("conflicting_agents", [])][:6]
            if not agents:
                agents = [f.agent_name for f in findings if f.confidence >= 0.65][:6]
            return ConflictResult(
                conflict_detected=True,
                conflict_type="cross_agent_interpretation_conflict",
                conflicting_signals=[str(x) for x in info.get("conflicting_signals", [])][:6],
                explanation=str(info.get("conflict_explanation") or "Synthesis identified a material disagreement among specialist interpretations."),
                compared_agents=agents,
            )

        positive = [f for f in findings if f.confidence >= 0.65 and f.direction == "positive" and not f.signal_type.startswith("no_")]
        negative = [f for f in findings if f.confidence >= 0.65 and f.direction == "negative" and not f.signal_type.startswith("no_")]
        if positive and negative:
            return ConflictResult(
                conflict_detected=True,
                conflict_type="directional_activity_vs_risk_conflict",
                conflicting_signals=[positive[0].signal_type, negative[0].signal_type],
                explanation=(
                    f"{positive[0].agent_name} reports meaningful activity/stability while {negative[0].agent_name} reports friction or declining/risk-oriented behaviour. "
                    "The disagreement is preserved for explicit arbitration rather than silently averaged."
                ),
                compared_agents=[positive[0].agent_name, negative[0].agent_name],
            )

        return ConflictResult(
            conflict_detected=False,
            conflict_type="none",
            explanation="No material directional disagreement was identified in the current specialist findings.",
            compared_agents=[f.agent_name for f in findings if f.confidence >= 0.65 and not f.signal_type.startswith("no_")],
        )


class DebateAgent:
    """Visible debate stage: two contrasting perspectives plus an arbiter in one provider call."""
    def __init__(self, llm=None):
        self.name = "debate_agent"
        self.llm = llm if llm is not None else create_groq_llm("debate", default_model="openai/gpt-oss-20b", default_temperature=0.1)
        self.last_prompt = ""
        self.last_provider = "deterministic_fallback"
        self.last_error: str | None = None

    @staticmethod
    def _fallback(customer_id: str, conflict: ConflictResult, life_event: LifeEventResult, findings: list[AgentFinding], signals: list[CorrelatedSignal]) -> DebateResult:
        positions = [
            DebatePosition(agent_name=f.agent_name, position=f.signal_type, supporting_evidence=f.evidence[:4], key_concern=f.recommendation)
            for f in findings if not conflict.compared_agents or f.agent_name in conflict.compared_agents
        ]
        evidence_a = [e for p in positions for e in p.supporting_evidence[:2]][:4]
        evidence_b = [e for p in positions for e in p.supporting_evidence[2:4]][:4] or evidence_a
        perspectives = [
            DebatePerspective(
                perspective_name="evidence_skeptic",
                position="The customer is still active, so the risk-oriented interpretation may overstate an emerging relationship problem.",
                arguments=["Recent activity is direct evidence that the relationship is still being used."],
                counterpoints=["Continued usage does not disprove unresolved customer friction."],
                evidence=evidence_a,
            ),
            DebatePerspective(
                perspective_name="customer_risk_advocate",
                position="Persistent support friction deserves explicit weight even when the customer remains active.",
                arguments=["Repeated friction can coexist with ongoing usage and may precede a later withdrawal."],
                counterpoints=["Not every support issue indicates churn or a major life-event transition."],
                evidence=evidence_b,
            ),
        ]
        confidence = min(0.90, max(life_event.confidence, max((f.confidence for f in findings), default=life_event.confidence)))
        return DebateResult(
            customer_id=customer_id,
            conflict_detected=True,
            resolution_status="resolved",
            resolved_state=life_event.inferred_state,
            confidence=confidence,
            reasoning="The arbiter retained the current life-event inference because the available evidence package supports it better than an alternative, while preserving the disagreement for audit.",
            participating_agents=conflict.compared_agents,
            positions=positions,
            perspectives=perspectives,
            disagreements=[conflict.explanation],
            consensus=["Use cross-domain evidence and timing rather than any isolated specialist signal."],
            resolution_evidence=[e for s in signals for e in s.evidence[:2]][:6] or life_event.evidence[:4],
        )

    def resolve(self, customer_id: str, conflict: ConflictResult, life_event: LifeEventResult, findings: list[AgentFinding], signals: list[CorrelatedSignal]) -> DebateResult:
        # Provider metadata is checkpoint-local. Never leak the previous checkpoint's Groq status into a later fallback/not-required result.
        self.last_provider = "deterministic_fallback"
        self.last_error = None
        if not conflict.conflict_detected:
            result = DebateResult(
                customer_id=customer_id, conflict_detected=False, resolution_status="not_required",
                resolved_state=life_event.inferred_state, confidence=life_event.confidence,
                reasoning="No material disagreement was detected, so explicit debate was not required.",
                participating_agents=conflict.compared_agents,
            )
            self.last_provider = "deterministic_fallback"
            return result

        record = {
            "life_event": life_event.model_dump(),
            "conflict": conflict.model_dump(),
            "specialist_positions": [f.model_dump() for f in findings if not conflict.compared_agents or f.agent_name in conflict.compared_agents],
            "correlated_signals": [s.model_dump() for s in signals[:8]],
            "allowed_states": ALLOWED_STATES,
        }
        prompt = f"""
You are the explicit Debate / Arbitration Agent in a Customer 360 system.

Two or more specialists disagree. Do not hide the disagreement. Produce two genuinely
contrasting perspectives, then act as an arbiter. You may resolve the disagreement or
leave it unresolved. Do not choose a policy action. Use only the supplied evidence.

Return ONLY JSON:
{{
  "perspectives": [
    {{"perspective_name":"evidence_skeptic","position":"...","arguments":["..."],"counterpoints":["..."],"evidence":["..."]}},
    {{"perspective_name":"customer_risk_advocate","position":"...","arguments":["..."],"counterpoints":["..."],"evidence":["..."]}}
  ],
  "resolution_status":"resolved|unresolved",
  "resolved_state":"allowed state",
  "confidence":0.0,
  "reasoning":"...",
  "disagreements":["..."],
  "consensus":["..."],
  "resolution_evidence":["..."]
}}

Record:
{json.dumps(redact_sensitive(record), ensure_ascii=False, separators=(",", ":"), default=str)}
""".strip()
        self.last_prompt = prompt
        self.last_error = None
        try:
            if self.llm is None:
                raise RuntimeError("Debate LLM unavailable")
            data = ensure_object(extract_json(response_text(invoke(self.llm, prompt, "debate"))))
            normalized_perspectives: list[dict[str, Any]] = []
            for raw in data.get("perspectives", [])[:2]:
                if not isinstance(raw, dict):
                    continue
                item = dict(raw)
                for field in ("arguments", "counterpoints", "evidence"):
                    item[field] = coerce_string_list(item.get(field), max_items=8)
                normalized_perspectives.append(item)
            perspectives = [DebatePerspective.model_validate(x) for x in normalized_perspectives]
            # GPT-OSS can occasionally return a valid JSON object with only one
            # perspective even though the requested debate schema is otherwise
            # correct. Treat this as a provider-backed semantic repair, not as a
            # provider outage: preserve the Groq-produced perspective and fill the
            # missing counterpart from the deterministic conflict evidence.
            if len(perspectives) == 1:
                repaired = self._fallback(customer_id, conflict, life_event, findings, signals).perspectives[1]
                perspectives.append(repaired)
                self.last_provider = "groq_repaired"
            elif len(perspectives) == 0:
                raise ValueError("Debate output did not contain a usable perspective.")
            status = str(data.get("resolution_status", "unresolved"))
            if status not in {"resolved", "unresolved"}:
                raise ValueError(f"Invalid debate resolution status: {status!r}")
            resolved = str(data.get("resolved_state") or life_event.inferred_state)
            if resolved not in ALLOWED_STATES:
                raise ValueError(f"Unsupported debated state: {resolved!r}")
            confidence = max(0.0, min(1.0, float(data.get("confidence", life_event.confidence))))
            result = DebateResult(
                customer_id=customer_id,
                conflict_detected=True,
                resolution_status=status,
                resolved_state=resolved if status == "resolved" else life_event.inferred_state,
                confidence=confidence,
                reasoning=str(data.get("reasoning", "")),
                participating_agents=conflict.compared_agents,
                positions=[DebatePosition(agent_name=f.agent_name, position=f.signal_type, supporting_evidence=f.evidence[:4], key_concern=f.recommendation) for f in findings if not conflict.compared_agents or f.agent_name in conflict.compared_agents],
                perspectives=perspectives,
                disagreements=coerce_string_list(data.get("disagreements"), max_items=6),
                consensus=coerce_string_list(data.get("consensus"), max_items=6),
                resolution_evidence=coerce_string_list(data.get("resolution_evidence"), max_items=8),
            )
            if self.last_provider != "groq_repaired":
                self.last_provider = "groq"
            print(f"[DEBATE] Explicit two-perspective debate completed: {status}.")
            return result
        except Exception as exc:
            self.last_error = f"{type(exc).__name__}: {exc}"
            self.last_provider = "deterministic_fallback"
            result = self._fallback(customer_id, conflict, life_event, findings, signals)
            print(f"[DEBATE] Provider unavailable/invalid; deterministic arbitration used: {exc}.")
            return result
