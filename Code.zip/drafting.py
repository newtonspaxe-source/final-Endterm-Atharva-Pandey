from __future__ import annotations

import json
import os
from typing import Literal

from pydantic import BaseModel, Field

from decision import CustomerDecision
from json_utils import ensure_object, extract_json, response_text
from llm_provider import create_groq_llm, invoke
from offer import OfferRecommendation
from governance import redact_sensitive


class ActionDraft(BaseModel):
    customer_id: str
    draft_id: str
    agent_name: str
    action: str
    action_subtype: str
    message: str
    rationale: str
    risk_flags: list[str] = Field(default_factory=list)
    draft_status: Literal["draft", "revised", "final"] = "draft"
    round_number: int = 1
    revision_notes: str = ""


class RoundRobinDraftingAgent:
    """Three specialized communication roles in an explicit sequential round-robin."""

    ROLES = [
        ("draft_001", "customer_support_agent", "Write the safest, clearest first draft."),
        ("draft_002", "relationship_manager_agent", "Revise the previous draft for relationship quality and appropriate next step."),
        ("draft_003", "customer_experience_agent", "Revise the previous draft for clarity, brevity, low pressure, and natural tone."),
    ]

    def __init__(self, llm=None):
        self.name = "round_robin_drafting_agent"
        self.llm = llm if llm is not None else create_groq_llm("draft", default_model="openai/gpt-oss-20b", default_temperature=0.2)
        self.last_prompt = ""
        self.last_provider = "deterministic_fallback"
        self.last_error: str | None = None

    @staticmethod
    def _fallback_message(decision: CustomerDecision, round_number: int) -> tuple[str, str]:
        """Role-specific deterministic fallback that visibly demonstrates sequential refinement."""
        base = {
            "relationship_manager_escalation": "A member of our team can review the available options with you. Please let us know a convenient time to connect.",
            "support_intervention": "A specialist can review the available support options with you. Please let us know a convenient time to connect.",
            "compliance_fraud_hold": "A specialist needs to review recent account activity before any further action is taken.",
            "personalized_offer": "A specialist can walk you through the available options and answer any questions you may have.",
            "proactive_retention_outreach": "A member of our team can review the available options with you and answer any questions.",
        }.get(decision.action, "A member of our team can review the available options with you.")
        refinements = {
            1: (base, "Round 1: support-focused draft grounded only in the approved action."),
            2: (base.replace("A specialist", "A member of our team", 1), "Round 2: relationship-manager pass improves ownership and next-step clarity."),
            3: (base.replace("Please let us know a convenient time to connect.", "Please let us know a convenient time to connect, or reply here with any questions.").replace("A specialist", "A member of our team", 1), "Round 3: customer-experience pass improves clarity and gives a low-pressure reply path."),
        }
        return refinements[round_number]

    def _build_prompt(self, decision: CustomerDecision, offer: OfferRecommendation, action_proposal: dict | None = None) -> str:
        instruction = os.getenv("C360_DRAFTING_INSTRUCTION", "").strip() or "None"
        proposal = action_proposal or {}
        return f"""
You are a Round-Robin Drafting Coordinator for Customer 360.

Perform these three sequential communication passes. Pass 1 is the customer-support
writer. Pass 2 is the relationship manager revising Pass 1. Pass 3 is the customer
experience writer revising Pass 2. Each pass must build on the previous message; do not
create unrelated alternatives.

Internal decision context (never expose to customer):
{json.dumps(redact_sensitive({"action": decision.action, "action_subtype": decision.action_subtype, "offer_type": offer.offer_type, "eligibility_status": offer.eligibility_status, "rationale": decision.rationale, "risk_flags": decision.risk_flags, "retention_action_proposal": proposal}), ensure_ascii=False, separators=(",", ":"))}

Rules for every pass:
- 1-3 sentences.
- Never reveal or imply inferred state, confidence, evidence, risk scores, or agent reasoning.
- Never reveal sensitive medical/security inferences.
- Never state unsupported eligibility or guarantee an outcome.
- No "we know", "we detected", or "you are definitely".
- For support/review actions, invite discussion of available options.
- Keep language human, neutral, concise, and non-invasive.

Operator instruction: {redact_sensitive(instruction)}

Return ONLY JSON:
{{
  "passes": [
    {{"round":1,"draft_id":"draft_001","agent_name":"customer_support_agent","message":"...","revision_notes":"initial draft"}},
    {{"round":2,"draft_id":"draft_002","agent_name":"relationship_manager_agent","message":"...","revision_notes":"what changed"}},
    {{"round":3,"draft_id":"draft_003","agent_name":"customer_experience_agent","message":"...","revision_notes":"what changed"}}
  ]
}}
""".strip()

    def generate_drafts(self, decision: CustomerDecision, life_event=None, offer: OfferRecommendation | None = None, context: dict | None = None, action_proposal: dict | None = None) -> list[ActionDraft]:
        if offer is None:
            raise ValueError("Drafting requires an OfferRecommendation.")
        if decision.action == "no_action":
            return []

        prompt = self._build_prompt(decision, offer, action_proposal=action_proposal)
        self.last_prompt = prompt
        self.last_error = None
        messages: dict[str, tuple[str, str]] = {}
        try:
            if self.llm is None:
                raise RuntimeError("Draft LLM unavailable")
            data = ensure_object(extract_json(response_text(invoke(self.llm, prompt, "drafting"))), object_key="passes")
            passes = data.get("passes")
            if not isinstance(passes, list) or len(passes) != 3:
                raise ValueError("Round-robin output must contain exactly three sequential passes.")
            for item in passes:
                draft_id = str(item.get("draft_id", ""))
                message = str(item.get("message", "")).strip()
                notes = str(item.get("revision_notes", "")).strip()
                if draft_id and message:
                    messages[draft_id] = (message, notes)
            if len(messages) != 3:
                raise ValueError("Round-robin output did not contain three non-empty drafts.")
            self.last_provider = "groq"
        except Exception as exc:
            self.last_error = f"{type(exc).__name__}: {exc}"
            self.last_provider = "deterministic_fallback"
            print(f"[DRAFTING] Groq output unusable; deterministic drafts used: {exc}.")

        drafts: list[ActionDraft] = []
        for index, (draft_id, agent_name, _) in enumerate(self.ROLES, start=1):
            message, notes = messages.get(draft_id, self._fallback_message(decision, index))
            drafts.append(ActionDraft(
                customer_id=decision.customer_id,
                draft_id=draft_id,
                agent_name=agent_name,
                action=decision.action,
                action_subtype=decision.action_subtype,
                message=message,
                rationale=decision.rationale,
                risk_flags=list(decision.risk_flags),
                draft_status="draft" if index == 1 else "revised",
                round_number=index,
                revision_notes=notes,
            ))
        return drafts

    def finalize_round_robin(self, drafts: list[ActionDraft]) -> list[ActionDraft]:
        if not drafts:
            return []
        for i, draft in enumerate(drafts):
            draft.draft_status = "draft" if i == 0 else "revised"
            print("\n" + "=" * 70)
            print(f"[DRAFTING] ROUND {draft.round_number} | {draft.agent_name} | {draft.draft_status}")
            print("-" * 70)
            print(draft.message)
            if draft.revision_notes:
                print(f"Revision notes: {draft.revision_notes}")
        return drafts

    # Backward-compatible name used by older callers.
    def round_robin(self, drafts: list[ActionDraft]) -> list[ActionDraft]:
        return self.finalize_round_robin(drafts)
