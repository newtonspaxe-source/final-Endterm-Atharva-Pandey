from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path
from typing import Any, cast
from uuid import uuid4
from datetime import datetime, timezone
from io import TextIOWrapper

from config import discover_scenarios, load_scenario_metadata, project_root
from models import Event
from action import RetentionActionAgent
from state import CustomerState, ActionRecord
from stream import EventStream
from stream_features import LiveFeatureStore
from router import TriggerRouter
from agents import SpecialistAgents
from synthesis import SynthesisAgent
from evidence import EvidenceExtractor
from life_event import LifeEventAgent
from debate import ConflictDetectionAgent, DebateAgent
from decision import DecisionAgent
from offer import OfferEligibilityAgent
from drafting import RoundRobinDraftingAgent
from critique import CritiqueComplianceAgent, CritiqueResult, ReviewerAssessment
from guardrail import GuardrailHITLAgent
from execution import ExecutionAgent
from checkpointing import DecisionCheckpoint, InferredEvent, InferredEventWriter
from memory import CustomerMemory
from cust_trace import TraceLogger
from hitl import CLIHITL, FileHITL
from evaluation import ScenarioEvaluator
from json_utils import response_text
from governance import redact_sensitive
from llm_provider import configured_call_cap, start_llm_run, llm_run_stats
from triggers import AmbientTriggerCoordinator

BASE_DIR = project_root()
os.environ.setdefault("C360_PROJECT_ROOT", str(BASE_DIR))

for _stream in (sys.stdout, sys.stderr):
    try:
        cast(TextIOWrapper, _stream).reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def load_jsonl(path: Path) -> list[Event]:
    events: list[Event] = []
    for line_no, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        try:
            events.append(Event.model_validate(json.loads(line)))
        except Exception as exc:
            raise ValueError(f"Invalid event at {path}:{line_no}: {exc}") from exc
    return events


def print_separator(title: str) -> None:
    print("\n" + "=" * 78)
    print(title)
    print("=" * 78)


def write_run_status(
    scenario_id: str,
    status: str,
    *,
    customer_id: str | None = None,
    accepted: int = 0,
    duplicates: int = 0,
    late_events: int = 0,
    total_state_events: int = 0,
    inference_count: int = 0,
    last_checkpoint: dict[str, Any] | None = None,
    error: str | None = None,
) -> None:
    path = BASE_DIR / "outputs" / f"{scenario_id}_run_status.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "scenario_id": scenario_id,
        "status": status,
        "customer_id": customer_id,
        "accepted_events": accepted,
        "duplicate_events": duplicates,
        "late_events": late_events,
        "total_state_events": total_state_events,
        "inference_checkpoints": inference_count,
        "last_checkpoint": last_checkpoint or {},
        "error": error,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False, default=str), encoding="utf-8")


def safe_model_dump(value: Any) -> Any:
    """JSON-safe, recursively redacted trace representation."""
    try:
        payload = value.model_dump(mode="json")
    except Exception:
        try:
            payload = json.loads(value.model_dump_json())
        except Exception:
            if isinstance(value, dict):
                payload = value
            else:
                payload = str(value)
    return redact_sensitive(payload)


def log_llm_boundary(tracer: TraceLogger, stage: str, provider: str, prompt: str, error: str | None = None) -> None:
    tracer.log(
        stage,
        "llm_boundary",
        {
            "provider": provider,
            "prompt_chars": len(prompt or ""),
            "prompt": redact_sensitive((prompt or "")[:12000]),
            "error": error,
        },
    )


def run_scenario(
    scenario_id: str,
    interactive_hitl: bool = False,
    checkpoint_interval: int = 30,
    ui_hitl: bool = False,
    specialist_workers: int = 4,
) -> dict[str, Any]:
    scenario_dir = BASE_DIR / scenario_id
    if not scenario_dir.exists():
        raise FileNotFoundError(f"Scenario directory not found: {scenario_dir}")

    package = load_scenario_metadata(scenario_dir)
    replay = package.get("replay", {}) or {}
    entities = package.get("entities", {}) or {}
    profile = entities.get("profile") if isinstance(entities.get("profile"), dict) else {}
    customer_id = str(entities.get("customer_id") or profile.get("customer_id") or replay.get("customer_id") or "")
    customer = {"customer_id": customer_id, **profile}
    raw_accounts = entities.get("accounts") or []
    if isinstance(raw_accounts, list):
        account_map = {str(a.get("account_id")): dict(a) for a in raw_accounts if isinstance(a, dict) and a.get("account_id")}
    elif isinstance(raw_accounts, dict):
        account_map = dict(raw_accounts)
    else:
        account_map = {}
    if not customer_id:
        raise ValueError(f"Scenario {scenario_id} has no customer_id in entities.json/replay_config.json")

    history_path = scenario_dir / "history_seed.jsonl"
    live_path = scenario_dir / "live_stream.jsonl"
    history_events = load_jsonl(history_path)
    live_events = load_jsonl(live_path)

    if any(event.customer_id != customer_id for event in history_events + live_events):
        raise ValueError("Customer isolation violation: scenario contains an event for another customer.")

    outputs = BASE_DIR / "outputs"
    outputs.mkdir(parents=True, exist_ok=True)
    (outputs / f"{scenario_id}_traces").mkdir(parents=True, exist_ok=True)

    inferred_path = outputs / f"{scenario_id}_inferred_events.jsonl"
    audit_path = outputs / f"{scenario_id}_hitl_audit.jsonl"
    request_path = outputs / f"{scenario_id}_hitl_request.json"
    response_path = outputs / f"{scenario_id}_hitl_response.json"
    hard_stop_path = outputs / f"{scenario_id}_hard_stop_queue.jsonl"
    evaluation_path = outputs / f"{scenario_id}_evaluation.json"
    inferred_path.unlink(missing_ok=True)
    request_path.unlink(missing_ok=True)
    response_path.unlink(missing_ok=True)
    hard_stop_path.unlink(missing_ok=True)

    tracer = TraceLogger(str(outputs / f"{scenario_id}_traces"))
    # Reset the process-local provider budget for this scenario replay. The hard
    # cap is shared across all LLM-enabled stages and includes retries.
    start_llm_run(f"{scenario_id}:{tracer.trace_id}")
    memory_scope = f"{scenario_id}:{uuid4().hex[:10]}"
    memory = CustomerMemory(customer_id, root=str(BASE_DIR / "memory"), scope_id=memory_scope)
    memory.seed_semantic_policy()
    for _event in history_events:
        memory.index_event(_event)

    state = CustomerState(
        customer_id=customer_id,
        customer_profile=dict(customer),
        accounts=account_map,
    )
    for event in sorted(history_events, key=lambda e: (e.event_time, e.ingestion_time, e.event_id)):
        state.update(event)

    # Seed the per-customer live event index once from history; future arrivals are appended incrementally.
    # Repeated IDs are ignored by CustomerMemory, so restart/replay is safe.

    stream = EventStream(allowed_lateness_minutes=int(os.getenv("C360_ALLOWED_LATENESS_MINUTES", "30")))
    live_features = LiveFeatureStore(customer_id=customer_id, allowed_lateness=stream.allowed_lateness)
    for historical_event in sorted(history_events, key=lambda e: (e.event_time, e.ingestion_time, e.event_id)):
        live_features.ingest(historical_event)
    tracer_seed_note = {"historical_events_seeded": len(history_events), "transform_store": "incremental_event_time"}
    ambient_triggers = AmbientTriggerCoordinator()
    router = TriggerRouter()
    specialists = SpecialistAgents(max_workers=specialist_workers)
    synthesis_agent = SynthesisAgent()
    evidence_extractor = EvidenceExtractor(state)
    life_event_agent = LifeEventAgent()
    conflict_agent = ConflictDetectionAgent()
    debate_agent = DebateAgent()
    decision_agent = DecisionAgent()
    offer_agent = OfferEligibilityAgent()
    action_agent = RetentionActionAgent()
    drafting_agent = RoundRobinDraftingAgent()
    critique_agent = CritiqueComplianceAgent()
    guardrail_agent = GuardrailHITLAgent()
    execution_agent = ExecutionAgent()
    checkpoint = DecisionCheckpoint(min_events_between_inference=max(12, int(checkpoint_interval)), min_minutes_between_inference=30 * 24 * 60)
    inferred_writer = InferredEventWriter(str(inferred_path))
    evaluator = ScenarioEvaluator(BASE_DIR)

    hitl_adapter = None
    if interactive_hitl:
        hitl_adapter = CLIHITL(str(audit_path))
    elif ui_hitl:
        hitl_adapter = FileHITL(str(audit_path), str(request_path), str(response_path))

    accepted_live: list[Event] = []
    last_result: dict[str, Any] | None = None
    last_inference_event_id: str | None = None
    # Debate is conditional. If the same conflict signature recurs across
    # consecutive checkpoints without a material interpretation change, reuse
    # the audited debate result instead of spending another provider call.
    # This keeps the full replay inside the hard 12-call provider ceiling.
    debate_cache_key: tuple[Any, ...] | None = None
    debate_cache_result: Any | None = None
    life_event_cache_key: tuple[Any, ...] | None = None
    life_event_cache_result: Any | None = None
    inference_count = 0
    accepted_count = 0
    duplicate_count = 0
    late_count = 0
    total_hard_stops = 0
    hard_stop_event_ids: set[str] = set()

    write_run_status(scenario_id, "running", customer_id=customer_id, total_state_events=state.total_events)

    print_separator(f"RUNNING {scenario_id}")
    print(f"Customer ID       : {customer_id}")
    print(f"Historical events : {len(history_events)}")
    print(f"Live events       : {len(live_events)}")
    print(f"Replay start      : {replay.get('replay_start', replay.get('simulated_start', 'n/a'))}")
    print(f"Replay end        : {replay.get('replay_end', replay.get('simulated_end', 'n/a'))}")

    print_separator("HISTORICAL STATE RECONSTRUCTION")
    print(f"Historical events applied: {len(history_events)}")
    print(f"State event count       : {state.total_events}")
    tracer.log("ingestion", "historical_reconstruction", {"events": len(history_events), "state_event_count": state.total_events})

    def rebuild_state() -> None:
        nonlocal state, evidence_extractor
        previous_actions = list(state.action_history)
        previous_pending = state.pending_action_id
        rebuilt = CustomerState(
            customer_id=customer_id,
            customer_profile=dict(customer),
            accounts=account_map,
            action_history=previous_actions,
            pending_action_id=previous_pending,
        )
        for ev in sorted(history_events + accepted_live, key=lambda e: (e.event_time, e.ingestion_time, e.event_id)):
            rebuilt.update(ev)
        rebuilt.latest_agent_findings = dict(getattr(state, "latest_agent_findings", {}))
        state = rebuilt
        evidence_extractor = EvidenceExtractor(state)

    def memory_query(events: list[Event]) -> str:
        chunks: list[str] = []
        for event in events[-20:]:
            payload = event.payload or {}
            for key in ("raw_text", "search_text", "merchant_name", "feature_or_page", "transaction_type", "counterparty_name"):
                if payload.get(key) not in (None, ""):
                    chunks.append(str(payload[key]))
        return " ".join(chunks)[-5000:]

    def print_debate(conflict: Any, debate_result: Any) -> None:
        print("\nDEBATE")
        print(f"  Conflict detected : {conflict.conflict_detected}")
        print(f"  Status            : {debate_result.resolution_status}")
        if conflict.conflict_detected:
            print(f"  Conflict type     : {conflict.conflict_type}")
            print(f"  Why               : {conflict.explanation}")
            for perspective in getattr(debate_result, "perspectives", []):
                print(f"\n  [{perspective.perspective_name}] {perspective.position}")
                for item in perspective.evidence[:4]:
                    print(f"      evidence: {item}")
                for item in perspective.arguments[:2]:
                    print(f"      argument: {item}")
                for item in perspective.counterpoints[:2]:
                    print(f"      counterpoint: {item}")
            print(f"\n  Arbitration: {debate_result.reasoning}")
        else:
            print("  No material specialist disagreement at this checkpoint; debate stage recorded as skipped.")

    def print_drafting(drafts: list[Any]) -> None:
        print("\nDRAFT ROUND-ROBIN")
        if not drafts:
            print("  No customer-facing draft because the selected outcome is no_action.")
            return
        for draft in drafts:
            print(f"\n  PASS {draft.round_number} | {draft.agent_name} | {draft.draft_status}")
            print(f"  {draft.message}")
            if draft.revision_notes:
                print(f"  Notes: {draft.revision_notes}")

    def print_critique(results: list[Any]) -> None:
        print("\nCRITIQUE / COMPLIANCE-REFINER")
        if not results:
            print("  No customer-facing draft to review.")
            return
        for result in results:
            print(f"  {result.draft_id} | {result.status} | {result.agent_name}")
            if result.issues:
                print(f"    issues: {'; '.join(result.issues[:4])}")
            if result.compliance_flags:
                print(f"    flags : {'; '.join(result.compliance_flags[:4])}")
            if result.revised_message:
                print(f"    revised: {result.revised_message}")
            for assessment in getattr(result, "reviewer_assessments", [])[:3]:
                print(f"    reviewer={assessment.reviewer} verdict={assessment.verdict}")

    def timed(stage: str, fn):
        started = time.perf_counter()
        try:
            return fn()
        finally:
            tracer.log("latency", "stage", {
                "stage": stage,
                "latency_ms": round((time.perf_counter() - started) * 1000, 2),
            })

    tracer.log("stream_transform", "historical_seed", tracer_seed_note)

    def run_inference(as_of_event: Event, trigger_reasons: list[str]) -> dict[str, Any]:
        nonlocal inference_count, last_result, last_inference_event_id, state
        inference_count += 1
        last_inference_event_id = as_of_event.event_id
        checkpoint.mark_inferred(as_of_event.event_time)
        events_as_of = [e for e in state.all_events if e.event_time <= as_of_event.event_time and e.event_id not in hard_stop_event_ids]
        events_as_of.sort(key=lambda e: (e.event_time, e.ingestion_time, e.event_id))
        # Event-time isolation: inference never sees events that happened after the checkpoint,
        # even when those events were ingested earlier because the stream was out of order.
        analysis_state = CustomerState(
            customer_id=customer_id,
            customer_profile=dict(customer),
            accounts=account_map,
        )
        for ev in sorted(
            history_events
            + [e for e in accepted_live if e.event_time <= as_of_event.event_time and e.event_id not in hard_stop_event_ids],
            key=lambda e: (e.event_time, e.ingestion_time, e.event_id),
        ):
            analysis_state.update(ev)

        print_separator(f"INFERENCE CHECKPOINT #{inference_count}")
        print(f"As-of event       : {as_of_event.event_id}")
        print(f"As-of event time   : {as_of_event.event_time}")
        print(f"Trigger reasons    : {', '.join(trigger_reasons)}")
        checkpoint_wall_start = time.perf_counter()
        tracer.log("checkpoint", "inference_triggered", {"event_id": as_of_event.event_id, "event_time": as_of_event.event_time.isoformat(), "reasons": trigger_reasons, "inference_number": inference_count})

        query = memory_query(events_as_of)
        episodic_memory = memory.retrieve_episodic(query=query, limit=3, max_age_days=int(os.getenv("C360_MEMORY_MAX_AGE_DAYS", "730")), reference_time=as_of_event.event_time)
        relevant_event_memory = memory.retrieve_events(query=query, limit=8, max_age_days=int(os.getenv("C360_MEMORY_MAX_AGE_DAYS", "730")), reference_time=as_of_event.event_time)
        semantic_memory = memory.retrieve_semantic(query=query)
        tracer.log("memory", "retrieved", {
            "scope_id": memory_scope,
            "customer_id": customer_id,
            "episodic_count": len(episodic_memory),
            "event_memory_count": len(relevant_event_memory),
            "semantic_rules": len(semantic_memory.get("rules", [])),
            "episodic_items": [safe_model_dump(x) for x in episodic_memory],
            "event_items": [safe_model_dump(x) for x in relevant_event_memory],
        })

        findings = timed("specialists", lambda: specialists.run(analysis_state, events_as_of))
        tracer.log("handoff", "router_to_specialists", {
            "from": "agent_trigger_router",
            "to": [f.agent_name for f in findings],
            "event_ids": [e.event_id for e in events_as_of[-20:]],
            "scope": "customer_scoped_authorized_event_views",
        })
        for finding in findings:
            analysis_state.publish_finding(finding)
            state.publish_finding(finding)
        print("\nSPECIALIST FINDINGS")
        for finding in findings:
            print(f"  {finding.agent_name:<28} {finding.signal_type:<25} {finding.confidence:.2f} | {finding.direction}")
        tracer.log("specialists", "findings", [safe_model_dump(f) for f in findings])
        tracer.log("specialists", "tool_calls", [
            {
                "agent": f.agent_name,
                "tool": tool,
                "data_sources": f.data_sources,
                "event_ids": f.event_ids[:20],
                "returned_summary": getattr(f, "tool_results", {}),
            }
            for f in findings for tool in f.tools_used
        ])

        tracer.log("handoff", "specialists_to_synthesis", {
            "from": [f.agent_name for f in findings],
            "to": "synthesis_agent",
            "finding_count": len(findings),
            "event_ids": [e.event_id for e in events_as_of[-20:]],
        })
        signals = timed("synthesis", lambda: synthesis_agent.analyze(analysis_state, findings, events_as_of))
        print("\nCORRELATED SIGNALS")
        for signal in signals:
            print(f"  {signal.signal:<34} {signal.strength:<9} {signal.confidence:.2f}")
        tracer.log("synthesis", "correlated_signals", [safe_model_dump(s) for s in signals])
        log_llm_boundary(tracer, "synthesis", synthesis_agent.last_provider, synthesis_agent.last_prompt, synthesis_agent.last_error)
        tracer.log("synthesis", "conflict_handoff", synthesis_agent.last_conflict)

        evidence = EvidenceExtractor(analysis_state).extract(events_as_of)
        tracer.log("evidence", "extracted", evidence)

        tracer.log("handoff", "synthesis_to_life_event", {
            "from": "synthesis_agent",
            "to": "life_event_agent",
            "signal_count": len(signals),
            "signal_ids": [s.signal for s in signals],
        })
        deterministic_preview = life_event_agent.deterministic_preview(analysis_state, events_as_of)
        current_life_event_key = (
            deterministic_preview.inferred_state,
            deterministic_preview.confidence_band,
            round(deterministic_preview.confidence, 2),
        )
        nonlocal life_event_cache_key, life_event_cache_result
        reuse_life_event = False
        if life_event_cache_result is not None and life_event_cache_key is not None:
            cached_state, cached_band, cached_confidence = life_event_cache_key
            same_semantic_state = (
                deterministic_preview.inferred_state == cached_state
                and deterministic_preview.confidence_band == cached_band
                and abs(float(deterministic_preview.confidence) - float(cached_confidence)) <= 0.04
            )
            # Reuse only when the evidence-only state has not materially changed.
            # High-confidence pending actions are also allowed continuity reuse so
            # repeated stream events do not spend provider calls reproducing the same
            # semantic state before the human checkpoint.
            pending_high_confidence = (
                analysis_state.pending_action_id is not None
                and deterministic_preview.confidence_band == "high"
            )
            reuse_life_event = same_semantic_state and (
                not any(reason.startswith("event:") and reason in {
                    "event:outbound_transfer",
                    "event:dependents_change",
                    "event:address_change",
                    "event:marital_status_change",
                    "event:loan_application",
                    "event:loan_disbursed",
                } for reason in trigger_reasons)
                or pending_high_confidence
            )
        if reuse_life_event:
            life_event = deterministic_preview
            life_event_agent.last_provider = "continuity_reuse"
            life_event_agent.last_error = None
            life_event_agent.last_prompt = "Deterministic semantic preview reused; no redundant provider call was spent."
            print("[LIFE EVENT] Reusing prior semantic state; no Groq call spent because the evidence regime remained stable.")
        else:
            life_event = timed("life_event", lambda: life_event_agent.analyze(
                state=analysis_state,
                findings=findings,
                signals=signals,
                evidence=evidence,
                memory_context={"episodic": episodic_memory, "semantic": semantic_memory},
                scenario_instruction="",
            ))
        # Cache only a semantically aligned result. If the provider legitimately
        # disagrees with the deterministic preview, do not let that disagreement
        # leak into a future checkpoint through continuity reuse.
        cacheable_life_event = (
            life_event.inferred_state == deterministic_preview.inferred_state
            and life_event.confidence_band == deterministic_preview.confidence_band
            and abs(float(life_event.confidence) - float(deterministic_preview.confidence)) <= 0.10
        )
        if cacheable_life_event:
            life_event_cache_key = (
                life_event.inferred_state,
                life_event.confidence_band,
                round(life_event.confidence, 2),
            )
            life_event_cache_result = life_event
        else:
            life_event_cache_key = None
            life_event_cache_result = None
        print("\nLIFE-EVENT INFERENCE")
        print(f"  State      : {life_event.inferred_state}")
        print(f"  Confidence : {life_event.confidence:.2f} ({life_event.confidence_band})")
        print(f"  Provider   : {life_event.inference_provider}")
        print(f"  Evidence   : {len(life_event.evidence)} item(s)")
        tracer.log("life_event", "inference_result", safe_model_dump(life_event))
        log_llm_boundary(tracer, "life_event", life_event_agent.last_provider, life_event_agent.last_prompt, life_event_agent.last_error)

        tracer.log("handoff", "life_event_to_conflict", {
            "from": "life_event_agent",
            "to": "conflict_detection",
            "inferred_state": life_event.inferred_state,
            "confidence": life_event.confidence,
        })
        conflict = conflict_agent.detect(findings, signals, synthesis_conflict=synthesis_agent.last_conflict)
        tracer.log("conflict", "detection", safe_model_dump(conflict))
        nonlocal debate_cache_key, debate_cache_result
        current_debate_key = None
        if conflict.conflict_detected:
            current_debate_key = (
                conflict.conflict_type,
                tuple(sorted(conflict.compared_agents)),
                tuple(sorted(conflict.conflicting_signals)),
                life_event.inferred_state,
                life_event.confidence_band,
            )
        if (
            conflict.conflict_detected
            and debate_cache_key == current_debate_key
            and debate_cache_result is not None
        ):
            debate_result = debate_cache_result
            debate_agent.last_provider = "groq_cached" if debate_agent.last_provider.startswith("groq") else debate_agent.last_provider
            print("[DEBATE] Reusing prior Groq debate for unchanged conflict signature; no provider call spent.")
        else:
            debate_result = timed("debate", lambda: debate_agent.resolve(
                customer_id=customer_id,
                conflict=conflict,
                life_event=life_event,
                findings=findings,
                signals=signals,
            ))
            if conflict.conflict_detected and debate_agent.last_provider.startswith("groq"):
                debate_cache_key = current_debate_key
                debate_cache_result = debate_result
        print_debate(conflict, debate_result)
        tracer.log("debate", "resolution", safe_model_dump(debate_result))
        log_llm_boundary(tracer, "debate", debate_agent.last_provider, debate_agent.last_prompt, debate_agent.last_error)

        if debate_result.resolution_status == "resolved":
            life_event.inferred_state = debate_result.resolved_state
            # Arbitration resolves the *interpretation*, not the confidence calibration.
            # Never let a specialist's confidence inflate an independently inferred low/medium
            # life-event state merely because a debate occurred.
            life_event.confidence = min(life_event.confidence, debate_result.confidence)
            life_event.confidence_band = "high" if life_event.confidence >= 0.85 else "medium" if life_event.confidence >= 0.60 else "low"
            life_event.reasoning_summary = f"Debate arbitration: {debate_result.reasoning}"
            valid_ids = {e.event_id for e in events_as_of}
            life_event.source_event_ids = [
                event_id for event_id in dict.fromkeys(life_event.source_event_ids)
                if event_id in valid_ids
            ][:20]

        tracer.log("handoff", "resolved_state_to_decision", {
            "from": "debate" if debate_result.resolution_status != "not_required" else "life_event_inference",
            "to": "decision_agent",
            "debate_status": debate_result.resolution_status,
            "resolved_state": life_event.inferred_state,
        })
        decision = timed("decision", lambda: decision_agent.decide(
            life_event,
            semantic_policy=semantic_memory,
            context={
                "customer_state": analysis_state.summary(),
                "specialist_findings": [safe_model_dump(f) for f in findings],
                "correlated_signals": [safe_model_dump(s) for s in signals],
                "evidence": life_event.evidence,
                "memory": episodic_memory,
                "debate": safe_model_dump(debate_result),
                "prior_action_history": [safe_model_dump(a) for a in state.action_history[-10:]],
            },
        ))
        if debate_result.resolution_status == "unresolved":
            decision.requires_human_review = True
            decision.hitl_status = "escalated"
            if "unresolved_agent_conflict" not in decision.risk_flags:
                decision.risk_flags.append("unresolved_agent_conflict")
        print("\nDECISION")
        print(f"  Action   : {decision.action}")
        print(f"  Subtype  : {decision.action_subtype}")
        print(f"  HITL     : {decision.hitl_status}")
        print(f"  Provider : {decision.decision_provider}")
        print(f"  Rationale: {decision.rationale}")
        tracer.log("latency", "checkpoint_to_decision", {"event_id": as_of_event.event_id, "latency_ms": round((time.perf_counter() - checkpoint_wall_start) * 1000, 2)})
        tracer.log("decision", "decision_result", safe_model_dump(decision))
        log_llm_boundary(tracer, "decision", decision_agent.last_provider, decision_agent.last_prompt, decision_agent.last_error)

        # Lifecycle deduplication is deliberately kept separate from inference.
        # Repeated evidence must never turn a valid semantic decision into no_action; it only
        # controls whether an already-pending side effect is refreshed or a new action record is created.
        equivalent = [
            a for a in state.action_history
            if a.action == decision.action
            and a.action_subtype == decision.action_subtype
            and a.inferred_state == life_event.inferred_state
        ]
        pending_equivalent = [a for a in equivalent if a.status == "pending_human_review"]
        resolved_equivalent = [a for a in equivalent if a.status in {"approved", "modified", "executed"}]
        current_evidence_ids = set(life_event.source_event_ids)
        exact_evidence_repeat = any(set(a.source_event_ids) == current_evidence_ids for a in equivalent)
        duplicate_suppressed = False
        lifecycle_event = "new_action_record"
        if pending_equivalent:
            lifecycle_event = "refresh_existing_pending"
            print("\n[ACTION LIFECYCLE] Existing pending action refreshed with the latest evidence/draft; no duplicate side effect created.")
        elif resolved_equivalent and exact_evidence_repeat:
            lifecycle_event = "repeat_resolved_same_evidence"
            duplicate_suppressed = True
            print("\n[ACTION LIFECYCLE] Identical already-resolved action observed; execution remains suppressed, but inference output is preserved.")
        elif resolved_equivalent:
            lifecycle_event = "new_action_after_new_evidence"
            print("\n[ACTION LIFECYCLE] New evidence package permits a distinct action after a prior resolved action.")
        tracer.log("decision", "lifecycle_check", {
            "equivalent": [safe_model_dump(a) for a in equivalent[-5:]],
            "same_evidence_package": exact_evidence_repeat,
            "duplicate_suppression": duplicate_suppressed,
            "lifecycle_event": lifecycle_event,
        })

        tracer.log("handoff", "decision_to_offer", {
            "from": "decision_agent",
            "to": "offer_eligibility_agent",
            "action": decision.action,
            "action_subtype": decision.action_subtype,
        })
        offer = timed("offer", lambda: offer_agent.evaluate(life_event, decision))
        action_proposal = timed("retention_action", lambda: action_agent.propose(decision, life_event, offer))
        print(f"\nRETENTION / ACTION PROPOSAL: {action_proposal.action} | {action_proposal.purpose}")
        tracer.log("action", "proposal", safe_model_dump(action_proposal))
        print(f"\nOFFER / ELIGIBILITY: {offer.offer_type} | {offer.eligibility_status}")
        tracer.log("offer", "eligibility_result", safe_model_dump(offer))

        drafts: list[Any] = []
        critique_results: list[Any] = []
        critique_rounds: list[list[Any]] = []
        guardrail_result = None
        execution_result = None
        hitl_result = None
        original_message = ""
        selected_draft_id = None

        if decision.action != "no_action" and not duplicate_suppressed:
            # Do not re-spend provider quota on an already-pending customer-facing action.
            # The pending record already contains a compliant, human-reviewable message.
            existing_pending_record = pending_equivalent[-1] if pending_equivalent else None
            if existing_pending_record is not None and existing_pending_record.original_message:
                from drafting import ActionDraft
                drafts = [ActionDraft(
                    customer_id=customer_id,
                    draft_id=existing_pending_record.draft_id or "draft_reused",
                    agent_name="customer_experience_agent",
                    action=decision.action,
                    action_subtype=decision.action_subtype or "review",
                    message=existing_pending_record.final_message or existing_pending_record.original_message,
                    rationale=decision.rationale,
                    risk_flags=list(decision.risk_flags),
                    draft_status="final",
                    round_number=3,
                    revision_notes="Reused previously compliance-reviewed pending draft; no new provider call required.",
                )]
                critique_results = [CritiqueResult(
                    draft_id=drafts[0].draft_id,
                    agent_name="critique_compliance_agent",
                    status="approved",
                    explanation="Previously reviewed pending draft reused without changing customer-facing content.",
                    reviewer_assessments=[ReviewerAssessment(reviewer=r, verdict="approved") for r in CritiqueComplianceAgent.REVIEWERS],
                )]
                drafting_agent.last_provider = "reuse_existing_pending"
                drafting_agent.last_prompt = "Pending action reuse: provider drafting skipped because an existing pending draft was already reviewed."
                drafting_agent.last_error = None
                critique_agent.last_provider = "reuse_existing_pending"
                critique_agent.last_prompt = "Pending action reuse: provider critique skipped because the existing pending draft was already reviewed."
                critique_agent.last_error = None
                print("\n[DRAFTING] Reusing existing compliance-reviewed pending draft; no Groq call spent.")
                print_drafting(drafts)
                print("\n[CRITIQUE] Reusing prior approved compliance result; no Groq call spent.")
                print_critique(critique_results)
            else:
                tracer.log("handoff", "offer_to_round_robin_drafting", {
                    "from": "offer_eligibility_agent",
                    "to": "round_robin_drafting_agent",
                    "action": decision.action,
                    "offer_type": offer.offer_type,
                })
                drafts = timed("drafting", lambda: drafting_agent.generate_drafts(
                    decision=decision,
                    life_event=life_event,
                    offer=offer,
                    context={
                        "evidence": life_event.evidence,
                        "specialist_findings": [safe_model_dump(f) for f in findings],
                        "episodic_memory": episodic_memory,
                        "relevant_event_memory": relevant_event_memory,
                    },
                    action_proposal=action_proposal.model_dump(),
                ))
                drafting_agent.finalize_round_robin(drafts)
                print_drafting(drafts)
                tracer.log("drafting", "drafts", [safe_model_dump(d) for d in drafts])
                log_llm_boundary(tracer, "drafting", drafting_agent.last_provider, drafting_agent.last_prompt, drafting_agent.last_error)

                tracer.log("handoff", "drafting_to_critique", {
                    "from": "round_robin_drafting_agent",
                    "to": "critique_compliance_agent",
                    "draft_ids": [d.draft_id for d in drafts],
                })
                critique_results = timed("critique", lambda: critique_agent.review_drafts(drafts, offer))
                critique_rounds.append(critique_results)
                print_critique(critique_results)
                drafts = critique_agent.apply_refinement(drafts, critique_results)

                # A refinement is a new customer-facing artifact, so run the compliance gate again.
                if any(r.status == "needs_revision" and r.revised_message for r in critique_results):
                    final_critique = timed("critique_recheck", lambda: critique_agent.review_drafts(drafts, offer))
                    critique_rounds.append(final_critique)
                    critique_results = final_critique
                    drafts = critique_agent.apply_refinement(drafts, final_critique)
                    print("\nCRITIQUE RE-CHECK AFTER REFINEMENT")
                    print_critique(final_critique)

            tracer.log("critique", "results", [safe_model_dump(r) for r in critique_results])
            tracer.log("critique", "rounds", [[safe_model_dump(r) for r in batch] for batch in critique_rounds])
            log_llm_boundary(tracer, "critique", critique_agent.last_provider, critique_agent.last_prompt, critique_agent.last_error)
        else:
            print_drafting([])
            print_critique([])
            tracer.log("drafting", "drafts", [])
            tracer.log("critique", "results", [])

        tracer.log("handoff", "critique_to_guardrail", {
            "from": "critique_compliance_agent",
            "to": "deterministic_guardrail",
            "draft_ids": [d.draft_id for d in drafts],
        })
        guardrail_result = timed("guardrail", lambda: guardrail_agent.evaluate(decision, offer, critique_results, drafts))
        print("\nGUARDRAIL")
        print(f"  Decision : {guardrail_result.decision}")
        print(f"  HITL     : {guardrail_result.hitl_status}")
        print(f"  Reason   : {guardrail_result.reason}")
        print(f"  Flags    : {', '.join(guardrail_result.guardrail_flags) if guardrail_result.guardrail_flags else 'None'}")
        if duplicate_suppressed and decision.action != "no_action":
            guardrail_result = guardrail_result.model_copy(update={
                "decision": "blocked",
                "hitl_status": "auto_approved",
                "selected_draft_id": None,
                "reason": "Identical resolved action with the same evidence package is suppressed at the side-effect boundary.",
                "guardrail_flags": list(dict.fromkeys(guardrail_result.guardrail_flags + ["duplicate_side_effect_suppressed"])),
            })
            tracer.log("action_lifecycle", "duplicate_side_effect_suppressed", {
                "action": decision.action,
                "action_subtype": decision.action_subtype,
                "source_event_ids": life_event.source_event_ids[:20],
            })

        tracer.log("guardrail", "result", safe_model_dump(guardrail_result))

        # Preserve the pre-human-review state separately from the final human disposition.
        # A checkpoint that required HITL must remain "escalated" even if the human later approves/rejects it.
        hitl_requirement_status = (
            "escalated"
            if guardrail_result.decision == "requires_human_review" or decision.hitl_status == "escalated"
            else "auto_approved"
        )

        # Create the proposed action record before HITL so the approval checkpoint has a durable object.
        approved_drafts = [d for d in drafts if any(r.draft_id == d.draft_id and r.status == "approved" for r in critique_results)]
        selected_draft = None
        if guardrail_result.selected_draft_id:
            selected_draft = next((d for d in drafts if d.draft_id == guardrail_result.selected_draft_id), None)
        if selected_draft is None and approved_drafts:
            selected_draft = approved_drafts[-1]
        if selected_draft is not None:
            selected_draft_id = selected_draft.draft_id
            original_message = selected_draft.message

        action_record = None
        if decision.action != "no_action" and guardrail_result.decision != "blocked" and selected_draft is not None:
            # Reuse an existing pending record instead of generating duplicate customer-facing side effects.
            existing_pending = next((a for a in reversed(state.action_history) if a.status == "pending_human_review" and a.action == decision.action and a.action_subtype == decision.action_subtype and a.inferred_state == life_event.inferred_state), None)
            if existing_pending is not None:
                action_record = existing_pending
                action_record.source_event_ids = list(dict.fromkeys(action_record.source_event_ids + life_event.source_event_ids))[:20]
                action_record.original_message = original_message
                action_record.final_message = original_message
                action_record.draft_id = selected_draft.draft_id
                tracer.log("action_lifecycle", "refreshed", safe_model_dump(action_record))
            else:
                record_status = "pending_human_review" if guardrail_result.decision == "requires_human_review" else "proposed"
                action_record = ActionRecord(
                    action_id=f"ACT_{uuid4().hex[:12]}",
                    customer_id=customer_id,
                    inferred_state=life_event.inferred_state,
                    action=decision.action,
                    action_subtype=decision.action_subtype,
                    original_message=original_message,
                    final_message=original_message,
                    draft_id=selected_draft.draft_id,
                    source_event_ids=life_event.source_event_ids[:20],
                    status=record_status,
                    created_at=datetime.now(timezone.utc),
                )
                state.action_history.append(action_record)
                tracer.log("action_lifecycle", "proposed", safe_model_dump(action_record))
            state.pending_action_id = action_record.action_id if guardrail_result.decision == "requires_human_review" else None

            if guardrail_result.decision == "requires_human_review":
                context = {
                    "specialist_findings": [safe_model_dump(f) for f in findings],
                    "correlated_signals": [safe_model_dump(s) for s in signals],
                    "life_event": safe_model_dump(life_event),
                    "debate": safe_model_dump(debate_result),
                    "offer": safe_model_dump(offer),
                    "guardrail": safe_model_dump(guardrail_result),
                    "evidence": life_event.evidence,
                    "source_event_ids": life_event.source_event_ids,
                    "memory": {"episodic": episodic_memory, "relevant_events": relevant_event_memory},
                }
                if hitl_adapter is not None:
                    tracer.log("handoff", "guardrail_to_hitl", {
                        "from": "deterministic_guardrail",
                        "to": "human_approver",
                        "action_id": action_record.action_id if action_record else None,
                        "draft_id": selected_draft.draft_id if selected_draft else None,
                        "why_available": True,
                    })
                    hitl_result = hitl_adapter.review(decision, original_message, context)
                    if hitl_result is None:
                        action_record.status = "blocked" if action_record is not None else "blocked"
                        if action_record is not None:
                            action_record.resolved_at = datetime.now(timezone.utc)
                        state.pending_action_id = None
                        tracer.log("hitl", "adapter_returned_none", {"action_id": action_record.action_id if action_record else None})
                        decision.hitl_status = "timed_out"
                        decision.requires_human_review = False
                        guardrail_result = guardrail_result.model_copy(update={
                            "decision": "blocked",
                            "hitl_status": "timed_out",
                            "reason": "HITL adapter returned no decision; fail-closed before execution.",
                        })
                    else:
                        if action_record is not None:
                            action_record.original_message = hitl_result.original_message
                            action_record.final_message = hitl_result.final_message
                            action_record.status = {
                                "human_approved": "approved",
                                "human_modified": "modified",
                                "human_rejected": "rejected",
                                "timed_out": "blocked",
                            }.get(hitl_result.status, "blocked")
                            action_record.resolved_at = datetime.now(timezone.utc)
                            if hitl_result.status == "human_modified":
                                action_record.modification_reason = "Human-modified message requires post-HITL safety recheck."
                            if hitl_result.status == "human_rejected":
                                action_record.rejection_reason = "Human rejected the proposed intervention."
                        state.pending_action_id = None
                        tracer.log("hitl", "decision", safe_model_dump(hitl_result))
                        decision.hitl_status = hitl_result.status
                        decision.requires_human_review = False

                        if hitl_result.status == "human_modified" and selected_draft is not None:
                            selected_draft.message = hitl_result.final_message
                            selected_draft.draft_status = "revised"
                            post_hitl_critique = critique_agent.review_drafts([selected_draft], offer)
                            tracer.log("critique", "post_hitl", [safe_model_dump(r) for r in post_hitl_critique])
                            post_hitl_guardrail = guardrail_agent.evaluate(
                                decision, offer, post_hitl_critique, [selected_draft], human_clearance=True
                            )
                            tracer.log("guardrail", "post_hitl_result", safe_model_dump(post_hitl_guardrail))
                            if post_hitl_guardrail.decision != "approved_for_execution":
                                if action_record is not None:
                                    action_record.status = "blocked"
                                decision.hitl_status = "escalated"
                                guardrail_result = post_hitl_guardrail
                            else:
                                guardrail_result = post_hitl_guardrail.model_copy(update={
                                    "decision": "approved_for_execution",
                                    "hitl_status": "human_modified",
                                    "selected_draft_id": selected_draft.draft_id,
                                    "reason": "Human-modified message passed post-HITL critique and guardrail validation.",
                                })
                                if action_record is not None:
                                    action_record.status = "modified"
                        elif hitl_result.status == "human_approved":
                            guardrail_result = guardrail_result.model_copy(update={
                                "decision": "approved_for_execution",
                                "hitl_status": "human_approved",
                                "selected_draft_id": selected_draft.draft_id if selected_draft else guardrail_result.selected_draft_id,
                                "reason": "Human approved the proposed action after reviewing the evidence and draft.",
                            })
                        elif hitl_result.status in {"human_rejected", "timed_out"}:
                            guardrail_result = guardrail_result.model_copy(update={
                                "decision": "blocked",
                                "hitl_status": hitl_result.status,
                                "reason": "Human rejected or timed out; the action remains blocked.",
                            })
                else:
                    # No interactive adapter means no real HITL happened. Fail closed.
                    if action_record is not None:
                        action_record.status = "pending_human_review"
                    state.pending_action_id = action_record.action_id if action_record is not None else None
                    tracer.log("hitl", "waiting_for_human", {
                        "action_id": action_record.action_id if action_record else None,
                        "reason": "Customer-facing/costly action requires a real human checkpoint.",
                    })

        # Execution is a simulated safe adapter: it never calls a real bank/customer API.
        execution_result = timed("execution", lambda: execution_agent.execute(guardrail_result, drafts))
        tracer.log("latency", "checkpoint_to_action", {"event_id": as_of_event.event_id, "latency_ms": round((time.perf_counter() - checkpoint_wall_start) * 1000, 2)})
        print(f"\nEXECUTION: {execution_result.execution_status} | {execution_result.execution_message}")
        tracer.log("execution", "result", safe_model_dump(execution_result))

        if state.action_history and selected_draft_id:
            record = next((a for a in reversed(state.action_history) if a.draft_id == selected_draft_id), None)
            if record is not None:
                if execution_result.execution_status == "executed":
                    record.status = "executed"
                    record.resolved_at = record.resolved_at or datetime.now(timezone.utc)
                elif execution_result.execution_status == "blocked":
                    record.status = "blocked"
                    record.resolved_at = record.resolved_at or datetime.now(timezone.utc)
                elif execution_result.execution_status == "pending_human_review":
                    record.status = "pending_human_review"

        hitl_status = decision.hitl_status
        if guardrail_result.decision == "requires_human_review" and decision.hitl_status == "auto_approved":
            hitl_status = "escalated"
        if guardrail_result.decision == "blocked" and hitl_result is None:
            hitl_status = guardrail_result.hitl_status
        if decision.action == "no_action":
            hitl_status = "auto_approved"

        inferred = InferredEvent(
            timestamp=as_of_event.event_time,
            as_of_time=as_of_event.event_time,
            customer_id=customer_id,
            inferred_state=life_event.inferred_state,
            confidence=life_event.confidence,
            confidence_band=life_event.confidence_band,
            action=decision.action,
            action_subtype=decision.action_subtype,
            hitl_status=hitl_status,
            hitl_requirement_status=hitl_requirement_status,
            notes=(
                f"triggers={','.join(trigger_reasons)}; provider_life={life_event.inference_provider}; "
                f"provider_decision={decision.decision_provider}; debate={debate_result.resolution_status}; "
                f"guardrail={guardrail_result.decision}; execution={execution_result.execution_status}; "
                f"duplicate_suppressed={duplicate_suppressed}"
            ),
            evidence=life_event.evidence[:10],
            source_event_ids=life_event.source_event_ids[:20] or [e.event_id for e in events_as_of[-12:]],
            memory_refs=[f"episodic:{len(episodic_memory)}", "semantic:shared_policy"],
            decision_trace_id=tracer.trace_id,
        )
        inferred_writer.write(inferred)
        memory.write_episode(
            inferred_state=life_event.inferred_state,
            action=decision.action,
            confidence=life_event.confidence,
            evidence=life_event.evidence,
            event_ids=inferred.source_event_ids,
            outcome=execution_result.execution_status,
            action_subtype=decision.action_subtype,
            hitl_status=hitl_status,
            original_message=original_message or None,
            final_message=(hitl_result.final_message if hitl_result else original_message) or None,
        )

        final = {
            "scenario_id": scenario_id,
            "customer_id": customer_id,
            "life_event": life_event,
            "decision": decision,
            "offer": offer,
            "drafts": drafts,
            "critique": critique_results,
            "guardrail": guardrail_result,
            "execution": execution_result,
            "debate": debate_result,
            "conflict": conflict,
            "as_of_event": as_of_event,
            "inference_number": inference_count,
        }
        last_result = final
        write_run_status(
            scenario_id,
            "running",
            customer_id=customer_id,
            accepted=accepted_count,
            duplicates=duplicate_count,
            late_events=late_count,
            total_state_events=state.total_events,
            inference_count=inference_count,
            last_checkpoint={
                "event_id": as_of_event.event_id,
                "event_time": as_of_event.event_time.isoformat(),
                "state": life_event.inferred_state,
                "action": decision.action,
                "debate": debate_result.resolution_status,
            },
        )
        return final

    # ------------------------------------------------------------
    # LIVE STREAM: ingestion is separated from decision checkpoints.
    # ------------------------------------------------------------
    print_separator("LIVE EVENT STREAM")
    for event in sorted(live_events, key=lambda e: (e.ingestion_time, e.event_id)):
        early = guardrail_agent.precheck_event(event)
        tracer.log("guardrail", "event_precheck", {"event": safe_model_dump(event), "result": safe_model_dump(early)})
        if early.triggered:
            total_hard_stops += 1
            hard_stop_event_ids.add(event.event_id)
            print(f"[{event.event_time}] {event.event_type:<28} -> HARD STOP: {early.route}")

        routed = router.route(event)
        stream_result = stream.process(event)
        if stream_result["status"] == "duplicate":
            duplicate_count += 1
            print(f"[{event.event_time}] {event.event_type:<28} -> duplicate ignored")
            continue
        accepted_count += 1
        if stream_result.get("is_late"):
            late_count += 1
        accepted_live.append(event)
        state.update(event)
        memory.index_event(event)
        feature_snapshot = live_features.ingest(event)
        trigger_signals = ambient_triggers.evaluate(event)
        tracer.log("stream_transform", "live_features_updated", {
            "event_id": event.event_id,
            "event_time": event.event_time.isoformat(),
            "is_late": bool(stream_result.get("is_late")),
            "watermark": stream_result.get("watermark"),
            "features": feature_snapshot.__dict__,
        })
        tracer.log("trigger", "ambient_trigger_signals", {
            "event_id": event.event_id,
            "signals": [x.__dict__ for x in trigger_signals],
        })
        print(f"[{event.event_time}] {event.event_type:<28} -> {routed['target']}")
        print(f"  LIVE TRANSFORM: logins14d={feature_snapshot.usage_14d_logins} | support14d={feature_snapshot.support_14d_tickets} | tx30d={feature_snapshot.tx_30d_count}")
        tracer.log("ingestion", "event_accepted", {"event": safe_model_dump(event), "route": routed, "is_late": stream_result.get("is_late", False), "watermark": stream_result.get("watermark")})

        if stream_result.get("is_late"):
            rebuild_state()
            tracer.log("ingestion", "late_event_rebuild", {"event_id": event.event_id, "event_time": event.event_time.isoformat()})

        # Hard-stop conditions bypass the normal autonomous decision pipeline.
        # The event remains ingested and auditable, but no specialist->decision->draft->execution
        # chain is allowed to run for this event. It is routed to the specialized queue.
        if early.triggered:
            hard_stop_record = {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "event_id": event.event_id,
                "event_time": event.event_time.isoformat(),
                "customer_id": customer_id,
                "route": early.route,
                "reason": early.reason,
                "flags": early.flags,
                "status": "specialized_review_required",
            }
            with hard_stop_path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(redact_sensitive(hard_stop_record), ensure_ascii=False) + "\n")
            tracer.log("guardrail", "hard_stop_bypass", hard_stop_record)
            print("  Normal autonomous pipeline bypassed; routed to specialized review.")
            continue

        # Agent-dependent trigger uses the shared state board, not hidden reasoning.
        trigger_findings = specialists.run(state, [e for e in state.all_events if e.event_time <= state.last_event_time and e.event_id not in hard_stop_event_ids])
        trigger = checkpoint.observe(event, trigger_findings)
        tracer.log("trigger", "decision_checkpoint", {
            "event_id": event.event_id,
            "should_infer": trigger.should_infer,
            "reasons": trigger.reasons,
        })
        if trigger.should_infer:
            run_inference(event, list(dict.fromkeys(trigger.reasons)))

    # ------------------------------------------------------------
    # Final consistency checkpoint: never leave the last accepted event unanalysed.
    # ------------------------------------------------------------
    latest_event = max(accepted_live, key=lambda e: (e.event_time, e.ingestion_time, e.event_id)) if accepted_live else None
    if latest_event is not None and last_inference_event_id != latest_event.event_id:
        run_inference(latest_event, ["final_event_time_consistency_check"])

    if last_result is None:
        # Empty live streams are still valid runs; create an explicit no-action artifact.
        reference = history_events[-1] if history_events else Event(
            event_id="NO_EVENT",
            event_time=datetime.now(timezone.utc),
            ingestion_time=datetime.now(timezone.utc),
            customer_id=customer_id,
            account_id=None,
            source_system="system",
            event_type="empty_stream",
            schema_version="1",
            payload={},
        )
        last_result = run_inference(reference, ["empty_or_non_triggering_stream"])

    tracer.log("llm_provider", "run_stats", llm_run_stats())

    evaluation = evaluator.evaluate_run(
        scenario_id=scenario_id,
        inferred_path=str(inferred_path),
        final_result={
            "life_event": last_result["life_event"],
            "decision": last_result["decision"],
            "execution": last_result["execution"],
        },
        late_events=late_count,
        trace_path=str(tracer.path),
        audit_path=str(audit_path),
        hard_stop_path=str(hard_stop_path),
    )
    evaluation["operational"] = {
        "hard_stop_events": total_hard_stops,
        "inference_count": inference_count,
        "accepted_events": accepted_count,
        "duplicate_events": duplicate_count,
        "late_events": late_count,
        "trace_id": tracer.trace_id,
        "memory_scope_id": memory_scope,
        "llm": llm_run_stats(),
    }
    evaluation_path.write_text(json.dumps(evaluation, indent=2, ensure_ascii=False, default=str), encoding="utf-8")

    write_run_status(
        scenario_id,
        "completed",
        customer_id=customer_id,
        accepted=accepted_count,
        duplicates=duplicate_count,
        late_events=late_count,
        total_state_events=state.total_events,
        inference_count=inference_count,
        last_checkpoint={
            "event_id": last_result["as_of_event"].event_id,
            "event_time": last_result["as_of_event"].event_time.isoformat(),
            "state": last_result["life_event"].inferred_state,
            "action": last_result["decision"].action,
            "execution": last_result["execution"].execution_status,
        },
    )

    print_separator("RUN COMPLETE")
    print(f"Inference checkpoints : {inference_count}")
    print(f"Accepted events       : {accepted_count}")
    print(f"Duplicates            : {duplicate_count}")
    print(f"Late events           : {late_count}")
    print(f"Hard-stop events      : {total_hard_stops}")
    llm_stats = llm_run_stats()
    print(f"LLM provider attempts : {llm_stats['provider_attempts']} / {configured_call_cap()} cap")
    print(f"LLM stages            : {os.getenv('C360_LLM_STAGES', 'life_event,debate,draft,critique')}")
    print(f"Final state           : {last_result['life_event'].inferred_state}")
    print(f"Final action          : {last_result['decision'].action}")
    actionable = next((r for r in reversed(state.action_history) if r.action != "no_action"), None)
    print(f"Latest actionable     : {actionable.action if actionable else 'none'}")
    if actionable:
        print(f"Latest action status  : {actionable.status}")
    print(f"Final execution       : {last_result['execution'].execution_status}")
    print(f"Trace                 : {tracer.path}")
    print(f"Inferred events       : {inferred_path}")
    print(f"Evaluation            : {evaluation_path}")
    print(f"HITL audit            : {audit_path}")
    print(f"Hard-stop queue       : {hard_stop_path}")

    try:
        evaluator.print_summary(evaluation)
    except AttributeError:
        pass

    return {
        "scenario_id": scenario_id,
        "trace_id": tracer.trace_id,
        "inference_count": inference_count,
        "accepted_events": accepted_count,
        "duplicate_events": duplicate_count,
        "late_events": late_count,
        "hard_stop_events": total_hard_stops,
        "final": last_result,
        "evaluation": evaluation,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Agentic Customer 360 — Proactive Intervention Desk")
    parser.add_argument("--scenario", default="scenario_01", help="scenario_01, scenario_02, scenario_03, or all")
    parser.add_argument("--interactive-hitl", action="store_true", help="Use real terminal HITL for escalated actions")
    parser.add_argument("--ui-hitl", action="store_true", help="Use file-backed HITL for the Streamlit control room")
    parser.add_argument("--checkpoint-interval", type=int, default=30, help="Minimum event spacing between generic inference checkpoints")
    parser.add_argument("--parallel", type=int, default=4, help="Number of specialist swarm workers (scenarios remain isolated and sequential)")
    args = parser.parse_args()

    scenarios = [p.name for p in discover_scenarios(BASE_DIR)]
    selected = scenarios if args.scenario.lower() == "all" else [args.scenario]
    for scenario_id in selected:
        try:
            run_scenario(
                scenario_id,
                interactive_hitl=args.interactive_hitl,
                checkpoint_interval=args.checkpoint_interval,
                ui_hitl=args.ui_hitl,
                specialist_workers=max(1, args.parallel),
            )
        except KeyboardInterrupt:
            print("\nRun interrupted by user.")
            return 130
        except Exception as exc:
            write_run_status(scenario_id, "failed", error=f"{type(exc).__name__}: {exc}")
            print_separator(f"RUN FAILED: {scenario_id}")
            print(f"{type(exc).__name__}: {exc}")
            if args.scenario.lower() != "all":
                raise
            # For --all, isolate failures so one scenario cannot corrupt another run.
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
