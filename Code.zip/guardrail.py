from __future__ import annotations

from typing import Literal, Any

from pydantic import BaseModel, Field


class EarlyGuardrailResult(BaseModel):
    triggered: bool
    action: Literal["continue", "hard_stop"]
    route: str
    reason: str
    flags: list[str] = Field(default_factory=list)


class GuardrailResult(BaseModel):
    customer_id: str
    decision: Literal["approved_for_execution", "requires_human_review", "blocked", "no_action_required"]
    hitl_status: Literal["auto_approved", "escalated", "human_approved", "human_rejected", "human_modified", "timed_out"]
    selected_draft_id: str | None = None
    reason: str
    guardrail_flags: list[str] = Field(default_factory=list)


class GuardrailHITLAgent:
    """Deterministic safety boundary; model output cannot bypass these rules."""

    HARD_STOP_TERMS = (
        "lawsuit", "legal action", "attorney", "sue us", "sue you",
        "self-harm", "self harm", "suicide", "sanctions evasion",
    )

    def __init__(self):
        self.name = "guardrail_hitl_agent"

    def precheck_event(self, event: Any) -> EarlyGuardrailResult:
        payload = getattr(event, "payload", {}) or {}
        searchable = " ".join(
            str(payload.get(k, ""))
            for k in ("raw_text", "search_text", "merchant_name", "counterparty_name", "feature_or_page", "transaction_type")
        )
        lower = searchable.lower()
        matched = [term for term in self.HARD_STOP_TERMS if term in lower]
        if matched:
            return EarlyGuardrailResult(
                triggered=True,
                action="hard_stop",
                route="specialized_compliance_or_safety_queue",
                reason="Event matched a deterministic hard-stop condition; normal outbound-action autonomy is bypassed.",
                flags=["hard_stop:" + x for x in matched],
            )
        return EarlyGuardrailResult(
            triggered=False,
            action="continue",
            route="normal_pipeline",
            reason="No event-level hard-stop condition matched.",
        )

    def evaluate(self, decision, offer, critique_results, drafts=None, *, human_clearance: bool = False) -> GuardrailResult:
        """Return the only four states the execution boundary may receive.

        ``human_clearance`` is only used after a real approve/modify response has
        been recorded by HITL. It prevents the second safety check from treating
        the already recorded human approval as if it never happened.
        """
        texts = [decision.rationale]
        texts.extend(d.message for d in (drafts or []))
        combined = " ".join(texts).lower()
        matched = [term for term in self.HARD_STOP_TERMS if term in combined]
        if matched:
            return GuardrailResult(
                customer_id=decision.customer_id,
                decision="requires_human_review",
                hitl_status="escalated",
                selected_draft_id=None,
                reason="Deterministic hard-stop condition triggered; outbound communication is blocked pending specialized review.",
                guardrail_flags=["hard_stop:" + x for x in matched] + ["autonomy_bypassed"],
            )

        if decision.action == "no_action":
            return GuardrailResult(
                customer_id=decision.customer_id,
                decision="no_action_required",
                hitl_status="auto_approved",
                selected_draft_id=None,
                reason="No customer-facing action is required.",
                guardrail_flags=["no_action"],
            )

        if decision.action == "personalized_offer" and offer.eligibility_status != "eligible":
            if offer.eligibility_status == "manual_review":
                approved = [r for r in critique_results if r.status == "approved"]
                selected_id = approved[-1].draft_id if approved else None
                if human_clearance and selected_id:
                    return GuardrailResult(
                        customer_id=decision.customer_id,
                        decision="approved_for_execution",
                        hitl_status="human_approved",
                        selected_draft_id=selected_id,
                        reason="Human clearance is recorded; the post-HITL policy and safety checks passed.",
                        guardrail_flags=["offer_eligibility_review", "human_clearance_recorded"],
                    )
                return GuardrailResult(
                    customer_id=decision.customer_id,
                    decision="requires_human_review",
                    hitl_status="escalated",
                    selected_draft_id=selected_id,
                    reason="Personalized offer eligibility requires human/policy review.",
                    guardrail_flags=["offer_eligibility_review", "human_review_required"],
                )
            return GuardrailResult(
                customer_id=decision.customer_id,
                decision="blocked",
                hitl_status="auto_approved",
                selected_draft_id=None,
                reason="Personalized offer is not eligible under the current policy.",
                guardrail_flags=["offer_not_eligible"],
            )

        approved = [r for r in critique_results if r.status == "approved"]
        # PS production bar: every customer-facing/costly action requires an
        # actual human checkpoint before execution, even when policy otherwise
        # permits the action.
        if decision.action != "no_action" and not human_clearance:
            if not approved:
                # Keep a real review checkpoint visible even when critique rejected all
                # drafts. The human may reject or modify; an approval cannot bypass the
                # compliance result because the post-HITL gate rechecks the draft.
                selected_id = drafts[-1].draft_id if drafts else None
                return GuardrailResult(
                    customer_id=decision.customer_id,
                    decision="requires_human_review",
                    hitl_status="escalated",
                    selected_draft_id=selected_id,
                    reason="Human review is required because no draft currently passes compliance; approve cannot bypass the compliance gate, while Modify can trigger a post-HITL recheck.",
                    guardrail_flags=["human_review_required", "no_compliant_draft"],
                )
            return GuardrailResult(
                customer_id=decision.customer_id,
                decision="requires_human_review",
                hitl_status="escalated",
                selected_draft_id=approved[-1].draft_id,
                reason="All customer-facing or costly interventions stop at a real human approval checkpoint before execution.",
                guardrail_flags=["human_review_required"],
            )

        if human_clearance:
            selected_id = approved[-1].draft_id if approved else None
            if not selected_id:
                return GuardrailResult(
                    customer_id=decision.customer_id,
                    decision="blocked",
                    hitl_status="human_approved",
                    selected_draft_id=None,
                    reason="Post-HITL validation failed because no compliant draft is available.",
                    guardrail_flags=["no_compliant_draft", "post_hitl_fail_closed"],
                )
            return GuardrailResult(
                customer_id=decision.customer_id,
                decision="approved_for_execution",
                hitl_status="human_approved",
                selected_draft_id=selected_id,
                reason="Human approval is recorded and the post-HITL safety/compliance gate passed.",
                guardrail_flags=["human_clearance_recorded"],
            )

        return GuardrailResult(
            customer_id=decision.customer_id,
            decision="approved_for_execution",
            hitl_status="auto_approved",
            selected_draft_id=approved[-1].draft_id if approved else None,
            reason="No customer-facing action remains after safety validation.",
        )
