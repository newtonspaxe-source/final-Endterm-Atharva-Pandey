from __future__ import annotations

from datetime import timedelta
from concurrent.futures import ThreadPoolExecutor
from typing import Literal

from pydantic import BaseModel, Field

from governance import authorize
from data_access import AgentContext, DataAccessLayer
from models import Event
from tools import kyc_lookup, sentiment_score, support_ticket_retrieval, transaction_baseline, windowed_usage


class AgentFinding(BaseModel):
    agent_name: str
    customer_id: str
    signal_type: str
    severity: Literal["low", "medium", "high"]
    direction: Literal["positive", "negative", "neutral"] = "neutral"
    evidence: list[str] = Field(default_factory=list)
    event_ids: list[str] = Field(default_factory=list)
    confidence: float = Field(ge=0.0, le=1.0)
    recommendation: str
    tools_used: list[str] = Field(default_factory=list)
    data_sources: list[str] = Field(default_factory=list)
    tool_results: dict[str, object] = Field(default_factory=dict)


class BaseAgent:
    def __init__(self, name: str):
        self.name = name

    def finding(
        self, customer_id: str, signal_type: str, severity: str, evidence: list[str],
        event_ids: list[str], confidence: float, recommendation: str,
        direction: str = "neutral", tools_used: list[str] | None = None,
        data_sources: list[str] | None = None, tool_results: dict[str, object] | None = None,
    ) -> AgentFinding:
        defaults = {
            "usage_agent": (["windowed_aggregation", "trend_detection", "anomaly_scoring"], ["web_app_events"]),
            "support_agent": (["ticket_retrieval", "sentiment_analysis", "urgency_detection"], ["support_logs"]),
            "transaction_agent": (["transaction_query", "anomaly_scoring", "historical_baseline"], list(TransactionAgent.TRANSACTION_SOURCES)),
            "kyc_compliance_agent": (["kyc_lookup", "sanctions_lookup", "compliance_rules"], ["loan_kyc"]),
        }
        default_tools, default_sources = defaults.get(self.name, ([], []))
        return AgentFinding(
            agent_name=self.name,
            customer_id=customer_id,
            signal_type=signal_type,
            severity=severity,
            direction=direction,
            evidence=evidence[:10],
            event_ids=event_ids[:20],
            confidence=max(0.0, min(1.0, float(confidence))),
            recommendation=recommendation,
            tools_used=tools_used or default_tools,
            data_sources=data_sources or default_sources,
            tool_results=tool_results or {},
        )


class UsageAgent(BaseAgent):
    def __init__(self):
        super().__init__("usage_agent")

    def analyze(self, state: AgentContext, events: list[Event]) -> AgentFinding:
        usage_events = [e for e in events if authorize(self.name, e.source_system)]
        if not usage_events:
            return self.finding(state.customer_id, "no_usage_signal", "low", ["No web/app events available."], [], 0.20, "No usage-based action.")

        latest = max(e.event_time for e in usage_events)
        recent_cutoff = latest - timedelta(days=14)
        prior_cutoff = latest - timedelta(days=28)
        recent = [e for e in usage_events if e.event_time >= recent_cutoff]
        prior = [e for e in usage_events if prior_cutoff <= e.event_time < recent_cutoff]
        recent_logins = sum(e.event_type == "login" for e in recent)
        prior_logins = sum(e.event_type == "login" for e in prior)
        win = windowed_usage(usage_events, days=14)
        evidence = [
            f"14-day usage window: {win['count']} events ({win['logins']} logins, {win['searches']} searches).",
            f"Recent-vs-prior 14-day login counts: {recent_logins} vs {prior_logins}.",
        ]
        event_ids = [e.event_id for e in recent[-10:]]
        if prior_logins >= 3 and recent_logins < prior_logins * 0.60:
            evidence.append("A material decline in login frequency was detected relative to the prior window.")
            return self.finding(state.customer_id, "usage_decline", "medium", evidence, event_ids, 0.78, "Correlate usage decline with support and transaction signals.", "negative", tool_results={"windowed_usage_14d": win, "recent_logins": recent_logins, "prior_logins": prior_logins})
        return self.finding(state.customer_id, "usage_activity", "low", evidence, event_ids, 0.60, "Continue monitoring usage behaviour.", "positive", tool_results={"windowed_usage_14d": win, "recent_logins": recent_logins, "prior_logins": prior_logins})


class SupportAgent(BaseAgent):
    def __init__(self):
        super().__init__("support_agent")

    def analyze(self, state: AgentContext, events: list[Event]) -> AgentFinding:
        support_events = support_ticket_retrieval([e for e in events if authorize(self.name, e.source_system)])
        if not support_events:
            return self.finding(state.customer_id, "no_support_signal", "low", ["No support events available."], [], 0.20, "No support intervention.")

        tickets = [e for e in support_events if e.event_type == "ticket_created"]
        unresolved = [e for e in tickets if e.payload.get("resolution_status") not in {"resolved", "closed"}]
        texts = [str(e.payload.get("raw_text", "")).strip() for e in support_events if str(e.payload.get("raw_text", "")).strip()]
        sentiments = [sentiment_score(t) for t in texts]
        average = sum(sentiments) / len(sentiments) if sentiments else 0.0
        evidence = [
            f"Observed {len(tickets)} support tickets and {len(unresolved)} unresolved ticket(s).",
            f"Support sentiment-tool average: {average:.3f}.",
        ]

        friction_terms = ("problem", "issue", "urgent", "help", "fee", "charged", "denied", "cannot", "unable", "refund", "payment plan")
        matched = [e for e in support_events if any(term in str(e.payload.get("raw_text", "")).lower() for term in friction_terms)]
        if matched:
            evidence.append(f"{len(matched)} support events contain customer-friction or assistance language.")
            return self.finding(state.customer_id, "support_friction", "medium", evidence, [e.event_id for e in matched], min(0.92, 0.68 + (0.10 if unresolved else 0.0) + (0.05 if average >= 0.10 else 0.0)), "Correlate support friction with other customer signals.", "negative", tool_results={"ticket_count": len(tickets), "unresolved_count": len(unresolved), "average_sentiment": round(average, 4), "matched_friction_events": len(matched)})
        return self.finding(state.customer_id, "support_activity", "low", evidence, [e.event_id for e in support_events[-10:]], 0.55, "Continue monitoring support interactions.", "positive", tool_results={"ticket_count": len(tickets), "unresolved_count": len(unresolved), "average_sentiment": round(average, 4)})


class TransactionAgent(BaseAgent):
    TRANSACTION_SOURCES = {"card_payments", "instant_payments", "ach_wire", "core_banking_ledger", "trading_brokerage"}

    def __init__(self):
        super().__init__("transaction_agent")

    def analyze(self, state: AgentContext, events: list[Event]) -> AgentFinding:
        tx = [e for e in events if authorize(self.name, e.source_system)]
        if not tx:
            return self.finding(state.customer_id, "no_transaction_signal", "low", ["No transaction events available."], [], 0.20, "No transaction action.")
        latest_time = max(e.event_time for e in tx)
        prior_tx = [e for e in tx if e.event_time < latest_time]
        baseline = transaction_baseline(prior_tx or tx)
        avg = float(baseline.get("average", 0.0) or 0.0)
        anomalous = [e for e in tx if isinstance(e.payload.get("amount"), (int, float)) and avg > 0 and float(e.payload["amount"]) >= avg * 3]
        declines = [e for e in tx if e.event_type in {"decline", "payment_declined"}]
        outbound = [e for e in tx if e.event_type == "outbound_transfer" and str(e.payload.get("direction", "")).lower() == "outbound"]
        evidence = [
            f"Observed {len(tx)} transaction-domain events; average amount field {avg:.2f}.",
            f"Observed {len(anomalous)} materially above-baseline transaction(s), {len(declines)} decline(s), and {len(outbound)} outbound transfer(s).",
        ]
        if anomalous:
            evidence.append("At least one transaction is materially above the observed amount baseline; context is required before any risk action.")
            return self.finding(state.customer_id, "transaction_anomaly", "medium", evidence, [e.event_id for e in anomalous[-10:]], 0.74, "Correlate unusual transactions with other customer signals.", "negative", tool_results={"baseline": baseline, "anomaly_count": len(anomalous), "decline_count": len(declines), "outbound_count": len(outbound)})
        if declines:
            return self.finding(state.customer_id, "transaction_friction", "medium", evidence, [e.event_id for e in declines[-10:]], 0.72, "Correlate transaction friction with support and usage signals.", "negative", tool_results={"baseline": baseline, "anomaly_count": len(anomalous), "decline_count": len(declines), "outbound_count": len(outbound)})
        return self.finding(state.customer_id, "transaction_activity", "low", evidence, [e.event_id for e in tx[-10:]], 0.68, "Continue monitoring transaction behaviour.", "positive", tool_results={"baseline": baseline, "anomaly_count": len(anomalous), "decline_count": len(declines), "outbound_count": len(outbound)})


class KYCComplianceAgent(BaseAgent):
    def __init__(self):
        super().__init__("kyc_compliance_agent")

    def analyze(self, state: AgentContext, events: list[Event]) -> AgentFinding:
        kyc_events = kyc_lookup([e for e in events if authorize(self.name, e.source_system)])
        if not kyc_events:
            return self.finding(state.customer_id, "no_kyc_signal", "low", ["No KYC/compliance events available."], [], 0.20, "No KYC action.")
        profile_changes = [e for e in kyc_events if e.event_type in {"address_change", "marital_status_change", "dependents_change"}]
        loan_events = [e for e in kyc_events if e.event_type in {"loan_application", "loan_disbursed"}]
        evidence = [f"Observed {len(kyc_events)} KYC/loan events, {len(profile_changes)} profile change(s), and {len(loan_events)} loan event(s)."]
        if profile_changes:
            evidence.append("Customer profile information changed and is available to downstream correlation.")
            return self.finding(state.customer_id, "profile_change", "medium", evidence, [e.event_id for e in profile_changes], 0.85, "Make updated customer profile available to downstream inference.", "neutral", tool_results={"kyc_event_count": len(kyc_events), "profile_change_count": len(profile_changes), "loan_event_count": len(loan_events)})
        return self.finding(state.customer_id, "kyc_activity", "low", evidence, [e.event_id for e in kyc_events[-10:]], 0.60, "Continue monitoring KYC/compliance events.", "neutral", tool_results={"kyc_event_count": len(kyc_events), "profile_change_count": len(profile_changes), "loan_event_count": len(loan_events)})


class SpecialistAgents:
    """Parallel swarm specialists; each specialist is isolated to authorized data sources."""
    def __init__(self, max_workers: int = 4):
        self.usage = UsageAgent()
        self.support = SupportAgent()
        self.transaction = TransactionAgent()
        self.kyc = KYCComplianceAgent()
        self.max_workers = max(1, int(max_workers))
        self.data_access = DataAccessLayer()

    def run(self, state, events: list[Event]) -> list[AgentFinding]:
        agents = [self.usage, self.support, self.transaction, self.kyc]
        context = self.data_access.context_for(state.customer_id)
        views = {agent.name: self.data_access.view_for(agent.name, context.customer_id, events).events for agent in agents}
        if self.max_workers <= 1:
            return [agent.analyze(context, list(views[agent.name])) for agent in agents]
        with ThreadPoolExecutor(max_workers=min(self.max_workers, len(agents)), thread_name_prefix="c360-specialist") as pool:
            futures = [pool.submit(agent.analyze, context, list(views[agent.name])) for agent in agents]
            return [future.result() for future in futures]
