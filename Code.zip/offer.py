from __future__ import annotations

from typing import Literal, Any

from pydantic import BaseModel, Field

from life_event import LifeEventResult
from decision import CustomerDecision
from policy_registry import PolicyRegistry


class OfferRecommendation(BaseModel):
    customer_id: str
    inferred_state: str
    action: str
    offer_type: str
    eligibility_status: Literal["eligible", "not_eligible", "manual_review"]
    rationale: str
    conditions: list[str] = Field(default_factory=list)
    risk_flags: list[str] = Field(default_factory=list)
    requires_human_review: bool = False


class OfferEligibilityAgent:
    """Policy-aware offer gate.

    It does not infer life events. It validates whether the selected action has an
    explicit offer/policy representation and otherwise fails closed.
    """

    def __init__(self):
        self.name = "offer_eligibility_agent"
        self.registry = PolicyRegistry()

    def evaluate(self, life_event: LifeEventResult, decision: CustomerDecision) -> OfferRecommendation:
        rule: dict[str, Any] = self.registry.for_state(life_event.inferred_state)
        configured_offer = rule.get("offer_type")

        if decision.action == "no_action":
            return OfferRecommendation(
                customer_id=life_event.customer_id,
                inferred_state=life_event.inferred_state,
                action=decision.action,
                offer_type="none",
                eligibility_status="not_eligible",
                rationale="No customer-facing offer is associated with an explicit no-action decision.",
            )

        if decision.action == "proactive_retention_outreach":
            offer_type = configured_offer or "retention_review"
            return OfferRecommendation(
                customer_id=life_event.customer_id,
                inferred_state=life_event.inferred_state,
                action=decision.action,
                offer_type=offer_type,
                eligibility_status="eligible",
                rationale="The bounded retention action can proceed to customer communication review.",
                conditions=["Use only approved retention/support options."],
                risk_flags=[],
                requires_human_review=(decision.action in set(rule.get("human_review_actions", []))),
            )

        if decision.action == "personalized_offer":
            if not configured_offer:
                return OfferRecommendation(
                    customer_id=life_event.customer_id,
                    inferred_state=life_event.inferred_state,
                    action=decision.action,
                    offer_type="unresolved_offer",
                    eligibility_status="manual_review",
                    rationale=(
                        "A personalized offer was proposed, but no explicit offer definition "
                        "exists in semantic policy. Human review is required rather than guessing eligibility."
                    ),
                    conditions=["Resolve product/offer eligibility through policy before execution."],
                    risk_flags=["offer_policy_missing"],
                    requires_human_review=True,
                )
            return OfferRecommendation(
                customer_id=life_event.customer_id,
                inferred_state=life_event.inferred_state,
                action=decision.action,
                offer_type=str(configured_offer),
                eligibility_status=(
                    "manual_review"
                    if decision.action in set(rule.get("human_review_actions", []))
                    else "eligible"
                ),
                rationale="The proposed personalized offer is represented in semantic policy; eligibility remains policy constrained.",
                conditions=["Confirm current product eligibility before customer contact."],
                risk_flags=[],
                requires_human_review=(decision.action in set(rule.get("human_review_actions", []))),
            )

        if decision.action in {"relationship_manager_escalation", "support_intervention"}:
            return OfferRecommendation(
                customer_id=life_event.customer_id,
                inferred_state=life_event.inferred_state,
                action=decision.action,
                offer_type="review_only",
                eligibility_status="not_eligible",
                rationale="The selected action is a human/support intervention rather than an automated product offer.",
                conditions=[],
                risk_flags=[],
                requires_human_review=True if decision.requires_human_review else False,
            )

        if decision.action == "compliance_fraud_hold":
            return OfferRecommendation(
                customer_id=life_event.customer_id,
                inferred_state=life_event.inferred_state,
                action=decision.action,
                offer_type="no_customer_offer",
                eligibility_status="manual_review",
                rationale="Compliance/fraud actions do not permit an automated customer offer.",
                conditions=["Compliance review required."],
                risk_flags=["compliance_review"],
                requires_human_review=True,
            )

        return OfferRecommendation(
            customer_id=life_event.customer_id,
            inferred_state=life_event.inferred_state,
            action=decision.action,
            offer_type="none",
            eligibility_status="not_eligible",
            rationale="No eligible offer is defined for the selected action.",
        )
