"""Defensive structured-output handling for every LLM boundary.

The project never trusts provider text directly. Each agent uses this module to
normalize provider responses, extract JSON from harmless formatting wrappers,
repair only conservative JSON damage, and validate the resulting schema in the
calling agent.
"""
from __future__ import annotations

import ast
import json
import re
from typing import Any


class StructuredOutputError(ValueError):
    """Raised when an LLM response cannot be converted into structured data."""


class EmptyLLMResponseError(StructuredOutputError):
    """Raised when a provider returns no usable final-content text."""


def response_text(response: Any) -> str:
    """Return only the model's final textual content.

    LangChain providers may return a string, an AIMessage, or content blocks.
    Reasoning/thinking metadata is deliberately *not* treated as final output:
    an agent asked for JSON must either return JSON or be considered unusable.
    """
    if response is None:
        return ""
    content = getattr(response, "content", response)
    if content is None:
        return ""
    if isinstance(content, str):
        return content.strip()

    # Some provider wrappers expose the response itself as a mapping. Prefer
    # explicit final-content fields and ignore reasoning/tool metadata.
    if isinstance(content, dict):
        block_type = str(content.get("type", "")).lower()
        if block_type in {"reasoning", "thinking", "analysis", "tool_call"}:
            return ""
        for key in ("text", "content", "output_text", "value"):
            value = content.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
        return ""

    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                if item.strip():
                    parts.append(item.strip())
                continue
            if isinstance(item, dict):
                block_type = str(item.get("type", "")).lower()
                # Do not turn explicit reasoning blocks into final JSON.
                if block_type in {"reasoning", "thinking", "analysis", "tool_call"}:
                    continue
                for key in ("text", "content", "value", "output_text"):
                    value = item.get(key)
                    if isinstance(value, str) and value.strip():
                        parts.append(value.strip())
                        break
                continue
            text = str(item).strip()
            if text:
                parts.append(text)
        return "\n".join(parts).strip()

    # Some message implementations expose final text in a dedicated attribute.
    for attr in ("text", "output_text"):
        value = getattr(response, attr, None)
        if isinstance(value, str) and value.strip():
            return value.strip()

    # IMPORTANT: do not fall back to reasoning_content. A reasoning-only reply
    # is not a valid completion for our JSON contract and should trigger the
    # provider retry/fallback path instead of contaminating the parser.
    return ""


def _strip_fences(text: str) -> str:
    value = text.strip()
    value = re.sub(r"^\s*```(?:json|javascript|js|text)?\s*", "", value, flags=re.I)
    value = re.sub(r"\s*```\s*$", "", value)
    return value.strip()


def _balanced_candidates(text: str) -> list[str]:
    pairs = {"{": "}", "[": "]"}
    closing = set(pairs.values())
    for start, char in enumerate(text):
        if char not in pairs:
            continue
        stack: list[str] = []
        in_string = False
        escaped = False
        for i in range(start, len(text)):
            ch = text[i]
            if in_string:
                if escaped:
                    escaped = False
                elif ch == "\\":
                    escaped = True
                elif ch == '"':
                    in_string = False
                continue
            if ch == '"':
                in_string = True
                continue
            if ch in pairs:
                stack.append(pairs[ch])
            elif ch in closing:
                if not stack or ch != stack[-1]:
                    break
                stack.pop()
                if not stack:
                    return [text[start : i + 1]]
    return []


def _extract_json_candidate(text: str) -> str:
    stripped = _strip_fences(text)
    if not stripped:
        raise EmptyLLMResponseError("LLM returned an empty response.")
    candidates = _balanced_candidates(stripped)
    if candidates:
        return candidates[0]
    raise StructuredOutputError("LLM response did not contain a balanced JSON object or array.")


def _remove_trailing_commas(text: str) -> str:
    return re.sub(r",\s*([}\]])", r"\1", text)


def _repair_control_chars(text: str) -> str:
    out: list[str] = []
    in_string = False
    escaped = False
    for ch in text:
        if in_string:
            if escaped:
                out.append(ch)
                escaped = False
            elif ch == "\\":
                out.append(ch)
                escaped = True
            elif ch == '"':
                out.append(ch)
                in_string = False
            elif ord(ch) < 32:
                out.append("\\n" if ch in "\r\n" else "\\t" if ch == "\t" else "")
            else:
                out.append(ch)
        else:
            out.append(ch)
            if ch == '"':
                in_string = True
    return "".join(out)


def _escape_unescaped_quotes(text: str) -> str:
    """Repair quotes inside JSON strings while preserving structural quotes."""
    out: list[str] = []
    in_string = False
    escaped = False
    i = 0
    while i < len(text):
        ch = text[i]
        if not in_string:
            out.append(ch)
            if ch == '"':
                in_string = True
            i += 1
            continue
        if escaped:
            out.append(ch)
            escaped = False
            i += 1
            continue
        if ch == "\\":
            out.append(ch)
            escaped = True
            i += 1
            continue
        if ch == '"':
            j = i + 1
            while j < len(text) and text[j].isspace():
                j += 1
            next_ch = text[j] if j < len(text) else ""
            if next_ch in {",", "]", "}", ":"}:
                out.append(ch)
                in_string = False
            else:
                out.append('\\"')
            i += 1
            continue
        out.append(ch)
        i += 1
    return "".join(out)


def _quote_bare_keys(text: str) -> str:
    return re.sub(r'([\{,]\s*)([A-Za-z_][A-Za-z0-9_-]*)\s*:', r'\1"\2":', text)


def _single_quote_fallback(text: str) -> Any:
    try:
        return ast.literal_eval(text)
    except (ValueError, SyntaxError, MemoryError, RecursionError):
        return None


def extract_json(text: str) -> Any:
    """Extract a JSON object/array from text with conservative repair."""
    raw = response_text(text)
    if not raw:
        raise EmptyLLMResponseError("LLM returned an empty response.")
    candidate = _extract_json_candidate(raw)
    attempts = [candidate]
    repaired = _repair_control_chars(_remove_trailing_commas(candidate))
    if repaired != candidate:
        attempts.append(repaired)
    escaped = _escape_unescaped_quotes(repaired)
    if escaped != repaired:
        attempts.append(escaped)
    quoted = _quote_bare_keys(escaped)
    if quoted != escaped:
        attempts.append(quoted)

    first_error: Exception | None = None
    for attempt in attempts:
        try:
            return json.loads(attempt)
        except json.JSONDecodeError as exc:
            first_error = first_error or exc

    literal = _single_quote_fallback(candidate)
    if literal is not None:
        return literal
    raise StructuredOutputError(f"Unable to parse structured JSON from LLM response: {first_error}")


def coerce_string_list(value: Any, *, max_items: int | None = None) -> list[str]:
    """Normalize provider list fields that drift into nested lists/scalars.

    This is deliberately shape-only repair: it never invents content. Nested lists
    are flattened and scalar values are stringified so the caller's Pydantic schema
    can validate the semantic payload.
    """
    out: list[str] = []

    def visit(item: Any) -> None:
        if max_items is not None and len(out) >= max_items:
            return
        if item is None:
            return
        if isinstance(item, list):
            for child in item:
                visit(child)
                if max_items is not None and len(out) >= max_items:
                    return
            return
        if isinstance(item, str):
            value = item.strip()
        else:
            value = str(item).strip()
        if value:
            out.append(value)

    visit(value)
    return out


def ensure_object(data: Any, *, object_key: str | None = None) -> dict[str, Any]:
    """Normalize schema-shape drift without silently inventing fields."""
    if isinstance(data, dict):
        return data
    if isinstance(data, list) and object_key:
        return {object_key: data}
    raise StructuredOutputError(
        f"Expected JSON object{f' or list for {object_key!r}' if object_key else ''}, got {type(data).__name__}."
    )
