"""Data-layer access control and PII masking for the Customer 360 prototype."""
from __future__ import annotations

import re
from typing import Any


AGENT_SOURCES = {
    "usage_agent": {"web_app_events"},
    "support_agent": {"support_logs"},
    "transaction_agent": {
        "card_payments", "instant_payments", "ach_wire", "core_banking_ledger", "trading_brokerage"
    },
    "kyc_compliance_agent": {"loan_kyc"},
}


def authorize(agent_name: str, source_system: str) -> bool:
    return source_system in AGENT_SOURCES.get(agent_name, set())


def mask_pii(value: Any) -> str:
    text = str(value)
    # Common direct identifiers in the supplied financial/support data.  Keep
    # monetary values, timestamps, and short event IDs intact for explainability.
    text = re.sub(r"\b\d{3}-\d{2}-\d{4}\b", "[REDACTED_SSN]", text)
    text = re.sub(r"(?<!\d)(?:\d[ -]?){13,19}(?!\d)", "[REDACTED_ID]", text)
    text = re.sub(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", "[REDACTED_EMAIL]", text, flags=re.I)
    return text


def _redact_recursive(value: Any, key: str = "") -> Any:
    """Recursively redact identifiers and obvious direct PII at prompt/log boundaries."""
    sensitive_keys = {
        "phone", "mobile", "email", "address", "street", "postal_code",
        "ssn", "national_id", "government_id", "account_number", "card_number",
        "routing_number", "date_of_birth", "dob",
    }
    token_keys = {"customer_id", "account_id", "case_id", "ticket_id"}
    if isinstance(value, dict):
        out: dict[str, Any] = {}
        for raw_key, raw_value in value.items():
            k = str(raw_key)
            kl = k.lower()
            if kl in sensitive_keys:
                out[k] = "[REDACTED_PII]"
            elif kl in token_keys:
                out[k] = "[CUSTOMER_TOKEN]" if kl == "customer_id" else "[ACCOUNT_TOKEN]"
            else:
                out[k] = _redact_recursive(raw_value, k)
        return out
    if isinstance(value, list):
        return [_redact_recursive(v, key) for v in value]
    if isinstance(value, tuple):
        return tuple(_redact_recursive(v, key) for v in value)
    if isinstance(value, str):
        return mask_pii(value)
    return value


def redact_customer_state_for_llm(state: dict[str, Any]) -> dict[str, Any]:
    """Return a structurally identical state with obvious direct identifiers masked."""
    return _redact_recursive(state)


def redact_sensitive(value: Any) -> Any:
    """Public boundary redactor used for model prompts and trace/audit serialization."""
    return _redact_recursive(value)
