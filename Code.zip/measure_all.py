import os, sys, json
from pathlib import Path
ROOT=Path('/tmp/c360v4'); os.chdir(ROOT); sys.path.insert(0,str(ROOT))
# Simulate a stale/hostile env from an old build; hard caps must contain it.
os.environ.update({
 'C360_LLM_MODE':'offline','C360_MAX_SPECIALIST_FINDINGS':'99','C360_MAX_CORRELATED_SIGNALS':'99','C360_MAX_EVIDENCE_PER_CATEGORY':'99','C360_MAX_EPISODIC_MEMORY':'99','C360_MAX_RECENT_EVENTS':'99','C360_MAX_EVENT_PAYLOAD_CHARS':'9999',
})
from main import load_jsonl
from config import load_scenario_metadata, ALLOWED_STATES
from state import CustomerState
from agents import SpecialistAgents
from synthesis import SynthesisAgent
from evidence import EvidenceExtractor
from life_event import LifeEventAgent
from debate import ConflictDetectionAgent, DebateAgent
from decision import DecisionAgent
from offer import OfferEligibilityAgent
from action import RetentionActionAgent
from drafting import RoundRobinDraftingAgent
from critique import CritiqueComplianceAgent
from memory import CustomerMemory
from llm_provider import estimate_tokens, _configured_output_tokens
from governance import redact_sensitive

def memory_query(events):
    chunks=[]
    for event in events[-20:]:
        p=event.payload or {}
        for key in ('raw_text','search_text','merchant_name','feature_or_page','transaction_type','counterparty_name'):
            if p.get(key) not in (None,''): chunks.append(str(p[key]))
    return ' '.join(chunks)[-5000:]

for scenario in ('scenario_01','scenario_02','scenario_03'):
  sd=ROOT/scenario; meta=load_scenario_metadata(sd); ent=meta['entities']; cid=str(ent['customer_id']); prof=ent.get('profile',{}); accounts=ent.get('accounts',{})
  if isinstance(accounts,list): accounts={str(a.get('account_id')):a for a in accounts if a.get('account_id')}
  hist=load_jsonl(sd/'history_seed.jsonl'); live=load_jsonl(sd/'live_stream.jsonl')
  state=CustomerState(customer_id=cid, customer_profile={'customer_id':cid,**prof}, accounts=accounts)
  for e in sorted(hist,key=lambda x:(x.event_time,x.ingestion_time,x.event_id)): state.update(e)
  mem=CustomerMemory(cid,root=str(ROOT/'memory'),scope_id='measure-'+scenario); mem.seed_semantic_policy()
  for e in hist: mem.index_event(e)
  sa=SpecialistAgents(max_workers=1); syn=SynthesisAgent(llm=object()); lev=LifeEventAgent(llm=object()); dec=DecisionAgent(llm=object()); conf=ConflictDetectionAgent(); offer=OfferEligibilityAgent(); action=RetentionActionAgent(); draft=RoundRobinDraftingAgent(llm=object()); crit=CritiqueComplianceAgent(llm=object())
  maxs={k:0 for k in ['life','debate','decision','draft','critique']}; maxreq={k:0 for k in maxs}; conflicts=0; callable=0
  # Use every 12th live event as an upper-bound proxy for checkpoint size.
  for i,e in enumerate(live,1):
    state.update(e); mem.index_event(e)
    if i%12: continue
    events=[x for x in state.all_events if x.event_time<=e.event_time]; events.sort(key=lambda x:(x.event_time,x.ingestion_time,x.event_id))
    findings=sa.run(state,events); synres=syn._fallback(state,findings,events); signals=synres.signals; evidence=EvidenceExtractor(state).extract(events)
    epis=mem.retrieve_episodic(query=memory_query(events),limit=2,reference_time=e.event_time)
    ctx=lev._context(state,findings,signals,evidence,{'episodic':epis}); lp=lev._prompt(ctx)
    est=estimate_tokens(lp)+_configured_output_tokens('life_event'); maxs['life']=max(maxs['life'],len(lp)); maxreq['life']=max(maxreq['life'],est)
    c=conf.detect(findings,signals,synres.model_dump(exclude={'signals'})); le=lev._fallback(state,events)
    policy=dec.registry.for_state(le.inferred_state); dc={'customer_state':state.summary(),'specialist_findings':[f.model_dump() for f in findings][:4],'correlated_signals':[s.model_dump() for s in signals][:6],'evidence':sum(evidence.values(),[])[:6],'memory':epis[:3],'debate':{},'prior_action_history':[]}
    dp=dec._prompt(le,dc,policy); maxs['decision']=max(maxs['decision'],len(dp)); maxreq['decision']=max(maxreq['decision'],estimate_tokens(dp)+_configured_output_tokens('decision'))
    if c.conflict_detected:
      conflicts+=1
      rec={'life_event':le.model_dump(),'conflict':c.model_dump(),'specialist_positions':[f.model_dump() for f in findings if not c.compared_agents or f.agent_name in c.compared_agents],'correlated_signals':[s.model_dump() for s in signals[:8]],'allowed_states':ALLOWED_STATES}
      bp=f'''You are the explicit Debate / Arbitration Agent in a Customer 360 system.\nTwo or more specialists disagree. Do not hide the disagreement. Produce two genuinely contrasting perspectives, then act as an arbiter. You may resolve the disagreement or leave it unresolved. Do not choose a policy action. Use only the supplied evidence.\nReturn ONLY JSON:\n{{"perspectives":[{{"perspective_name":"evidence_skeptic","position":"...","arguments":["..."],"counterpoints":["..."],"evidence":["..."]}},{{"perspective_name":"customer_risk_advocate","position":"...","arguments":["..."],"counterpoints":["..."],"evidence":["..."]}}],"resolution_status":"resolved|unresolved","resolved_state":"allowed state","confidence":0.0,"reasoning":"...","disagreements":["..."],"consensus":["..."],"resolution_evidence":["..."]}}\nRecord:\n{json.dumps(redact_sensitive(rec),ensure_ascii=False,separators=(",",":"),default=str)}'''
      maxs['debate']=max(maxs['debate'],len(bp)); maxreq['debate']=max(maxreq['debate'],estimate_tokens(bp)+_configured_output_tokens('debate'))
    # approximate actionable prompt size
    if le.inferred_state!='no_significant_event':
      d=dec._fallback(le,dec.registry,context=dc); of=offer.evaluate(le,d); ap=action.propose(d,le,of); drp=draft._build_prompt(d,of,ap.model_dump()); maxs['draft']=max(maxs['draft'],len(drp)); maxreq['draft']=max(maxreq['draft'],estimate_tokens(drp)+_configured_output_tokens('draft'))
      drafts=draft.generate_drafts(d,offer=of,action_proposal=ap.model_dump())
      cp=crit._build_prompt(drafts,of); maxs['critique']=max(maxs['critique'],len(cp)); maxreq['critique']=max(maxreq['critique'],estimate_tokens(cp)+_configured_output_tokens('critique'))
  print(scenario,'max_chars',maxs,'max_request_est',maxreq,'conflict_proxies',conflicts)
