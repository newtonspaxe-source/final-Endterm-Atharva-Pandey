"""Scenario-agnostic policy registry: validation/eligibility only, never inference."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from config import ALLOWED_ACTIONS, project_root, load_policy


class PolicyViolationError(ValueError):
    pass


class PolicyRegistry:
    def __init__(self, path: Path | None = None):
        self.path = path or project_root() / "policy_defaults.json"

    def document(self) -> dict[str, Any]:
        return load_policy(self.path)

    def rules(self) -> list[dict[str, Any]]:
        document = self.document()
        return [dict(r) for r in document.get("rules", []) if isinstance(r, dict)]

    def for_state(self, state: str) -> dict[str, Any]:
        for rule in self.rules():
            if rule.get("state") == state:
                return dict(rule)
        return {}

    def allowed_actions_for(self, state: str) -> list[str]:
        rule = self.for_state(state)
        configured = rule.get("allowed_actions")
        if not configured:
            configured = self.document().get("defaults", {}).get("allowed_actions", ALLOWED_ACTIONS)
        return [str(x) for x in configured if str(x) in ALLOWED_ACTIONS]

    def allowed_subtypes_for(self, state: str, action: str) -> list[str]:
        rule = self.for_state(state)
        mapping = rule.get("allowed_action_subtypes", {})
        values = mapping.get(action, []) if isinstance(mapping, dict) else []
        return [str(x) for x in values]

    def human_review_actions_for(self, state: str) -> list[str]:
        rule = self.for_state(state)
        values = rule.get("human_review_actions", [])
        return [str(x) for x in values]

    def requires_human_review(self, state: str, action: str) -> bool:
        rule = self.for_state(state)
        return action in self.human_review_actions_for(state)

    def validate_action(self, action: str) -> bool:
        return action in ALLOWED_ACTIONS

    def validate(self, decision: Any, life_event: Any) -> Any:
        allowed_actions = self.allowed_actions_for(life_event.inferred_state)
        if decision.action not in allowed_actions:
            raise PolicyViolationError(
                f"Action {decision.action!r} is not permitted for inferred state {life_event.inferred_state!r}."
            )

        subtypes = self.allowed_subtypes_for(life_event.inferred_state, decision.action)
        if subtypes and decision.action_subtype not in subtypes:
            raise PolicyViolationError(
                f"Subtype {decision.action_subtype!r} is not permitted for action {decision.action!r} in state {life_event.inferred_state!r}."
            )

        # These are derived fields from the semantic inference, not an override of it.
        decision.inferred_state = life_event.inferred_state
        decision.confidence = life_event.confidence
        decision.confidence_band = life_event.confidence_band
        decision.evidence = list(life_event.evidence)

        if self.requires_human_review(life_event.inferred_state, decision.action):
            decision.requires_human_review = True
            decision.hitl_status = "escalated"
        return decision
