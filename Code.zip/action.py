from __future__ import annotations

from pydantic import BaseModel, Field


class ActionProposal(BaseModel):
    customer_id: str
    action: str
    action_subtype: str | None = None
    purpose: str
    allowed_customer_content: list[str] = Field(default_factory=list)
    prohibited_customer_content: list[str] = Field(default_factory=list)
    evidence_event_ids: list[str] = Field(default_factory=list)
    requires_human_review: bool = True


class RetentionActionAgent:
    """Explicit action-planning boundary between eligibility and communication drafting.

    It does not send messages or change accounts. It converts the bounded Decision + Offer
    outputs into a small, auditable proposal package consumed by the round-robin drafter.
    """

    def __init__(self) -> None:
        self.name = "retention_action_agent"

    def propose(self, decision, life_event, offer) -> ActionProposal:
        customer_action = decision.action
        purpose_map = {
            "proactive_retention_outreach": "Offer a low-pressure relationship follow-up.",
            "relationship_manager_escalation": "Route a relationship review to a human banker/manager.",
            "personalized_offer": "Present only the currently eligible product/offer path.",
            "support_intervention": "Invite the customer to review available support options.",
            "compliance_fraud_hold": "Route to a specialist review; do not make unsupported customer claims.",
            "no_action": "Record an explicit no-action outcome.",
        }
        purpose = purpose_map.get(customer_action, "Review the bounded action with the customer/appropriate human team.")
        prohibited = [
            "internal inferred state", "confidence score", "agent reasoning",
            "sensitive medical/security inference", "unverified eligibility guarantee",
        ]
        return ActionProposal(
            customer_id=decision.customer_id,
            action=customer_action,
            action_subtype=decision.action_subtype,
            purpose=purpose,
            allowed_customer_content=["approved next-step purpose", "available options", "human contact path"],
            prohibited_customer_content=prohibited,
            evidence_event_ids=list(dict.fromkeys(getattr(life_event, "source_event_ids", [])))[:20],
            requires_human_review=customer_action != "no_action",
        )
