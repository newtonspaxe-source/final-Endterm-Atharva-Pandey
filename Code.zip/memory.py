"""Customer-scoped working, episodic and semantic memory.

The index is updated incrementally as events arrive; no full re-index is needed
for a new event. Customer isolation is enforced by a customer-specific storage
path plus an exact customer_id check on every retrieval row.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
import hashlib
import json
import math
import re
from typing import Any


class LocalVectorIndex:
    """Small dependency-free semantic index suitable for the supplied prototype data."""
    DIM = 128

    @classmethod
    def embed(cls, text: str) -> list[float]:
        vec = [0.0] * cls.DIM
        tokens = re.findall(r"[a-z0-9_]+", text.lower())
        for token in tokens:
            h = int(hashlib.sha256(token.encode("utf-8")).hexdigest()[:8], 16)
            vec[h % cls.DIM] += 1.0
        norm = math.sqrt(sum(x * x for x in vec)) or 1.0
        return [x / norm for x in vec]

    @staticmethod
    def cosine(a: list[float], b: list[float]) -> float:
        return sum(x * y for x, y in zip(a, b))


class CustomerMemory:
    """Three-layer memory with customer-level isolation and freshness controls."""

    def __init__(self, customer_id: str, root: str = "memory", scope_id: str | None = None):
        self.customer_id = customer_id
        self.scope_id = scope_id or "default"
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        # Episodic memory is customer-scoped *and* replay/scope-scoped. This prevents
        # one concurrent replay from bleeding historical interventions into another.
        safe_scope = re.sub(r"[^A-Za-z0-9_.-]+", "_", self.scope_id)[:80] or "default"
        self.episodic_path = self.root / f"{customer_id}_{safe_scope}_episodic.jsonl"
        self.semantic_path = self.root / "semantic_policy.json"
        # Raw event retrieval is customer-scoped; events themselves carry scope_id for audit.
        self.event_index_path = self.root / f"{customer_id}_events.index.jsonl"
        self.episode_index_path = self.root / f"{customer_id}_{safe_scope}_episodic.index.jsonl"
        self._seen_event_ids: set[str] = set()
        self._load_seen_event_ids()

    def _load_seen_event_ids(self) -> None:
        if not self.event_index_path.exists():
            return
        try:
            with self.event_index_path.open("r", encoding="utf-8") as f:
                for line in f:
                    try:
                        row = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    event_id = row.get("event_id") if isinstance(row, dict) else None
                    if event_id:
                        self._seen_event_ids.add(str(event_id))
        except OSError:
            return

    def _read_jsonl(self, path: Path) -> list[dict[str, Any]]:
        if not path.exists():
            return []
        out: list[dict[str, Any]] = []
        try:
            with path.open("r", encoding="utf-8") as f:
                for line in f:
                    if not line.strip():
                        continue
                    try:
                        row = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if isinstance(row, dict):
                        out.append(row)
        except OSError:
            return []
        return out

    @staticmethod
    def _event_text(event: Any) -> str:
        payload = getattr(event, "payload", {}) or {}
        keys = (
            "raw_text", "search_text", "merchant_name", "feature_or_page",
            "transaction_type", "counterparty_name", "mcc_category", "status",
        )
        values = [str(getattr(event, "event_type", ""))]
        values.extend(str(payload[k]) for k in keys if payload.get(k) not in (None, ""))
        return " ".join(values)

    def index_event(self, event: Any) -> bool:
        """Incrementally index one accepted event. Returns True when written."""
        event_id = str(getattr(event, "event_id", ""))
        customer_id = str(getattr(event, "customer_id", ""))
        if not event_id or customer_id != self.customer_id or event_id in self._seen_event_ids:
            return False
        record = {
            "event_id": event_id,
            "customer_id": customer_id,
            "scope_id": self.scope_id,
            "event_time": str(getattr(event, "event_time", "")),
            "ingestion_time": str(getattr(event, "ingestion_time", "")),
            "source_system": str(getattr(event, "source_system", "")),
            "event_type": str(getattr(event, "event_type", "")),
            "text": self._event_text(event)[:1000],
        }
        record["embedding"] = LocalVectorIndex.embed(record["text"])
        with self.event_index_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
        self._seen_event_ids.add(event_id)
        return True

    def retrieve_events(self, query: str = "", limit: int = 8, max_age_days: int | None = None, reference_time: datetime | None = None) -> list[dict[str, Any]]:
        rows = [r for r in self._read_jsonl(self.event_index_path) if r.get("customer_id") == self.customer_id]
        if not rows:
            return []
        cutoff = None
        if max_age_days is not None:
            anchor = reference_time or datetime.now(timezone.utc)
            if anchor.tzinfo is None:
                anchor = anchor.replace(tzinfo=timezone.utc)
            cutoff = anchor.astimezone(timezone.utc) - timedelta(days=max(0, int(max_age_days)))
        q = LocalVectorIndex.embed(query or self.customer_id)
        scored: list[tuple[float, dict[str, Any]]] = []
        for row in rows:
            if cutoff:
                try:
                    event_time = datetime.fromisoformat(str(row.get("event_time")).replace("Z", "+00:00"))
                    if event_time < cutoff:
                        continue
                except (TypeError, ValueError):
                    pass
            emb = row.get("embedding") or LocalVectorIndex.embed(str(row.get("text", "")))
            score = LocalVectorIndex.cosine(q, emb)
            scored.append((score, row))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [{**row, "retrieval_score": round(score, 4)} for score, row in scored[: max(1, int(limit))]]

    def retrieve_episodic(self, query: str = "", limit: int = 5, max_age_days: int | None = None, reference_time: datetime | None = None) -> list[dict[str, Any]]:
        rows = [r for r in self._read_jsonl(self.episodic_path) if r.get("customer_id") == self.customer_id]
        if not rows:
            return []
        cutoff = None
        if max_age_days is not None:
            anchor = reference_time or datetime.now(timezone.utc)
            if anchor.tzinfo is None:
                anchor = anchor.replace(tzinfo=timezone.utc)
            cutoff = anchor.astimezone(timezone.utc) - timedelta(days=max(0, int(max_age_days)))
        q = LocalVectorIndex.embed(query or self.customer_id)
        scored: list[tuple[float, dict[str, Any]]] = []
        for row in rows:
            if cutoff:
                try:
                    created = datetime.fromisoformat(str(row.get("timestamp")).replace("Z", "+00:00"))
                    if created < cutoff:
                        continue
                except (TypeError, ValueError):
                    pass
            emb = row.get("embedding") or LocalVectorIndex.embed(json.dumps(row, sort_keys=True))
            score = LocalVectorIndex.cosine(q, emb)
            # Relevance dominates; a small recency factor breaks ties and helps decay stale episodes.
            scored.append((score, row))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [{**row, "retrieval_score": round(score, 4)} for score, row in scored[: max(1, int(limit))]]

    def write_episode(
        self, inferred_state: str, action: str, confidence: float, evidence: list[str],
        event_ids: list[str] | None = None, outcome: str | None = None,
        action_subtype: str | None = None, hitl_status: str | None = None,
        original_message: str | None = None, final_message: str | None = None,
    ) -> None:
        record = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "customer_id": self.customer_id,
            "scope_id": self.scope_id,
            "inferred_state": inferred_state,
            "action": action,
            "action_subtype": action_subtype,
            "hitl_status": hitl_status,
            "original_message": original_message,
            "final_message": final_message,
            "confidence": confidence,
            "evidence": evidence[:10],
            "event_ids": (event_ids or [])[:20],
            "outcome": outcome,
        }
        record["embedding"] = LocalVectorIndex.embed(json.dumps(record, sort_keys=True, ensure_ascii=False))
        with self.episodic_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
        with self.episode_index_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps({
                "timestamp": record["timestamp"], "customer_id": self.customer_id,
                "state": inferred_state, "action": action,
                "embedding": record["embedding"],
            }) + "\n")

    def retrieve_semantic(self, query: str = "") -> dict[str, Any]:
        if not self.semantic_path.exists():
            return {"description": "Shared policy memory", "rules": []}
        try:
            policy = json.loads(self.semantic_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {"description": "Shared policy memory", "rules": []}
        if query and policy.get("rules"):
            q = LocalVectorIndex.embed(query)
            ranked = [(LocalVectorIndex.cosine(q, LocalVectorIndex.embed(json.dumps(rule, sort_keys=True))), rule) for rule in policy["rules"]]
            policy = dict(policy)
            policy["rules"] = [r for _, r in sorted(ranked, key=lambda x: x[0], reverse=True)]
        return policy

    def seed_semantic_policy(self) -> None:
        """Update shared semantic policy without rebuilding customer event indexes."""
        defaults_path = Path(__file__).resolve().parent / "policy_defaults.json"
        try:
            defaults = json.loads(defaults_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            defaults = {"description": "Shared policy memory", "rules": []}
        if self.semantic_path.exists():
            try:
                policy = json.loads(self.semantic_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                policy = {}
        else:
            policy = {}
        existing = policy.get("rules") or []
        default_rules = [dict(rule) for rule in defaults.get("rules", []) if isinstance(rule, dict) and rule.get("state")]
        default_states = {rule.get("state") for rule in default_rules}
        extra_rules = [dict(rule) for rule in existing if isinstance(rule, dict) and rule.get("state") not in default_states]
        policy["description"] = defaults.get("description", policy.get("description") or "Shared policy memory")
        policy["rules"] = default_rules + extra_rules
        self.semantic_path.write_text(json.dumps(policy, indent=2, ensure_ascii=False), encoding="utf-8")
