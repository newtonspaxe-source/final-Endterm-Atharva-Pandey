from __future__ import annotations

import json
from typing import Any, Literal

from pydantic import BaseModel, Field

from drafting import ActionDraft
from governance import redact_sensitive
from json_utils import ensure_object, extract_json, response_text
from llm_provider import create_groq_llm, invoke
from offer import OfferRecommendation


class ReviewerAssessment(BaseModel):
    reviewer: str
    verdict: Literal["approved", "needs_revision", "rejected"]
    issues: list[str] = Field(default_factory=list)
    flags: list[str] = Field(default_factory=list)
    suggestion: str = ""


class CritiqueResult(BaseModel):
    draft_id: str
    agent_name: str
    status: Literal["approved", "needs_revision", "rejected"]
    compliance_flags: list[str] = Field(default_factory=list)
    issues: list[str] = Field(default_factory=list)
    revised_message: str | None = None
    explanation: str
    reviewer_assessments: list[ReviewerAssessment] = Field(default_factory=list)


class CritiqueComplianceAgent:
    """Independent critique/refiner before the deterministic safety boundary."""

    REVIEWERS = [
        "customer_safety_reviewer",
        "policy_eligibility_reviewer",
        "communication_quality_reviewer",
    ]

    def __init__(self, llm=None):
        self.name = "critique_compliance_agent"
        self.llm = llm if llm is not None else create_groq_llm("critique", default_model="openai/gpt-oss-20b", default_temperature=0.0)
        self.last_prompt = ""
        self.last_provider = "deterministic_fallback"
        self.last_error: str | None = None

    @staticmethod
    def _deterministic_checks(draft: ActionDraft, offer: OfferRecommendation) -> tuple[list[str], list[str]]:
        issues: list[str] = []
        flags: list[str] = []
        message = draft.message.lower()
        forbidden_certainty = ("we know", "we detected", "you are definitely", "you have definitely")
        for phrase in forbidden_certainty:
            if phrase in message:
                issues.append(f"Unsupported certainty phrase: {phrase!r}")
        sensitive = ("medical", "hospital", "diagnosis", "condition", "fraud", "takeover", "sanctions")
        if any(term in message for term in sensitive):
            flags.append("sensitive_internal_information")
            issues.append("Customer-facing message contains internal sensitive information.")
        if draft.action == "personalized_offer" and offer.eligibility_status == "not_eligible":
            issues.append("Personalized offer is not eligible; customer-facing offer messaging is blocked.")
        if len(draft.message.split()) > 80:
            issues.append("Message is too long for the customer communication boundary.")
        return issues, flags

    @staticmethod
    def _safe_revision(draft: ActionDraft, local_issues: list[str]) -> str:
        # Deterministic privacy-safe refiner. Never inserts sensitive inference details.
        if local_issues:
            return "A specialist can review the available options with you. Please let us know a convenient time to connect."
        return draft.message.strip()

    def _build_prompt(self, drafts: list[ActionDraft], offer: OfferRecommendation) -> str:
        payload = {
            "offer": offer.model_dump(),
            "drafts": [
                {"draft_id": d.draft_id, "agent_name": d.agent_name, "action": d.action, "subtype": d.action_subtype, "message": d.message}
                for d in drafts
            ],
        }
        return f"""
You are the Critique / Refiner Agent in a banking Customer 360 system.

Review each draft from three distinct perspectives: customer safety, policy eligibility,
and communication quality. Identify specific issues. When revision is needed, provide a
safe replacement message that does not expose internal state, evidence, confidence, risk,
agent names, medical/security inference, or private policy details.

Return ONLY JSON:
{{
  "reviews": [
    {{"draft_id":"...","reviewers":[
      {{"reviewer":"customer_safety_reviewer","verdict":"approved|needs_revision|rejected","issues":[],"flags":[],"suggestion":"..."}},
      {{"reviewer":"policy_eligibility_reviewer","verdict":"approved|needs_revision|rejected","issues":[],"flags":[],"suggestion":"..."}},
      {{"reviewer":"communication_quality_reviewer","verdict":"approved|needs_revision|rejected","issues":[],"flags":[],"suggestion":"..."}}
    ],"revised_message":"...","summary":"..."}}
  ]
}}

Context:
{json.dumps(redact_sensitive(payload), ensure_ascii=False, separators=(",", ":"), default=str)}
""".strip()

    def review_drafts(self, drafts: list[ActionDraft], offer: OfferRecommendation) -> list[CritiqueResult]:
        if not drafts:
            return []
        prompt = self._build_prompt(drafts, offer)
        self.last_prompt = prompt
        self.last_error = None
        remote: dict[str, Any] = {}
        try:
            if self.llm is None:
                raise RuntimeError("Critique LLM unavailable")
            data = ensure_object(extract_json(response_text(invoke(self.llm, prompt, "critique"))), object_key="reviews")
            remote = {str(x.get("draft_id")): x for x in data.get("reviews", []) if isinstance(x, dict)}
            self.last_provider = "groq"
        except Exception as exc:
            self.last_error = f"{type(exc).__name__}: {exc}"
            self.last_provider = "deterministic_fallback"
            print(f"[CRITIQUE] Groq output unusable; deterministic review used: {exc}.")

        results: list[CritiqueResult] = []
        for draft in drafts:
            local_issues, local_flags = self._deterministic_checks(draft, offer)
            item = remote.get(draft.draft_id, {})
            assessments: list[ReviewerAssessment] = []
            try:
                assessments = [ReviewerAssessment.model_validate(x) for x in item.get("reviewers", [])]
            except Exception:
                assessments = []
            llm_issues = [issue for a in assessments for issue in a.issues]
            llm_flags = [flag for a in assessments for flag in a.flags]
            issues = list(dict.fromkeys(local_issues + llm_issues))
            flags = list(dict.fromkeys(local_flags + llm_flags))
            verdicts = [a.verdict for a in assessments]
            if "rejected" in verdicts or (draft.action == "personalized_offer" and offer.eligibility_status == "not_eligible"):
                status = "rejected"
            elif "needs_revision" in verdicts or issues:
                status = "needs_revision"
            else:
                status = "approved"
            revised = str(item.get("revised_message", "")).strip() or None
            if status == "needs_revision" and not revised:
                revised = self._safe_revision(draft, issues)
            results.append(CritiqueResult(
                draft_id=draft.draft_id,
                agent_name=draft.agent_name,
                status=status,
                compliance_flags=flags,
                issues=issues,
                revised_message=revised,
                explanation=str(item.get("summary") or "Three independent compliance perspectives were applied."),
                reviewer_assessments=assessments or [ReviewerAssessment(reviewer=r, verdict=status, issues=issues[:2], flags=flags[:2]) for r in self.REVIEWERS],
            ))
        print("[CRITIQUE] Three-perspective compliance review completed.")
        return results

    def apply_refinement(self, drafts: list[ActionDraft], results: list[CritiqueResult]) -> list[ActionDraft]:
        by_id = {r.draft_id: r for r in results}
        for draft in drafts:
            result = by_id.get(draft.draft_id)
            if result and result.status == "needs_revision" and result.revised_message:
                draft.message = result.revised_message.strip()
                draft.draft_status = "revised"
                draft.revision_notes = (draft.revision_notes + " | critique-refiner applied").strip(" |")
        if drafts:
            # The last compliant candidate is the final customer-facing draft after critique.
            for draft in drafts:
                draft.draft_status = "final" if draft.draft_id == drafts[-1].draft_id else draft.draft_status
        return drafts

    def review(self, draft: ActionDraft, offer: OfferRecommendation) -> CritiqueResult:
        return self.review_drafts([draft], offer)[0]
