from __future__ import annotations

from datetime import datetime
from typing import Any, ClassVar, Literal

from pydantic import BaseModel, Field

from models import Event


class ActionRecord(BaseModel):
    action_id: str
    customer_id: str
    inferred_state: str
    action: str
    action_subtype: str | None
    original_message: str | None = None
    final_message: str | None = None
    draft_id: str | None = None
    source_event_ids: list[str] = Field(default_factory=list)
    status: Literal["proposed", "pending_human_review", "approved", "modified", "rejected", "executed", "blocked"]
    created_at: datetime
    resolved_at: datetime | None = None
    rejection_reason: str | None = None
    modification_reason: str | None = None


class CustomerState(BaseModel):
    """Shared per-customer state board: working memory + published structured findings."""

    customer_id: str
    customer_profile: dict[str, Any] = Field(default_factory=dict)
    accounts: dict[str, Any] = Field(default_factory=dict)
    last_event_time: datetime | None = None
    last_ingestion_time: datetime | None = None
    total_events: int = 0
    events_by_source: dict[str, int] = Field(default_factory=dict)
    events_by_type: dict[str, int] = Field(default_factory=dict)
    latest_balances: dict[str, float] = Field(default_factory=dict)
    balance_event_times: dict[str, datetime] = Field(default_factory=dict)
    transaction_counts: dict[str, int] = Field(default_factory=dict)
    transaction_amounts: dict[str, float] = Field(default_factory=dict)
    support_tickets_created: int = 0
    support_tickets_resolved: int = 0
    support_calls: int = 0
    web_logins: int = 0
    web_searches: int = 0
    web_features_used: int = 0
    web_sessions: int = 0
    kyc_updates: int = 0
    profile_changes: list[dict[str, Any]] = Field(default_factory=list)
    recent_events: list[dict[str, Any]] = Field(default_factory=list)
    all_events: list[Event] = Field(default_factory=list)
    latest_agent_findings: dict[str, dict[str, Any]] = Field(default_factory=dict)
    action_history: list[ActionRecord] = Field(default_factory=list)
    pending_action_id: str | None = None
    max_recent_events: int = 20

    TRANSACTION_SOURCES: ClassVar[set[str]] = {
        "card_payments", "instant_payments", "ach_wire", "core_banking_ledger", "trading_brokerage"
    }

    def publish_finding(self, finding: Any) -> None:
        try:
            self.latest_agent_findings[str(finding.agent_name)] = finding.model_dump(mode="json")
        except Exception:
            self.latest_agent_findings[str(getattr(finding, "agent_name", "unknown"))] = {"value": str(finding)}

    def update(self, event: Event) -> None:
        self.total_events += 1
        self.events_by_source[event.source_system] = self.events_by_source.get(event.source_system, 0) + 1
        self.events_by_type[event.event_type] = self.events_by_type.get(event.event_type, 0) + 1
        if self.last_event_time is None or event.event_time > self.last_event_time:
            self.last_event_time = event.event_time
        if self.last_ingestion_time is None or event.ingestion_time > self.last_ingestion_time:
            self.last_ingestion_time = event.ingestion_time

        if event.source_system in self.TRANSACTION_SOURCES:
            amount = event.payload.get("amount")
            if isinstance(amount, (int, float)):
                self.transaction_amounts[event.source_system] = self.transaction_amounts.get(event.source_system, 0.0) + float(amount)
            self.transaction_counts[event.source_system] = self.transaction_counts.get(event.source_system, 0) + 1

        if event.source_system == "core_banking_ledger":
            balance_after = event.payload.get("balance_after")
            if event.account_id is not None and isinstance(balance_after, (int, float)):
                previous_time = self.balance_event_times.get(event.account_id)
                if previous_time is None or event.event_time >= previous_time:
                    self.latest_balances[event.account_id] = float(balance_after)
                    self.balance_event_times[event.account_id] = event.event_time

        if event.source_system == "support_logs":
            if event.event_type == "ticket_created":
                self.support_tickets_created += 1
            elif event.event_type == "ticket_resolved":
                self.support_tickets_resolved += 1
            elif event.event_type == "call_transcript":
                self.support_calls += 1

        if event.source_system == "web_app_events":
            if event.event_type == "login": self.web_logins += 1
            elif event.event_type == "search_query": self.web_searches += 1
            elif event.event_type == "feature_used": self.web_features_used += 1
            elif event.event_type == "session_duration": self.web_sessions += 1

        if event.source_system == "loan_kyc":
            if event.event_type in {"kyc_update", "address_change", "marital_status_change", "dependents_change"}:
                self.kyc_updates += 1
                self.profile_changes.append({
                    "event_id": event.event_id,
                    "event_time": event.event_time.isoformat(),
                    "event_type": event.event_type,
                    "payload": event.payload,
                })
                if event.event_type == "dependents_change" and "new_value" in event.payload:
                    self.customer_profile["dependents"] = event.payload.get("new_value")
                if event.event_type in {"address_change", "marital_status_change"} and "new_value" in event.payload:
                    self.customer_profile[event.event_type] = event.payload.get("new_value")

        self.all_events.append(event)
        self.recent_events.append({
            "event_id": event.event_id,
            "event_time": event.event_time.isoformat(),
            "ingestion_time": event.ingestion_time.isoformat(),
            "source_system": event.source_system,
            "event_type": event.event_type,
            "account_id": event.account_id,
            "payload": event.payload,
        })
        if len(self.recent_events) > self.max_recent_events:
            self.recent_events = self.recent_events[-self.max_recent_events:]

    def summary(self) -> dict[str, Any]:
        return {
            "customer_id": self.customer_id,
            "customer_profile": self.customer_profile,
            "accounts": self.accounts,
            "last_event_time": self.last_event_time.isoformat() if self.last_event_time else None,
            "last_ingestion_time": self.last_ingestion_time.isoformat() if self.last_ingestion_time else None,
            "total_events": self.total_events,
            "events_by_source": self.events_by_source,
            "events_by_type": self.events_by_type,
            "latest_balances": self.latest_balances,
            "balance_event_time": {k: v.isoformat() for k, v in self.balance_event_times.items()},
            "transaction_counts": self.transaction_counts,
            "transaction_amounts": self.transaction_amounts,
            "support": {"tickets_created": self.support_tickets_created, "tickets_resolved": self.support_tickets_resolved, "calls": self.support_calls},
            "web_activity": {"logins": self.web_logins, "searches": self.web_searches, "features_used": self.web_features_used, "sessions": self.web_sessions},
            "kyc_updates": self.kyc_updates,
            "profile_changes": self.profile_changes[-10:],
            "latest_agent_findings": self.latest_agent_findings,
            "recent_events_count": len(self.recent_events),
            "pending_action_id": self.pending_action_id,
        }
