from __future__ import annotations

import argparse
import json
from pathlib import Path

from evaluation import ScenarioEvaluator


def main() -> int:
    parser = argparse.ArgumentParser(description="Score an inferred-events JSONL against a practice scenario ground truth.")
    parser.add_argument("--scenario", required=True)
    parser.add_argument("--inferred", required=True)
    parser.add_argument("--trace", default=None)
    parser.add_argument("--audit", default=None)
    parser.add_argument("--hard-stop", dest="hard_stop", default=None)
    args = parser.parse_args()

    root = Path(__file__).resolve().parent
    evaluator = ScenarioEvaluator(root)
    inferred = Path(args.inferred)
    if not inferred.exists():
        raise SystemExit(f"Inferred-events file not found: {inferred}")
    rows = evaluator._load_rows(str(inferred))
    gt = evaluator.load_ground_truth(args.scenario)
    checkpoints = evaluator._checkpoint_results(gt, rows)
    total = len(checkpoints)
    if total:
        state = sum(x["state_pass"] for x in checkpoints) / total
        action = sum(x["action_pass"] for x in checkpoints) / total
        subtype = sum(x["subtype_pass"] for x in checkpoints) / total
        hitl = sum(x["hitl_pass"] for x in checkpoints) / total
        complete = sum(x["checkpoint_pass"] for x in checkpoints) / total
    else:
        state = action = subtype = hitl = complete = None
    false_positive = evaluator._false_positive_results(gt, rows)
    print(json.dumps({
        "scenario_id": args.scenario,
        "inference_rows": len(rows),
        "checkpoints": total,
        "state_accuracy": state,
        "action_accuracy": action,
        "subtype_accuracy": subtype,
        "hitl_accuracy": hitl,
        "complete_checkpoint_accuracy": complete,
        "red_herring_pass": all(x["pass"] for x in false_positive) if false_positive else True,
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
