"""Shared, scenario-agnostic configuration and schema vocabulary."""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

ALLOWED_STATES = [
    "no_significant_event",
    "new_child_life_event",
    "marriage_or_relationship_change",
    "job_change_or_promotion",
    "job_loss_or_income_disruption",
    "medical_hardship",
    "financial_distress_general",
    "relocation",
    "retirement_transition",
    "wealth_growth_or_windfall",
    "potential_fraud_or_takeover",
    "elder_vulnerability_or_scam_risk",
    "churn_risk",
    "small_business_cashflow_event",
]

ALLOWED_ACTIONS = [
    "no_action",
    "proactive_retention_outreach",
    "relationship_manager_escalation",
    "personalized_offer",
    "support_intervention",
    "compliance_fraud_hold",
]

ALLOWED_HITL = [
    "auto_approved",
    "escalated",
    "human_approved",
    "human_rejected",
    "human_modified",
    "timed_out",
]

ALLOWED_CONFIDENCE_BANDS = ["low", "medium", "high"]

DEFAULT_CONTEXT_LIMITS = {
    "specialist_findings": 4,
    "correlated_signals": 6,
    "evidence_per_category": 2,
    "episodic_memory": 2,
    "recent_events": 4,
    "event_payload_chars": 90,
}

# Provider-facing context is intentionally bounded by code, not only by api.env.
# This prevents an old/stale local api.env from silently recreating the historical
# 8K+ request-size failures. Users may reduce these values, but not inflate them.
CONTEXT_HARD_MAX = dict(DEFAULT_CONTEXT_LIMITS)


def project_root() -> Path:
    return Path(__file__).resolve().parent


def get_context_limits() -> dict[str, int]:
    """Read only infrastructure limits from environment; never scenario values."""
    out = dict(DEFAULT_CONTEXT_LIMITS)
    for key, default in DEFAULT_CONTEXT_LIMITS.items():
        env_key = "C360_MAX_" + key.upper()
        raw = os.getenv(env_key)
        if raw:
            try:
                value = max(1, int(raw))
                out[key] = min(value, CONTEXT_HARD_MAX[key])
            except ValueError:
                out[key] = default
    return out


def load_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def discover_scenarios(root: Path | None = None) -> list[Path]:
    """Discover any scenario_* directory containing the core event files."""
    base = root or project_root()
    scenarios: list[Path] = []
    for path in base.glob("scenario_*"):
        if not path.is_dir():
            continue
        if (path / "history_seed.jsonl").exists() and (path / "live_stream.jsonl").exists():
            scenarios.append(path)
    return sorted(scenarios, key=lambda p: p.name)


def load_scenario_metadata(scenario_dir: Path) -> dict[str, Any]:
    entities = load_json(scenario_dir / "entities.json")
    replay = load_json(scenario_dir / "replay_config.json")
    instructions_path = scenario_dir / "instructions.md"
    instructions = ""
    if instructions_path.exists():
        try:
            instructions = instructions_path.read_text(encoding="utf-8")
        except OSError:
            instructions = ""
    return {
        "entities": entities,
        "replay": replay,
        "instructions": instructions,
    }


def load_policy(path: Path | None = None) -> dict[str, Any]:
    policy_path = path or project_root() / "policy_defaults.json"
    if not policy_path.exists():
        fallback = project_root() / "policy_defaults.json"
        policy_path = fallback if fallback.exists() else policy_path
    policy = load_json(policy_path)
    return policy if isinstance(policy, dict) else {}
