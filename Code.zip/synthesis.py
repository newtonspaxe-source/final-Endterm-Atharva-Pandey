from __future__ import annotations

import json
from typing import Any, Literal

from pydantic import BaseModel, Field

from agents import AgentFinding
from config import get_context_limits
from governance import mask_pii, redact_customer_state_for_llm, redact_sensitive
from json_utils import StructuredOutputError, ensure_object, extract_json, response_text
from llm_provider import create_groq_llm, invoke
from state import CustomerState


class CorrelatedSignal(BaseModel):
    signal: str
    strength: Literal["weak", "moderate", "strong"]
    confidence: float = Field(ge=0.0, le=1.0)
    supporting_agents: list[str] = Field(default_factory=list)
    evidence: list[str] = Field(default_factory=list)
    event_ids: list[str] = Field(default_factory=list)


class SynthesisResult(BaseModel):
    signals: list[CorrelatedSignal] = Field(default_factory=list, max_length=8)
    conflict_detected: bool = False
    conflicting_agents: list[str] = Field(default_factory=list)
    conflicting_signals: list[str] = Field(default_factory=list)
    conflict_explanation: str = ""


class SynthesisAgent:
    """Correlates specialist outputs and emits a strict structured handoff."""

    def __init__(self, llm=None):
        self.name = "synthesis_agent"
        self.llm = llm if llm is not None else create_groq_llm("synthesis", default_model="openai/gpt-oss-20b", default_temperature=0.0)
        self.last_prompt = ""
        self.last_error: str | None = None
        self.last_provider = "deterministic_fallback"
        self.last_conflict: dict[str, Any] = {
            "conflict_detected": False,
            "conflicting_agents": [],
            "conflicting_signals": [],
            "conflict_explanation": "",
        }

    @staticmethod
    def _compact_event(event: Any) -> dict[str, Any]:
        payload = getattr(event, "payload", {}) or {}
        keep = (
            "amount", "balance_after", "raw_text", "search_text", "merchant_name",
            "counterparty_name", "transaction_type", "feature_or_page", "status",
            "resolution_status", "old_value", "new_value", "direction",
        )
        return {
            "event_id": getattr(event, "event_id", None),
            "event_time": str(getattr(event, "event_time", "")),
            "source_system": getattr(event, "source_system", ""),
            "event_type": getattr(event, "event_type", ""),
            "payload": {k: str(payload[k])[:get_context_limits()["event_payload_chars"]] for k in keep if k in payload},
        }

    def _build_prompt(self, state: CustomerState, findings: list[AgentFinding], events: list[Any]) -> str:
        context = {
            "customer_state": redact_customer_state_for_llm(state.summary()),
            "specialist_findings": [f.model_dump() for f in findings],
            "recent_events": [
                self._compact_event(e)
                for e in sorted(events, key=lambda x: x.event_time, reverse=True)[:10]
            ],
        }
        safe = json.dumps(redact_sensitive(context), ensure_ascii=False, separators=(",", ":"), default=str)
        return f"""
You are the Synthesis / Correlation Agent in an ambient Customer 360 system.

Create a small set of cross-domain signals from independently produced specialist findings.
Do not infer a life-event name. Do not choose an action. Do not invent evidence.
A signal should connect observations across domains where appropriate and preserve event IDs.

Material disagreement means two credible specialist interpretations point in materially different
directions. Routine activity versus no-signal is not itself a conflict.

Return ONLY JSON. The root must be an object with exactly this contract:
{{
  "signals": [
    {{
      "signal": "descriptive cross-domain signal",
      "strength": "weak|moderate|strong",
      "confidence": 0.0,
      "supporting_agents": ["agent_name"],
      "evidence": ["grounded evidence"],
      "event_ids": ["event_id"]
    }}
  ],
  "conflict_detected": false,
  "conflicting_agents": [],
  "conflicting_signals": [],
  "conflict_explanation": ""
}}

Every event_id must appear in the supplied recent events or specialist findings.

Context:
{safe}
""".strip()

    @staticmethod
    def _fallback(state: CustomerState, findings: list[AgentFinding], events: list[Any], error: Exception | None = None) -> SynthesisResult:
        active = [f for f in findings if not f.signal_type.startswith("no_")]
        signals: list[CorrelatedSignal] = []
        if len(active) >= 2:
            top = sorted(active, key=lambda f: f.confidence, reverse=True)[:4]
            combined_agents = [f.agent_name for f in top]
            event_ids = [eid for f in top for eid in f.event_ids[:4]][:10]
            evidence = [item for f in top for item in f.evidence[:2]][:6]
            confidence = round(min(0.95, max(f.confidence for f in top) * 0.95), 2)
            strength = "strong" if confidence >= 0.8 else "moderate" if confidence >= 0.6 else "weak"
            signals.append(CorrelatedSignal(
                signal="multi_domain_customer_change",
                strength=strength,
                confidence=confidence,
                supporting_agents=combined_agents,
                evidence=evidence,
                event_ids=event_ids,
            ))

        positive = [f for f in active if getattr(f, "direction", "neutral") == "positive"]
        negative = [f for f in active if getattr(f, "direction", "neutral") == "negative"]
        # A meaningful debate case in this domain is persistent customer activity coexisting
        # with strong support friction. This is intentionally broader than a strict 0.65/0.65
        # cutoff so moderate-but-reliable activity is not mistaken for agreement.
        strong_negative = [f for f in negative if f.confidence >= 0.75]
        activity_positive = [f for f in positive if f.signal_type in {"usage_activity", "transaction_activity"} and f.confidence >= 0.58]
        general_mix = bool(positive and negative and max(f.confidence for f in positive) >= 0.68 and max(f.confidence for f in negative) >= 0.68)
        conflict = bool((activity_positive and strong_negative) or general_mix)
        conflict_agents = [f.agent_name for f in (positive[:2] + negative[:2])]
        conflict_signals = [f.signal_type for f in (positive[:2] + negative[:2])]
        explanation = (
            "High-confidence specialist findings contain both positive/stable activity and negative/risk-oriented interpretations, so explicit arbitration is warranted."
            if conflict else "No material directional disagreement was identified in the structured specialist findings."
        )
        return SynthesisResult(
            signals=signals,
            conflict_detected=conflict,
            conflicting_agents=conflict_agents,
            conflicting_signals=conflict_signals,
            conflict_explanation=explanation,
        )

    def analyze(self, state: CustomerState, findings: list[AgentFinding], events: list[Any]) -> list[CorrelatedSignal]:
        prompt = self._build_prompt(state, findings, events)
        self.last_prompt = prompt
        self.last_error = None

        if self.llm is None:
            result = self._fallback(state, findings, events)
            self.last_provider = "deterministic_fallback"
            self.last_conflict = result.model_dump(exclude={"signals"})
            print(f"[SYNTHESIS] Fallback path: {len(result.signals)} correlated signal(s); conflict={result.conflict_detected}.")
            return result.signals

        try:
            response = invoke(self.llm, prompt, "synthesis")
            raw = response_text(response)
            data = extract_json(raw)
            data = ensure_object(data, object_key="signals")
            result = SynthesisResult.model_validate(data)
            visible = {str(getattr(e, "event_id", "")) for e in events}
            visible.update(eid for f in findings for eid in f.event_ids)
            bad_ids = sorted({eid for s in result.signals for eid in s.event_ids if eid not in visible})
            if bad_ids:
                raise ValueError(f"Unknown event IDs in synthesis output: {bad_ids[:5]}")
            self.last_provider = "groq"
            self.last_conflict = result.model_dump(exclude={"signals"})
            print(f"[SYNTHESIS] Groq: {len(result.signals)} correlated signal(s); conflict={result.conflict_detected}.")
            return result.signals
        except Exception as exc:
            self.last_error = f"{type(exc).__name__}: {exc}"

        result = self._fallback(state, findings, events, Exception(self.last_error or "provider error"))
        self.last_provider = "deterministic_fallback"
        self.last_conflict = result.model_dump(exclude={"signals"})
        print(f"[SYNTHESIS] Groq output unusable; deterministic fallback used: {self.last_error or 'provider error'}.")
        return result.signals
