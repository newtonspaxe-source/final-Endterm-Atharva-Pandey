from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

from triggers import AmbientTriggerCoordinator


class InferredEvent(BaseModel):
    # `timestamp` is the evaluator-facing event-time field; `as_of_time` is retained
    # as an explicit semantic alias used by this project. Both describe the same checkpoint.
    timestamp: datetime
    as_of_time: datetime
    customer_id: str
    inferred_state: str
    confidence: float = 0.0
    confidence_band: str
    action: str
    action_subtype: str | None = None
    # Final HITL disposition after the human checkpoint (for example human_approved).
    hitl_status: str
    # Whether the decision/guardrail required human review before any human response.
    # Benchmark checkpoints use this field so approving an escalated action does not erase the escalation fact.
    hitl_requirement_status: str = "auto_approved"
    notes: str = ""
    evidence: list[str] = Field(default_factory=list)
    source_event_ids: list[str] = Field(default_factory=list)
    memory_refs: list[str] = Field(default_factory=list)
    decision_trace_id: str | None = None


class InferredEventWriter:
    def __init__(self, path: str = "outputs/inferred_events.jsonl"):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def write(self, item: InferredEvent) -> None:
        with self.path.open("a", encoding="utf-8") as f:
            f.write(item.model_dump_json() + "\n")

    def clear(self) -> None:
        self.path.unlink(missing_ok=True)


class TriggerDecision(BaseModel):
    should_infer: bool = False
    reasons: list[str] = Field(default_factory=list)

    def __bool__(self) -> bool:
        return self.should_infer


class DecisionCheckpoint:
    """Event/time/agent-dependent trigger engine with bounded provider load."""

    def __init__(self, min_events_between_inference: int = 30, min_minutes_between_inference: int = 43200):
        self.min_events_between_inference = max(20, int(min_events_between_inference))
        self.min_minutes_between_inference = max(1, int(min_minutes_between_inference))
        self.events_since_last = 0
        self.last_inference_event_time: datetime | None = None
        self.ambient = AmbientTriggerCoordinator()

    @staticmethod
    def _event_is_impactful(event: Any) -> tuple[bool, str | None]:
        event_type = str(getattr(event, "event_type", "")).lower()
        payload = getattr(event, "payload", {}) or {}
        source = str(getattr(event, "source_system", "")).lower()
        mcc = str(payload.get("mcc_category", "")).lower()
        semantic_text = " ".join(str(payload.get(k, "")) for k in ("merchant_name", "search_text", "raw_text", "feature_or_page", "transaction_type")).lower()
        if event_type in {"ticket_created", "ticket_resolved", "call_transcript", "dependents_change", "address_change", "marital_status_change", "outbound_transfer", "decline", "payment_declined"}:
            return True, f"event:{event_type}"
        if event_type == "feature_used" and "cancel" in semantic_text:
            return True, "event:relationship_withdrawal_feature"
        if event_type == "search_query":
            return True, "event:customer_intent_search"
        if mcc in {"healthcare", "pharmacy", "baby_products"}:
            return True, f"event:semantic_category_{mcc}"
        if any(term in semantic_text for term in ("hospital", "daycare", "dependents change")):
            return True, "event:semantic_life_change_anchor"
        if source == "loan_kyc" and event_type.startswith("kyc"):
            return True, "event:kyc_update"
        severity = str(payload.get("severity") or payload.get("urgency") or "").lower()
        if severity in {"high", "critical", "urgent"}:
            return True, f"event:severity_{severity}"
        amount = payload.get("amount")
        if isinstance(amount, (int, float)) and float(amount) >= 10000:
            return True, "event:large_financial_movement"
        return False, None

    def observe(self, event: Any, agent_findings: list[Any] | None = None) -> TriggerDecision:
        self.events_since_last += 1
        reasons: list[str] = []
        now = getattr(event, "event_time", None)
        event_signal = self.ambient.event_trigger.evaluate(event)
        scheduled_signal = self.ambient.scheduled_trigger.evaluate(now) if isinstance(now, datetime) else None
        agent_signal = self.ambient.agent_trigger.evaluate(agent_findings or []) if agent_findings is not None else None

        # Event-based triggers wake the ambient path immediately, but the expensive decision
        # graph is still subject to a small cooldown so a burst does not become an LLM request storm.
        # The raw event, its specialist routing, and live transforms happen on every accepted event.
        impactful, legacy_reason = self._event_is_impactful(event)
        if self.last_inference_event_time is None:
            if impactful or event_signal.fired:
                reasons.append(legacy_reason or event_signal.reason)
            elif self.events_since_last >= self.min_events_between_inference:
                reasons.append("event_count")
        else:
            # Keep event-time ordering monotonic when late events arrive.
            elapsed_minutes = 0.0
            if isinstance(now, datetime):
                elapsed_minutes = max(0.0, (now - self.last_inference_event_time).total_seconds() / 60.0)
            if (impactful or event_signal.fired) and self.events_since_last >= 2:
                reasons.append(legacy_reason or event_signal.reason)
            if scheduled_signal and scheduled_signal.fired and elapsed_minutes >= self.min_minutes_between_inference:
                reasons.append("scheduled_time_window")
            if self.events_since_last >= self.min_events_between_inference:
                reasons.append("event_count")

        if agent_signal and agent_signal.fired:
            if self.last_inference_event_time is None or self.events_since_last >= 4:
                reasons.append("agent_dependent_cross_signal")

        return TriggerDecision(should_infer=bool(reasons), reasons=list(dict.fromkeys(reasons)))

    def mark_inferred(self, event_time: datetime | None = None) -> None:
        self.events_since_last = 0
        if isinstance(event_time, datetime):
            self.ambient.scheduled_trigger.mark_fired(event_time)
            if self.last_inference_event_time is None or event_time > self.last_inference_event_time:
                self.last_inference_event_time = event_time
